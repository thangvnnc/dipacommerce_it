<!DOCTYPE html>
<!-- saved from url=(0030)https://www.mister-auto.co.uk/ -->
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style type="text/css">[uib-typeahead-popup].dropdown-menu {
            display: block;
        }</style>
    <style type="text/css">.uib-time input {
            width: 50px;
        }</style>
    <style type="text/css">[uib-tooltip-popup].tooltip.top-left > .tooltip-arrow, [uib-tooltip-popup].tooltip.top-right > .tooltip-arrow, [uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow, [uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow, [uib-tooltip-popup].tooltip.left-top > .tooltip-arrow, [uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow, [uib-tooltip-popup].tooltip.right-top > .tooltip-arrow, [uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow, [uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow, [uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow, [uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow, [uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow, [uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow, [uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow, [uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow, [uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow, [uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow, [uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow, [uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow, [uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow, [uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow, [uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow, [uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow, [uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow, [uib-popover-popup].popover.top-left > .arrow, [uib-popover-popup].popover.top-right > .arrow, [uib-popover-popup].popover.bottom-left > .arrow, [uib-popover-popup].popover.bottom-right > .arrow, [uib-popover-popup].popover.left-top > .arrow, [uib-popover-popup].popover.left-bottom > .arrow, [uib-popover-popup].popover.right-top > .arrow, [uib-popover-popup].popover.right-bottom > .arrow, [uib-popover-html-popup].popover.top-left > .arrow, [uib-popover-html-popup].popover.top-right > .arrow, [uib-popover-html-popup].popover.bottom-left > .arrow, [uib-popover-html-popup].popover.bottom-right > .arrow, [uib-popover-html-popup].popover.left-top > .arrow, [uib-popover-html-popup].popover.left-bottom > .arrow, [uib-popover-html-popup].popover.right-top > .arrow, [uib-popover-html-popup].popover.right-bottom > .arrow, [uib-popover-template-popup].popover.top-left > .arrow, [uib-popover-template-popup].popover.top-right > .arrow, [uib-popover-template-popup].popover.bottom-left > .arrow, [uib-popover-template-popup].popover.bottom-right > .arrow, [uib-popover-template-popup].popover.left-top > .arrow, [uib-popover-template-popup].popover.left-bottom > .arrow, [uib-popover-template-popup].popover.right-top > .arrow, [uib-popover-template-popup].popover.right-bottom > .arrow {
            top: auto;
            bottom: auto;
            left: auto;
            right: auto;
            margin: 0;
        }

        [uib-popover-popup].popover, [uib-popover-html-popup].popover, [uib-popover-template-popup].popover {
            display: block !important;
        }</style>
    <style type="text/css">.uib-datepicker-popup.dropdown-menu {
            display: block;
            float: none;
            margin: 0;
        }

        .uib-button-bar {
            padding: 10px 9px 2px;
        }</style>
    <style type="text/css">.uib-position-measure {
            display: block !important;
            visibility: hidden !important;
            position: absolute !important;
            top: -9999px !important;
            left: -9999px !important;
        }

        .uib-position-scrollbar-measure {
            position: absolute !important;
            top: -9999px !important;
            width: 50px !important;
            height: 50px !important;
            overflow: scroll !important;
        }

        .uib-position-body-scrollbar-measure {
            overflow: scroll !important;
        }</style>
    <style type="text/css">.uib-datepicker .uib-title {
            width: 100%;
        }

        .uib-day button, .uib-month button, .uib-year button {
            min-width: 100%;
        }

        .uib-left, .uib-right {
            width: 100%
        }</style>
    <style type="text/css">.ng-animate.item:not(.left):not(.right) {
            -webkit-transition: 0s ease-in-out left;
            transition: 0s ease-in-out left
        }</style>
    <style type="text/css">@charset "UTF-8";
        [ng\:cloak], [ng-cloak], [data-ng-cloak], [x-ng-cloak], .ng-cloak, .x-ng-cloak, .ng-hide:not(.ng-hide-animate) {
            display: none !important;
        }

        ng\:form {
            display: block;
        }

        .ng-animate-shim {
            visibility: hidden;
        }

        .ng-anchor {
            position: absolute;
        }</style>
    <title> Buy Car Parts Online — Mister-Auto </title>
    <link rel="canonical" href="https://www.mister-auto.co.uk/">
    <link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.mister-auto.co.uk/">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
          content="Find unbeatable deals for car parts online at Mister-Auto. Brakes, filters, steering and suspension, clutch systems and exterior equipment—for all car lovers!">
    <meta name="keywords" content="car parts, car part, car parts online, buy car parts, buy car parts online">
    <link rel="shortcut icon" href="https://fr-static.cdn.mister-auto.com/img/commun/favicon/favicon.ico">
    <link rel="stylesheet" href="../../public/app/font-awesome.min.css">
    <link href="../../public/app/slick.min.css" media="screen" rel="stylesheet"
          type="text/css">
    <link href="../../public/app/slick-theme.min.css" media="screen" rel="stylesheet"
          type="text/css">
    <link href="../../public/app/bootstrap-select.min.css" media="screen" rel="stylesheet"
          type="text/css">
    <link href="../../public/app/bootstrap-multiselect.min.css" media="screen"
          rel="stylesheet" type="text/css">
    <link href="../../public/app/jquery.fancybox.min.css" media="screen" rel="stylesheet"
          type="text/css">
    <link rel="stylesheet" href="../../public/app/main.css">
    <link rel="stylesheet" href="../../public/app/style.min.css">
    <link rel="stylesheet" href="../../public/app/style.min(1).css">
    <link rel="stylesheet" href="../../public/app/style.min(2).css">
    <link rel="stylesheet" href="../../public/app/style.min(3).css">
    <link rel="stylesheet" href="../../public/app/style.min(4).css">
    <link rel="stylesheet" href="../../public/app/style.min(5).css">
    <link rel="stylesheet" href="../../public/app/style.min(6).css">
    <link rel="stylesheet" href="../../public/app/style.min(7).css">
    <link rel="stylesheet" href="../../public/app/style.min(8).css">
    <link rel="stylesheet" href="../../public/app/styles.min.css">
    <link rel="stylesheet" href="../../public/app/styles.min(1).css">
    <link rel="stylesheet" href="../../public/app/style.min(9).css">
    <link rel="stylesheet" href="../../public/app/style.min(10).css">
    <link rel="stylesheet" href="../../public/app/style.min(11).css">
    <link rel="stylesheet" href="../../public/app/style.min(12).css">
    <link rel="stylesheet" href="../../public/app/style.min(13).css">
    <link rel="stylesheet" href="../../public/app/style.min(14).css">
    <link rel="stylesheet" href="../../public/app/styles.min(2).css">
    <link rel="stylesheet" href="../../public/app/style.min(15).css">
    <link rel="alternate" href="https://www.mister-auto.com/" hreflang="x-default">
    <link rel="alternate" href="https://www.mister-auto.com/" hreflang="fr-FR">
    <link rel="alternate" href="https://www.mister-auto.nl/" hreflang="nl-NL">
    <link rel="alternate" href="https://www.mister-auto.be/fr/" hreflang="fr-BE">
    <link rel="alternate" href="https://www.mister-auto.be/fl/" hreflang="nl-BE">
    <link rel="alternate" href="https://www.mister-auto.lu/fr/" hreflang="fr-LU">
    <link rel="alternate" href="https://www.mister-auto.lu/de/" hreflang="de-LU">
    <link rel="alternate" href="https://www.mister-auto.de/" hreflang="de-DE">
    <link rel="alternate" href="https://www.mister-auto.at/" hreflang="de-AT">
    <link rel="alternate" href="https://www.mister-auto.es/" hreflang="es-ES">
    <link rel="alternate" href="https://www.mister-auto.it/" hreflang="it-IT">
    <link rel="alternate" href="https://www.mister-auto.co.uk/" hreflang="en-GB">
    <link rel="alternate" href="https://www.mister-auto.se/" hreflang="sv-SE">
    <link rel="alternate" href="https://www.mister-auto.dk/" hreflang="da-DK">
    <link rel="alternate" href="https://www.mister-auto.fi/" hreflang="fi-FI">
    <link rel="alternate" href="https://www.mister-auto.pt/" hreflang="pt-PT">
    <link rel="alternate" href="https://www.mister-auto.ie/" hreflang="en-IE">
    <link rel="alternate" href="https://www.mister-auto.gr/" hreflang="el-GR">
    <link rel="alternate" href="https://www.mister-auto.no/" hreflang="no-NO">
    <link rel="alternate" href="https://www.mister-auto.ch/fr/" hreflang="fr-CH">
    <link rel="alternate" href="https://www.mister-auto.ch/de/" hreflang="de-CH">
    <link rel="alternate" href="https://www.mister-auto.re/" hreflang="fr-RE">
    <link rel="alternate" href="https://www.mister-auto.gp/" hreflang="fr-GP">
    <link rel="alternate" href="https://www.mister-auto.mq/" hreflang="fr-MQ">
    <link rel="alternate" href="https://www.mister-auto.gf/" hreflang="fr-GF">
    <meta property="og:description"
          content="Find unbeatable deals for car parts online at Mister-Auto. Brakes, filters, steering and suspension, clutch systems and exterior equipment—for all car lovers!">
    <meta property="og:title" content="Buy Car Parts Online — Mister-Auto">
    <meta property="og:url" content="https://www.mister-auto.co.uk">
    <meta property="og:image"
          content="https://static.cdn.mister-auto.com/front/commons/misterauto/img/ma-social-logo.png">
    <meta property="fb:app_id" content="1493951624164660">
    <meta property="og:site_name" content="Mister-Auto">
</head>
<body ng-app="dataApp" class="route-745 type-page-homepage ng-scope">
<script type="text/javascript" async="" src="../../public/app/ec.js"></script>

<script src="../../public/app/bat.js" async=""></script>
<script type="text/javascript" async="" charset="UTF-8"
        src="../../public/app/sr-misterauto.js"></script>
<noscript>
    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P9RFHN" height="0" width="0"
            sandbox="allow-scripts allow-same-origin" style="display:none;visibility:hidden"></iframe>
</noscript>

<header id="main-header">

    <div id="header-links-row">
        <div class="container">
            <div class="row">
                <div class="col-xs-6"></div>
                <div class="col-xs-6">
                    <ul id="header-links" class="pull-right">
                        <li>
                            <script type="text/javascript"> var headerWelcome = "Welcome",
                                    headerWelcomeLinkUrl = "disconnection.html",
                                    headerWelcomeLinkLabel = "Sign out";</script>
                            <div id="header-client-info"></div>
                        </li>
                        <li class="header-new-account"><a href="https://www.mister-auto.co.uk/newaccount.html"
                                                          rel="nofollow">Create a new customer account <i
                                    class="mf mf-arrow-right"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div id="header-content-row" class="row">
            <div id="header-logo" class="col-md-2 col-xs-3">
                <div class="row"><a href="https://www.mister-auto.co.uk/"> <img
                            src="../../public/app/logo-mister-auto.svg" alt="Logo Mister-auto">
                    </a></div>
            </div>
            <div id="header-info" class="col-md-6 col-xs-9">
                <script type="text/javascript"> var searchUrl = "https://www.mister-auto.co.uk/search/";
                    var transCategories = "Categories", transBrands = "Brands", transProducts = "Products",
                        deleteButton = "Delete", seeMoreProducts = "Show all", transRef = "Ref:";
                    var appId = "ALG19O0IEK", searchKey = "a55d921ec94745696eaec4a1a9bdf4b0",
                        indexName = "prod_monoindex_GBen", searchPage = "1";</script>
                <div id="algolia-search-box-vehicle" class="algolia-search-box-vehicle"></div>
                <div class="algolia-search-box-wrapper">
                    <div class="algolia-search-box">
                        <div id="inputfield">
                            <div class="algolia-autocomplete"><span class="algolia-autocomplete"
                                                                    style="position: relative; display: inline-block; direction: ltr;"><input
                                        autocomplete="off" name="address"
                                        placeholder="Search for a product, a reference or a brand" spellcheck="false"
                                        class="aa-input" dir="auto" type="text" data-selenium="input_algolia_search"
                                        role="combobox" aria-autocomplete="both" aria-expanded="false"
                                        aria-owns="algolia-autocomplete-listbox-0"
                                        style="position: relative; vertical-align: top;"><pre aria-hidden="true"
                                                                                              style="position: absolute; visibility: hidden; white-space: pre; font-family: &quot;Open Sans&quot;, Arial, verdana, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 700; word-spacing: 0px; letter-spacing: 0px; text-indent: 0px; text-rendering: auto; text-transform: none;"></pre></span>
                            </div>
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="mf mf-search"
                                                                                 data-selenium="btn_algolia_search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="algolia-autocomplete-container" style="position: relative;"><span
                            class="aa-dropdown-menu" role="listbox" id="algolia-autocomplete-listbox-0"
                            style="position: absolute; top: 0px; left: 0px; z-index: 100; display: none; right: auto;"><div
                                class="container"><div class="row"><div class="col-sm-6"><div
                                            class="aa-dataset-category"></div><div class="aa-dataset-manufacturer"></div></div><div
                                        class="aa-dataset-product col-sm-6"></div></div></div></span></div>
                </div>
            </div>
            <div id="header-customer" class="col-sm-4 col-xs-12">
                <div class="row">
                    <div class="col-xs-6">
                        <div class="row"><a class="header-customer-account"
                                            href="../../public/login/login.html" rel="nofollow"
                                            title="Log in"> <i class="mf mf-my-account"></i> <span
                                    class="header-customer-label" id="account">Log in</span> </a></div>
                    </div>
                    <div class="col-xs-6 cart-tooltip ng-scope" ng-controller="cartTooltipController as $ctrl"
                         ng-mouseenter="false" ng-mouseleave="true">
                        <div class="row default"><a id="header-customer-cart"
                                                    href="https://www.mister-auto.co.uk/basket/" rel="nofollow"
                                                    title="Basket"> <i id="basket-icon" class="mf mf-shopping-cart2">
                                    <!-- ngIf: ngCart.load() && ngCart.getTotalItems() > 0 --></i> <span
                                    class="header-customer-label">Basket</span> </a> <!-- ngIf: ngCart.load() -->
                            <div class="cart-tooltip-content ng-scope ng-hide" ng-hide="$ctrl.tooltipHide"
                                 ng-if="ngCart.load()">
                                <div class="inner">
                                    <div class="cart-tooltip-header">Basket</div> <!-- ngIf: !ngCart.isEmpty() -->
                                    <!-- ngIf: ngCart.isEmpty() -->
                                    <div class="cart-tooltip-empty ng-scope" ng-if="ngCart.isEmpty()">Your cart is
                                        empty
                                    </div><!-- end ngIf: ngCart.isEmpty() --> </div>
                            </div><!-- end ngIf: ngCart.load() --> </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<nav id="main-menu" class="navbar navbar-default content-flex">
    <div class="container">
        <div class="row">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#main-navbar-collapse" aria-expanded="false"><span class="icon-bar"></span> <span
                        class="icon-bar"></span> <span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="main-navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="visible-xs visible-sm"><a href="https://www.mister-auto.co.uk/car-parts/">Car Parts</a>
                    </li>
                    <li class="visible-xs visible-sm"><a href="https://www.mister-auto.co.uk/car-accessories/">Accessories
                            and maintenance</a></li>
                    <li class="visible-xs visible-sm"><a href="https://www.mister-auto.co.uk/tyres/">Tyres</a></li>
                    <li class="visible-xs visible-sm"><a href="https://www.mister-auto.co.uk/engine-oil_lg3224/">Engine
                            oil</a></li>
                    <li class="visible-xs visible-sm"><a href="https://www.mister-auto.co.uk/snow-chains/">Snow
                            Chains</a></li>
                    <li class="visible-md visible-lg dropdown desktop-menu-dropdown"><a
                            href="https://www.mister-auto.co.uk/car-parts/">Car Parts <i
                                class="mf mf-arrow-down"></i></a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="container">
                                    <div class="row">
                                        <nav id="sub-menu">
                                            <div id="sub-menu-top-sections" class="col-md-3">
                                                <div class="row">
                                                    <div class="col-xs-12 sub-menu-block-title"><i
                                                            class="mf mf-winter"></i> <span>Winter's Best Sellers</span>
                                                    </div>
                                                    <div class="col-xs-12">
                                                        <div class="sub-menu-block-list">
                                                            <ul class="sub-menu-default-list">
                                                                <li><i class="mf mf-gen_3224"></i> <a
                                                                        href="https://www.mister-auto.co.uk/engine-oil_lg3224/"
                                                                        title="Engine Oil"> Engine Oil </a></li>
                                                                <li><i class="mf mf-gen_298"></i> <a
                                                                        href="https://www.mister-auto.co.uk/wiper-blades_lg298/"
                                                                        title="Wiper Blades"> Wiper Blades </a></li>
                                                                <li><i class="mf mf-gen_900005"></i> <a
                                                                        href="https://www.mister-auto.co.uk/disc-brakes_lf56/"
                                                                        title="Pads &amp; Discs"> Pads &amp; Discs </a>
                                                                </li>
                                                                <li><i class="mf mf-pneus"></i> <a
                                                                        href="https://www.mister-auto.co.uk/tyres/"
                                                                        title="Tyres"> Tyres </a></li>
                                                            </ul>
                                                            <ul class="sub-menu-winter-list">
                                                                <li><i class="mf mf-gen_90078"></i> <a
                                                                        href="https://www.mister-auto.co.uk/snow-chains/"
                                                                        title="Snow Chains"> Snow Chains </a></li>
                                                                <li><i class="mf mf-gen_243"></i> <a
                                                                        href="https://www.mister-auto.co.uk/glow-plug_lg243/"
                                                                        title="Glow Plug"> Glow Plug </a></li>
                                                                <li><i class="mf mf-gen_686"></i> <a
                                                                        href="https://www.mister-auto.co.uk/spark-plugs_lg686/"
                                                                        title="Spark Plugs"> Spark Plugs </a></li>
                                                                <li><i class="mf mf-gen_5032"></i> <a
                                                                        href="https://www.mister-auto.co.uk/boot-struts_lg219/"
                                                                        title="Boot Struts"> Boot Struts </a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="sub-menu-main-sections" class="col-md-9">
                                                <div class="row">
                                                    <div class="col-xs-12">
                                                        <ul class="row sub-menu-main-sections-list">
                                                            <li class="sub-menu-block col-xs-4">
                                                                <div class="sub-menu-block-title"><i
                                                                        class="mf mf-cat_10"></i> <a
                                                                        href="https://www.mister-auto.co.uk/brake-parts_lc10/"
                                                                        title="Brake Parts"> Brake Parts </a></div>
                                                                <div class="sub-menu-block-list">
                                                                    <ul>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/brake-pads_lg900005/"
                                                                                title="Brake Pads"
                                                                                data-selenium="link_front_generic">
                                                                                Brake Pads </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/brake-discs_lg900007/"
                                                                                title="Brake Discs"
                                                                                data-selenium="link_front_generic">
                                                                                Brake Discs </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/caliper_lg78/"
                                                                                title="Brake Calipers"
                                                                                data-selenium="link_front_generic">
                                                                                Brake Calipers </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/brake-kit-drum-brakes_lg3859/"
                                                                                title="Drum Brake Kit"
                                                                                data-selenium="link_front_generic"> Drum
                                                                                Brake Kit </a></li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                            <li class="sub-menu-block col-xs-4">
                                                                <div class="sub-menu-block-title"><i
                                                                        class="mf mf-suspensions"></i> <a
                                                                        href="https://www.mister-auto.co.uk/steering-and-suspension_lc13/"
                                                                        title="Steering Components"> Steering
                                                                        Components </a></div>
                                                                <div class="sub-menu-block-list">
                                                                    <ul>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/front-shock-absorber_lg900001/"
                                                                                title="Shock Absorbers"
                                                                                data-selenium="link_front_generic">
                                                                                Shock Absorbers </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/anti-roll-bar_lg3229/"
                                                                                title="Anti Roll Bars"
                                                                                data-selenium="link_front_generic"> Anti
                                                                                Roll Bars </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/suspension-arm-track-control-arm_lg273/"
                                                                                title="Suspension Arm"
                                                                                data-selenium="link_front_generic">
                                                                                Suspension Arm </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/wheel-bearing_lg654/"
                                                                                title="Wheel Bearings"
                                                                                data-selenium="link_front_generic">
                                                                                Wheel Bearings </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/tie-rod-end-track-rod-end_lg914/"
                                                                                title="Tie Rod Ends"
                                                                                data-selenium="link_front_generic"> Tie
                                                                                Rod Ends </a></li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                            <li class="sub-menu-block col-xs-4">
                                                                <div class="sub-menu-block-title"><i
                                                                        class="mf mf-cat_5"></i> <a
                                                                        href="https://www.mister-auto.co.uk/engine-compartment_lc5/"
                                                                        title="Engine Components"> Engine
                                                                        Components </a></div>
                                                                <div class="sub-menu-block-list">
                                                                    <ul>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/timing-belt-kit_lg307/"
                                                                                title="Timing Belt Kit"
                                                                                data-selenium="link_front_generic">
                                                                                Timing Belt Kit </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/drive-belts_lf1553/"
                                                                                title="Drive Belts"
                                                                                data-selenium="link_front_generic">
                                                                                Drive Belts </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/ignition_lf23/"
                                                                                title="Ignition Components"
                                                                                data-selenium="link_front_generic">
                                                                                Ignition Components </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/ignition-coil_lg689/"
                                                                                title="Ignition Coil"
                                                                                data-selenium="link_front_generic">
                                                                                Ignition Coil </a></li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                        <ul class="row sub-menu-main-sections-list">
                                                            <li class="sub-menu-block col-xs-4">
                                                                <div class="sub-menu-block-title"><i
                                                                        class="mf mf-cat_9"></i> <a
                                                                        href="https://www.mister-auto.co.uk/filters_lf55/"
                                                                        title="Filters"> Filters </a></div>
                                                                <div class="sub-menu-block-list">
                                                                    <ul>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/air-filter_lg8/"
                                                                                title="Air Filter"
                                                                                data-selenium="link_front_generic"> Air
                                                                                Filter </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/oil-filter_lg7/"
                                                                                title="Oil Filter"
                                                                                data-selenium="link_front_generic"> Oil
                                                                                Filter </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/fuel-filter_lg9/"
                                                                                title="Fuel Filter"
                                                                                data-selenium="link_front_generic"> Fuel
                                                                                Filter </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/pollen-filter-cabin-air-filter_lg424/"
                                                                                title="Pollen Filter"
                                                                                data-selenium="link_front_generic">
                                                                                Pollen Filter </a></li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                            <li class="sub-menu-block col-xs-4">
                                                                <div class="sub-menu-block-title"><i
                                                                        class="mf mf-fam_13"></i>
                                                                    <div>
                                                                        <a href="https://www.mister-auto.co.uk/clutch_lf27/"
                                                                           title="Clutch Systems "> Clutch Systems
                                                                            <span> / </span> </a> <a
                                                                            href="https://www.mister-auto.co.uk/transmission-parts_lf13/"
                                                                            title=" Transmission Parts"> Transmission
                                                                            Parts </a></div>
                                                                </div>
                                                                <div class="sub-menu-block-list">
                                                                    <ul>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/clutch-kit_lg479/"
                                                                                title="Clutch Kit"
                                                                                data-selenium="link_front_generic">
                                                                                Clutch Kit </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/flywheel_lg577/"
                                                                                title="Clutch Flywheels"
                                                                                data-selenium="link_front_generic">
                                                                                Clutch Flywheels </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/drive-shaft_lg13/"
                                                                                title="Drive Shafts"
                                                                                data-selenium="link_front_generic">
                                                                                Drive Shafts </a></li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                            <li class="sub-menu-block col-xs-4">
                                                                <div class="sub-menu-block-title"><i
                                                                        class="mf mf-pot-echappement"></i> <a
                                                                        href="https://www.mister-auto.co.uk/exhaust_lf36/"
                                                                        title="Exhaust Silencers"> Exhaust
                                                                        Silencers </a></div>
                                                                <div class="sub-menu-block-list">
                                                                    <ul>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/end-silencer_lg3437/"
                                                                                title="Exhaust End Silencers"
                                                                                data-selenium="link_front_generic">
                                                                                Exhaust End Silencers </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/catalytic-converter_lg429/"
                                                                                title="Catalytic Converter"
                                                                                data-selenium="link_front_generic">
                                                                                Catalytic Converter </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/egr-valve_lg1145/"
                                                                                title="EGR Valve"
                                                                                data-selenium="link_front_generic"> EGR
                                                                                Valve </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/lambda-sensor_lg3922/"
                                                                                title="Lambda Sensor"
                                                                                data-selenium="link_front_generic">
                                                                                Lambda Sensor </a></li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                        <ul class="row sub-menu-main-sections-list">
                                                            <li class="sub-menu-block col-xs-4">
                                                                <div class="sub-menu-block-title"><i
                                                                        class="mf mf-fam_62"></i> <a
                                                                        href="https://www.mister-auto.co.uk/engine-cooling_lc11/"
                                                                        title="Engine Cooling Parts"> Engine Cooling
                                                                        Parts </a></div>
                                                                <div class="sub-menu-block-list">
                                                                    <ul>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/water-pump_lg1260/"
                                                                                title="Water Pump"
                                                                                data-selenium="link_front_generic">
                                                                                Water Pump </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/radiator_lg470/"
                                                                                title="Car Radiator"
                                                                                data-selenium="link_front_generic"> Car
                                                                                Radiator </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/radiator-fan_lg508/"
                                                                                title="Radiator Fan"
                                                                                data-selenium="link_front_generic">
                                                                                Radiator Fan </a></li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                            <li class="sub-menu-block col-xs-4">
                                                                <div class="sub-menu-block-title"><i
                                                                        class="mf mf-gear"></i>
                                                                    <span> Other Parts </span></div>
                                                                <div class="sub-menu-block-list">
                                                                    <ul>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/alternator_lg4/"
                                                                                title="Alternator"
                                                                                data-selenium="link_front_generic">
                                                                                Alternator </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/starter-motor_lg2/"
                                                                                title="Starter Motors"
                                                                                data-selenium="link_front_generic">
                                                                                Starter Motors </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/front-window-regulator_lg900003/"
                                                                                title="Window Regulator"
                                                                                data-selenium="link_front_generic">
                                                                                Window Regulator </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/lighting-signalling_lf44/"
                                                                                title="Lights and Signal Parts"
                                                                                data-selenium="link_front_generic">
                                                                                Lights and Signal Parts </a></li>
                                                                        <li><i class="mf mf-triangle_droite"></i> <a
                                                                                href="https://www.mister-auto.co.uk/light-bulbs_lf41/"
                                                                                title="Light Bulbs"
                                                                                data-selenium="link_front_generic">
                                                                                Light Bulbs </a></li>
                                                                    </ul>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div id="sub-menu-link-more" class="pull-right"><a
                                                            href="https://www.mister-auto.co.uk/car-parts/"> + Car Parts
                                                            Catalogue </a></div>
                                                </div>
                                            </div>
                                        </nav>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="visible-md visible-lg"><a href="https://www.mister-auto.co.uk/tyres/">Tyres</a></li>
                    <li class="visible-md visible-lg"><a href="https://www.mister-auto.co.uk/snow-chains/">Snow
                            Chains</a></li>
                    <li class="visible-md visible-lg"><a href="https://www.mister-auto.co.uk/wiper-blades_lg298/">Wiper
                            Blades</a></li>
                    <li class="visible-md visible-lg"><a href="https://www.mister-auto.co.uk/engine-oil_lg3224/">Engine
                            oil</a></li>
                    <li class="visible-md visible-lg"><a href="https://www.mister-auto.co.uk/car-accessories/">Accessories
                            and maintenance</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<script type="text/javascript"> var headerMyAccount = "My account";
    var headerMyAccountUrl = "/myaccount/";
    var menuDesktopLogin = "Log in";</script>
<div>
    <div class="container homepage-template body-container">
        <div class="row tpl-row tpl-blockchoice">
            <div class="col-md-4 col-sm-6 col-xs-12 col-region-choice">
                <div class="homepage-selector">
                    <div class="container-homepage-selector"><h1 class="selector-title">Find your car parts</h1>
                        <ul class="nav nav-pills">
                            <li class="active"><a data-toggle="pill" href="https://www.mister-auto.co.uk/#tab1"
                                                  data-selenium="btn_model_veh"> <i class="mf mf-car3"></i> </a></li>
                            <li><a data-toggle="pill" href="https://www.mister-auto.co.uk/#tab3"
                                   data-selenium="btn_model_ref"> <i class="mf mf-reference"></i> Reference </a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="tab1" class="tab-pane fade in active">
                                <div class="title">
                                    <div class="ui-with-params" ng-show="1"><span class="small-grey-bold"> By registration number </span>
                                    </div>
                                </div>
                                <script> var plateDevice = "desktop";</script>
                                <div class="plate form-with-flag clearfix ng-scope" ng-controller="plateCtrl">
                                    <form ng-submit="plateSubmit(immatriculation, 1429432226)" autocomplete="off"
                                          class="msearch-immatriculation ng-pristine ng-invalid ng-invalid-recaptcha">
                                        <div class="row">
                                            <div class="col-md-12 clearfix">
                                                <div class="immat-area-wrapper">
                                                    <div class="left_side element"><span
                                                            class="mf mf-plaque-immat-GB"></span></div>
                                                    <div class="middle_side element negative-margin"><input
                                                            ng-model="immatriculation" data-selenium="input_model_immat"
                                                            type="text" placeholder="YOUR REG" name="plate-number"
                                                            class="custom-immat-area ng-pristine ng-untouched ng-valid ng-empty">
                                                    </div>
                                                    <div class="right_side element negative-margin"></div>
                                                </div>
                                                <div class="validate">
                                                    <button type="submit" ng-disabled="!immatriculation"
                                                            data-selenium="btn_ok_plate" class="active-arrow"
                                                            disabled="disabled">GO
                                                    </button>
                                                </div>
                                                <div vc-recaptcha=""
                                                     key="'6LfOXUMUAAAAAJuAyppW4wewcr79IV_OsV8E8q-h'"
                                                     size="invisible" on-create="setWidgetId(widgetId)"
                                                     on-success="setResponse(response, immatriculation, 1429432226)"
                                                     on-expire="cbExpiration()" badge="inline" lang="en"
                                                     class="ng-isolate-scope">
                                                    <div class="grecaptcha-badge" data-style="inline"
                                                         style="width: 256px; height: 60px; box-shadow: gray 0px 0px 5px;">
                                                        <!--                                                        <div class="grecaptcha-logo">-->
                                                        <!--                                                            <iframe src="app/anchor.html"-->
                                                        <!--                                                                    width="256" height="60" role="presentation"-->
                                                        <!--                                                                    name="a-gh88ze6dbpyk" frameborder="0" scrolling="no"-->
                                                        <!--                                                                    sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe>-->
                                                        <!--                                                        </div>-->
                                                        <!--                                                        <div class="grecaptcha-error"></div>-->
                                                        <!--                                                        <textarea id="g-recaptcha-response" name="g-recaptcha-response"-->
                                                        <!--                                                                  class="g-recaptcha-response"-->
                                                        <!--                                                                  style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <div class="gdpr"><a class="msg">Learn more about this processing and your
                                            rights</a>
                                        <div class="gdpr-txt" style="display: none;"><p>Information is provided for the
                                                purpose of executing the order placed. Such information is intended for
                                                Mister Auto SAS and all the suppliers involved in executing the order. Such
                                                information may be sent outside the European Union and in that case Mister
                                                Auto ensures that the appropriate legal guarantees are put in place.
                                                Personal data are stored for a maximum of 5 years.<br><br> In accordance
                                                with Regulation (EU) No 2016/679, you may access, rectify, exercise your
                                                right to portability, have any of your personal data deleted, request
                                                limitation of the processing of your data and object to the processing of
                                                your personal data by sending a letter to : Mister Auto, Data Protection
                                                Service, 19 Rue Alfred de Musset, 69100 Villeurbanne, France or by
                                                electronic mail to : <a style="color:#0572b7;"
                                                                        href="mailto:dataprotection@mister-atuo.com">dataprotection@mister-auto.com</a>.
                                                Unless such deletion of data, limitation of processing or objection to
                                                processing resulting in Mister Auto being unable to fulfil its legal or
                                                contractual obligations.</p></div>
                                    </div>
                                    <div class="modal plate-modal" id="plateVehicles1429432226" tabindex="-1"
                                         role="dialog">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close"><span aria-hidden="true">×</span>
                                                    </button>
                                                    <div class="modal-title">Select your vehicle</div>
                                                </div>
                                                <div class="modal-body">
                                                    <div ng-show="vehicles.length" class="ng-hide">
                                                        <div ng-show="vehicles.length &lt; 2"
                                                             class="title-founded-vehicle"> Search results
                                                        </div>
                                                        <div ng-show="vehicles.length &gt; 1"
                                                             class="title-founded-vehicle ng-hide"> following your
                                                            search, we have found several vehicles. Please choose yours
                                                            in this list :
                                                        </div> <!-- ngRepeat: vehicle in vehicles --> </div>
                                                    <div ng-show="!vehicles.length">
                                                        <div class="title-founded-vehicle"> No vehicle matches the
                                                            registration number entered.
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <p class="separator"><span>or</span></p>
                                <div class="title">
                                    <div class="ui-with-params" ng-show="1"><span class="small-grey-bold"> Select your vehicle </span>
                                    </div>
                                </div>
                                <div class="vehicle-selector selector"><p class="icon-only"><i class="mf mf-car"></i>
                                    </p>
                                    <div ng-controller="selectorCtrl"
                                         ng-init="onInit(true, false, '', '', 0, 0, 0)"
                                         class="selector-form ng-scope">
                                        <form ng-submit="onSubmit()" autocomplete="off"
                                              class="selector ng-pristine ng-valid">
                                            <div class="select">
                                                <div class="dropdown"><select ng-model="brand_id"
                                                                              data-selenium="select_model_brand"
                                                                              ng-change="refreshSeriesModels(brand_id)"
                                                                              class="form-control col-xs-12 ng-pristine ng-untouched ng-valid ng-not-empty"
                                                                              aria-label="Make">
                                                        <option value="false" selected="selected">Make</option>
                                                        <optgroup label="The most common brands">
                                                            <option value="5">AUDI</option>
                                                            <option value="16">BMW</option>
                                                            <option value="21">CITROEN</option>
                                                            <option value="35">FIAT</option>
                                                            <option value="36">FORD</option>
                                                            <option value="74">MERCEDES-BENZ</option>
                                                            <option value="80">NISSAN</option>
                                                            <option value="88">PEUGEOT</option>
                                                            <option value="93">RENAULT</option>
                                                            <option value="111">TOYOTA</option>
                                                            <option value="117">VAUXHALL</option>
                                                            <option value="121">VOLKSWAGEN</option>
                                                        </optgroup>
                                                        <optgroup label="All brands">
                                                            <option value="3854">Abarth</option>
                                                            <option value="2">ALFA ROMEO</option>
                                                            <option value="5">AUDI</option>
                                                            <option value="6">AUSTIN</option>
                                                            <option value="16">BMW</option>
                                                            <option value="138">CHEVROLET</option>
                                                            <option value="20">CHRYSLER</option>
                                                            <option value="21">CITROEN</option>
                                                            <option value="139">DACIA</option>
                                                            <option value="185">DAEWOO</option>
                                                            <option value="25">DAIHATSU</option>
                                                            <option value="29">DODGE</option>
                                                            <option value="4468">DS</option>
                                                            <option value="35">FIAT</option>
                                                            <option value="36">FORD</option>
                                                            <option value="45">HONDA</option>
                                                            <option value="183">HYUNDAI</option>
                                                            <option value="1526">INFINITI</option>
                                                            <option value="54">ISUZU</option>
                                                            <option value="55">IVECO</option>
                                                            <option value="56">JAGUAR</option>
                                                            <option value="882">JEEP</option>
                                                            <option value="184">KIA</option>
                                                            <option value="63">LADA</option>
                                                            <option value="64">LANCIA</option>
                                                            <option value="1820">LAND ROVER</option>
                                                            <option value="842">LEXUS</option>
                                                            <option value="802">LOTUS</option>
                                                            <option value="72">MAZDA</option>
                                                            <option value="74">MERCEDES-BENZ</option>
                                                            <option value="75">MG</option>
                                                            <option value="1523">MINI</option>
                                                            <option value="77">MITSUBISHI</option>
                                                            <option value="80">NISSAN</option>
                                                            <option value="84">OPEL</option>
                                                            <option value="88">PEUGEOT</option>
                                                            <option value="92">PORSCHE</option>
                                                            <option value="93">RENAULT</option>
                                                            <option value="95">ROVER</option>
                                                            <option value="99">SAAB</option>
                                                            <option value="104">SEAT</option>
                                                            <option value="106">SKODA</option>
                                                            <option value="1138">SMART</option>
                                                            <option value="175">SSANGYONG</option>
                                                            <option value="107">SUBARU</option>
                                                            <option value="109">SUZUKI</option>
                                                            <option value="110">Talbot</option>
                                                            <option value="111">TOYOTA</option>
                                                            <option value="117">VAUXHALL</option>
                                                            <option value="121">VOLKSWAGEN</option>
                                                            <option value="120">VOLVO</option>
                                                        </optgroup>
                                                    </select> <i class="mf mf-arrow-down"></i></div>
                                                <div class="dropdown"><select
                                                        ng-disabled="series_models.length &lt; 1 &amp;&amp; '' == 'false'"
                                                        data-selenium="select_model_series" ng-model="model_id"
                                                        ng-change="refreshVehicles(model_id)"
                                                        class="form-control col-xs-12 ng-pristine ng-untouched ng-valid ng-not-empty"
                                                        aria-label="Model"> <!-- ngIf: series_models.length < 1 -->
                                                        <option ng-if="series_models.length &lt; 1" value="false"
                                                                class="ng-scope" selected="selected"></option>
                                                        <!-- end ngIf: series_models.length < 1 -->
                                                        <option value="default">Model</option>
                                                        <!-- ngRepeat: serie in series_models --> </select> <i
                                                        class="mf mf-arrow-down"></i></div>
                                                <div class="dropdown"><select ng-disabled="vehicles.length &lt; 1"
                                                                              data-selenium="select_model_vehicle"
                                                                              ng-model="vehicle_uri"
                                                                              ng-change="setVehicle(vehicle_uri)"
                                                                              class="form-control col-xs-12 ng-pristine ng-untouched ng-valid ng-not-empty"
                                                                              aria-label="Engine and Fuel"
                                                                              disabled="disabled">
                                                        <!-- ngIf: vehicles.length < 1 -->
                                                        <option ng-if="vehicles.length &lt; 1" value="false"
                                                                class="ng-scope" selected="selected"></option>
                                                        <!-- end ngIf: vehicles.length < 1 -->
                                                        <option value="default">Engine and Fuel</option>
                                                        <!-- ngRepeat: (carburant, vehicles_list) in vehicles --> </select>
                                                    <i class="mf mf-arrow-down"></i></div>
                                            </div>
                                            <div class="validate">
                                                <button ng-disabled="vehicle_uri == 'false' || vehicle_uri == 'default'"
                                                        class="btn" type="submit" data-selenium="btn_ok_vehicle"
                                                        disabled="disabled">GO
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div id="tab3" class="tab-pane fade">
                                <div class="refsearch form ng-scope" ng-controller="refSearchCtrl">
                                    <form ng-submit="refSearchSubmit(refoem)" autocomplete="off"
                                          class="ng-pristine ng-valid">
                                        <div class="left-col"><p>Enter the reference for the item</p> <input type="text"
                                                                                                             ng-model="refoem"
                                                                                                             data-selenium="input_product_ref"
                                                                                                             aria-label="refoem"
                                                                                                             name="refoem"
                                                                                                             placeholder="EX: BOL-E011026"
                                                                                                             class="ng-pristine ng-untouched ng-valid ng-empty">
                                        </div>
                                        <div class="right-col">
                                            <button type="submit" data-selenium="btn_ok_product">GO</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-sm-6 col-xs-12 col-region-choice"> <!-- ngIf: image != '' -->
                <div class="old-campaign old-campaign-slider ng-scope" ng-controller="oldCampaignSliderCtrl"
                     ng-if="image != ''">
                    <div id="home-slider" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators"> <!-- ngRepeat: slide in slider -->
                            <li data-target="#home-slider" data-slide-to="0" ng-repeat="slide in slider"
                                ng-class="{'active': item == slider[0]}" class="ng-scope active"></li>
                            <!-- end ngRepeat: slide in slider -->
                            <li data-target="#home-slider" data-slide-to="1" ng-repeat="slide in slider"
                                ng-class="{'active': item == slider[0]}" class="ng-scope"></li>
                            <!-- end ngRepeat: slide in slider --> </ol>
                        <div class="carousel-inner"> <!-- ngRepeat: item in slider track by $index -->
                            <div class="item ng-scope active" ng-repeat="item in slider track by $index"
                                 ng-class="{'active': item == slider[0]}"><a
                                    ng-href="https://www.mister-auto.co.uk/" href="https://www.mister-auto.co.uk/">
                                    <!-- ngIf: item.text_1 --><span class="additional-text ng-binding ng-scope"
                                                                    ng-if="item.text_1">Until Sunday</span>
                                    <!-- end ngIf: item.text_1 --> <img class="sliderImg" data-id="0"
                                                                        src="../../public/app/d_slide_homepage_68430_5bf6cfb51983a.png">
                                </a></div><!-- end ngRepeat: item in slider track by $index -->
                            <div class="item ng-scope" ng-repeat="item in slider track by $index"
                                 ng-class="{'active': item == slider[0]}"><a
                                    ng-href="https://www.mister-auto.co.uk/engine-oil_lg3224.html"
                                    href="https://www.mister-auto.co.uk/engine-oil_lg3224.html">
                                    <!-- ngIf: item.text_1 --> <img class="sliderImg" data-id="1"
                                                                    src="../../public/app/d_slide_homepage_21765_584acdbec15bb.png">
                                </a></div><!-- end ngRepeat: item in slider track by $index --> </div>
                    </div>
                    <script> var oldCampaignType = "slide_homepage";
                        var oldCampaignDevice = "d";
                        var oldCampaignPlatform = "legacy";
                        var oldCampaignGenericId = "0"; </script>
                </div><!-- end ngIf: image != '' --> </div>
        </div>
        <div class="row tpl-row">
            <div class="tpl-region tpl-region-top1 col-md-12">
                <div class="reinsurance row">
                    <div class="col-sm-3">
                        <div class="translation text-with-icon"><i class="mf mf-premium-brand"></i> <span
                                class="reinsurance-label">New and <br>guaranteed parts</span></div>
                        <span class="breaker"></span></div>
                    <div class="col-sm-3">
                        <div class="translation text-with-icon"><i class="mf mf-items-in-stock"></i> <span
                                class="reinsurance-label">1 million<br> parts in stock</span></div>
                        <span class="breaker"></span></div>
                    <div class="col-sm-3">
                        <div class="translation text-with-icon"><i class="mf mf-customers"></i> <span
                                class="reinsurance-label">5 483 813 <br>customers</span></div>
                        <span class="breaker"></span></div>
                    <div class="col-sm-3">
                        <div class="translation text-with-icon"><i class="mf mf-sameday-shipping"></i> <span
                                class="reinsurance-label">Same day shipping</span></div>
                        <span class="breaker"></span></div>
                </div>
            </div>
        </div>
        <div class="row tpl-row">
            <div class="tpl-region tpl-region-top4 col-md-12">
                <div class="row">
                    <div class="title">
                        <div class="ui-with-params" ng-show="1"><h2 class="home-main-section"> Our car brands </h2>
                        </div>
                    </div>
                    <div class="listing slider width-margin">
                        <div class="slider-container slider-slick slick-initialized slick-slider"><i
                                class="mf mf-arrow-left slick-prev-custom slick-arrow" style=""></i>
                            <div class="slick-list draggable">
                                <div class="slick-track"
                                     style="opacity: 1; width: 60000px; transform: translate3d(-840px, 0px, 0px);">
                                    <div class="slick-slide slick-cloned" data-slick-index="-6" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-nissan-v80/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/80.jpg"
                                                                        alt="NISSAN"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="-5" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-peugeot-v88/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/88.jpg"
                                                                        alt="PEUGEOT"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="-4" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-renault-v93/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/93.jpg"
                                                                        alt="RENAULT"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="-3" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-toyota-v111/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/0.jpg"
                                                                        alt="TOYOTA"> <span
                                                        class="brand-name">TOYOTA</span> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="-2" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-vauxhall-v117/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/117.jpg"
                                                                        alt="VAUXHALL"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-volkswagen-v121/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/121.jpg"
                                                                        alt="VOLKSWAGEN"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-current slick-active" data-slick-index="0"
                                         aria-hidden="false">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-audi-v5/" tabindex="0">
                                                    <img class="img-brands" width="70"
                                                         src="../../public/app/5.jpg" alt="AUDI">
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-active" data-slick-index="1" aria-hidden="false">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-bmw-v16/" tabindex="0">
                                                    <img class="img-brands" width="70"
                                                         src="../../public/app/16.jpg" alt="BMW">
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-active" data-slick-index="2" aria-hidden="false">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-citroen-v21/"
                                                    tabindex="0"> <img class="img-brands" width="70"
                                                                       src="../../public/app/21.jpg"
                                                                       alt="CITROEN"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-active" data-slick-index="3" aria-hidden="false">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-fiat-v35/" tabindex="0">
                                                    <img class="img-brands" width="70"
                                                         src="../../public/app/35.jpg" alt="FIAT">
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-active" data-slick-index="4" aria-hidden="false">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-ford-v36/" tabindex="0">
                                                    <img class="img-brands" width="70"
                                                         src="../../public/app/36.jpg" alt="FORD">
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-active" data-slick-index="5" aria-hidden="false">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-mercedes-benz-v74/"
                                                    tabindex="0"> <img class="img-brands" width="70"
                                                                       src="../../public/app/74.jpg"
                                                                       alt="MERCEDES-BENZ"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide" data-slick-index="6" aria-hidden="true" tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-nissan-v80/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/80.jpg"
                                                                        alt="NISSAN"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide" data-slick-index="7" aria-hidden="true" tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-peugeot-v88/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/88.jpg"
                                                                        alt="PEUGEOT"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide" data-slick-index="8" aria-hidden="true" tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-renault-v93/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/93.jpg"
                                                                        alt="RENAULT"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide" data-slick-index="9" aria-hidden="true" tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-toyota-v111/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/0.jpg"
                                                                        alt="TOYOTA"> <span
                                                        class="brand-name">TOYOTA</span> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide" data-slick-index="10" aria-hidden="true" tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-vauxhall-v117/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/117.jpg"
                                                                        alt="VAUXHALL"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide" data-slick-index="11" aria-hidden="true" tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-volkswagen-v121/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/121.jpg"
                                                                        alt="VOLKSWAGEN"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="12" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-audi-v5/" tabindex="-1">
                                                    <img class="img-brands" width="70"
                                                         src="../../public/app/5.jpg" alt="AUDI">
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="13" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-bmw-v16/" tabindex="-1">
                                                    <img class="img-brands" width="70"
                                                         src="../../public/app/16.jpg" alt="BMW">
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="14" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-citroen-v21/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/21.jpg"
                                                                        alt="CITROEN"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="15" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-fiat-v35/" tabindex="-1">
                                                    <img class="img-brands" width="70"
                                                         src="../../public/app/35.jpg" alt="FIAT">
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="16" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-ford-v36/" tabindex="-1">
                                                    <img class="img-brands" width="70"
                                                         src="../../public/app/36.jpg" alt="FORD">
                                                </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="17" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-mercedes-benz-v74/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/74.jpg"
                                                                        alt="MERCEDES-BENZ"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="18" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-nissan-v80/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/80.jpg"
                                                                        alt="NISSAN"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="19" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-peugeot-v88/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/88.jpg"
                                                                        alt="PEUGEOT"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="20" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-renault-v93/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/93.jpg"
                                                                        alt="RENAULT"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="21" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-toyota-v111/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/0.jpg"
                                                                        alt="TOYOTA"> <span
                                                        class="brand-name">TOYOTA</span> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="22" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-vauxhall-v117/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/117.jpg"
                                                                        alt="VAUXHALL"> </a></div>
                                        </div>
                                    </div>
                                    <div class="slick-slide slick-cloned" data-slick-index="23" aria-hidden="true"
                                         tabindex="-1">
                                        <div>
                                            <div class="brand img-only" style="width: 100%; display: inline-block;"><a
                                                    href="https://www.mister-auto.co.uk/parts-volkswagen-v121/"
                                                    tabindex="-1"> <img class="img-brands" width="70"
                                                                        src="../../public/app/121.jpg"
                                                                        alt="VOLKSWAGEN"> </a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <i class="mf mf-arrow-right slick-next-custom slick-arrow" style=""></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="row tpl-row">
                    <div class="col-md-12 col-region-center1">
                        <div class="row tpl-row tpl-bkg">
                            <div class="title">
                                <div class="ui-with-params" ng-show="1"><h2 class="home-main-section"> Our car
                                        parts </h2></div>
                            </div>
                            <div class="treeview categories-img-with-generics-large col-md-12">
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-10"></div>
                                        <strong>Brake Parts</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/brake-pads_lg900005/"
                                                   title="Brake Pads"> Brake Pads </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/brake-discs_lg900007/"
                                                   title="Brake Discs"> Brake Discs </a></li>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/caliper_lg78/"
                                                   title="Brake Caliper"> Brake Caliper </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/brake-drum_lg123/"
                                                   title="Brake Drums"> Brake Drums </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/brake-kit-drum-brakes_lg3859/"
                                                   title="Drum Brake Kit"> Drum Brake Kit </a></li>
                                            <a class="more" href="https://www.mister-auto.co.uk/brake-parts_lc10/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-9"></div>
                                        <strong>Filtering Components</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/oil-filter_lg7/"
                                                   title="Oil Filter"> Oil Filter </a></li>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/air-filter_lg8/"
                                                   title="Air Filter"> Air Filter </a></li>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/fuel-filter_lg9/"
                                                   title="Fuel Filter"> Fuel Filter </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/pollen-filter-cabin-air-filter_lg424/"
                                                   title="Pollen Filter"> Pollen Filter </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/engine-oil_lg3224/"
                                                   title="Engine Oil"> Engine Oil </a></li>
                                            <a class="more" href="https://www.mister-auto.co.uk/filtering_lc9/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-13"></div>
                                        <strong>Steering Components</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/front-shock-absorber_lg900001/"
                                                   title="Shock Absorbers"> Shock Absorbers </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/wheel-bearing_lg654/"
                                                   title="Wheel Bearings"> Wheel Bearings </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/wheel-bearing_lg655/"
                                                   title="WHEEL BEARING"> WHEEL BEARING </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/tie-rod-end-track-rod-end_lg914/"
                                                   title="Tie Rod Ends"> Tie Rod Ends </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/steering-rack_lg286/"
                                                   title="Steering Racks"> Steering Racks </a></li>
                                            <a class="more"
                                               href="https://www.mister-auto.co.uk/steering-and-suspension_lc13/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-2"></div>
                                        <strong>Transmission Systems</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/clutch-kit_lg479/"
                                                   title="Clutch Kit"> Clutch Kit </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/drive-shaft_lg13/"
                                                   title="Drive Shafts"> Drive Shafts </a></li>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/cv-boot_lg193/"
                                                   title="Cv boot"> Cv boot </a></li>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/cv-joint_lg236/"
                                                   title="CV JOINT"> CV JOINT </a></li>
                                            <a class="more"
                                               href="https://www.mister-auto.co.uk/clutch-systems-transmission_lc2/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-617"></div>
                                        <strong>Exterior Parts</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/headlight_lg259/"
                                                   title="Headlights"> Headlights </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/fog-lights_lg289/"
                                                   title="Fog Lights"> Fog Lights </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/wiper-blades_lg298/"
                                                   title="Wiper Blades"> Wiper Blades </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/front-light-bulb_lg107/"
                                                   title="Headlight bulbs"> Headlight bulbs </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/wing-mirror_lg50/"
                                                   title="Wing mirrors"> Wing mirrors </a></li>
                                            <a class="more"
                                               href="https://www.mister-auto.co.uk/exterior-equipment_lc617/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-5"></div>
                                        <strong>Engine Components</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/glow-plug_lg243/"
                                                   title="Glow Plug"> Glow Plug </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/ignition-leads_lg685/"
                                                   title="Ignition Leads"> Ignition Leads </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/spark-plugs_lg686/"
                                                   title="Spark Plugs"> Spark Plugs </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/ignition-coil_lg689/"
                                                   title="Ignition Coil"> Ignition Coil </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/timing-belt_lg306/"
                                                   title="Timing Belts"> Timing Belts </a></li>
                                            <a class="more" href="https://www.mister-auto.co.uk/engine-compartment_lc5/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-6"></div>
                                        <strong>Exhaust System</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/catalytic-converter_lg429/"
                                                   title="Catalytic Converter"> Catalytic Converter </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/end-silencer_lg3437/"
                                                   title="Exhaust End Silencers"> Exhaust End Silencers </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/middle-silencer_lg3436/"
                                                   title="Exhaust Middle Silencers"> Exhaust Middle Silencers </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/diesel-particulate-filter_lg1256/"
                                                   title="Particulate Filter"> Particulate Filter </a></li>
                                            <a class="more" href="https://www.mister-auto.co.uk/exhaust_lc6/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-7"></div>
                                        <strong>Car Electrical Components</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/alternator_lg4/"
                                                   title="Alternator"> Alternator </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/starter-motor_lg2/"
                                                   title="Starter Motors"> Starter Motors </a></li>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/horn_lg297/"
                                                   title="Car horns"> Car horns </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/combination-switch_lg1563/"
                                                   title="Combination swtiches"> Combination swtiches </a></li>
                                            <a class="more"
                                               href="https://www.mister-auto.co.uk/electricity-and-lighting_lc7/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-11"></div>
                                        <strong>Engine Cooling Parts</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/coolant-expansion-tank_lg397/"
                                                   title="Coolant Expansion Tanks"> Coolant Expansion Tanks </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/water-pump_lg1260/"
                                                   title="Water Pump"> Water Pump </a></li>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/radiator_lg470/"
                                                   title="Car Radiator"> Car Radiator </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/radiator-hose_lg475/"
                                                   title="Radiator Hose"> Radiator Hose </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/radiator-fan_lg508/"
                                                   title="Radiator Fan"> Radiator Fan </a></li>
                                            <a class="more" href="https://www.mister-auto.co.uk/engine-cooling_lc11/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-4"></div>
                                        <strong>Heaters</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/heater_lg467/"
                                                   title="Car Heaters"> Car Heaters </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/compressor_lg447/"
                                                   title="Air Conditioning Compressor"> Air Conditioning Compressor </a>
                                            </li>
                                            <li><a role="menuitem" href="https://www.mister-auto.co.uk/condenser_lg448/"
                                                   title="Air Conditioning Condenser"> Air Conditioning Condenser </a>
                                            </li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/evaporator_lg471/"
                                                   title="Air Con Evaporator"> Air Con Evaporator </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/receiver-drier_lg851/"
                                                   title="Air Con Receiver Drier"> Air Con Receiver Drier </a></li>
                                            <a class="more"
                                               href="https://www.mister-auto.co.uk/heating-and-air-conditioning_lc4/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                                <div class="col-md-3 catline">
                                    <div class="category">
                                        <div class="wrapper-logo cat-12"></div>
                                        <strong>Locks and Closures</strong></div>
                                    <div class="container-list">
                                        <ul>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/boot-struts_lg219/"
                                                   title="Boot Struts"> Boot Struts </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/electric-window-motor_lg200/"
                                                   title="Electric Window Motors"> Electric Window Motors </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/electric-window-switch_lg1761/"
                                                   title="Electric Window Switches"> Electric Window Switches </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/car-keys-and-fobs_lg1483/"
                                                   title="Car Keys"> Car Keys </a></li>
                                            <li><a role="menuitem"
                                                   href="https://www.mister-auto.co.uk/steering-lock_lg1367/"
                                                   title="Steering Locks"> Steering Locks </a></li>
                                            <a class="more"
                                               href="https://www.mister-auto.co.uk/locks-and-closures_lc12/"
                                               title="see more products"> See + </a></ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row tpl-row">
                    <div class="col-md-12 tpl-col-left">
                        <div class="row"></div>
                    </div>
                </div>
                <div class="row tpl-row">
                    <div class="col-md-12 col-region-center2">
                        <div class="row tpl-row tpl-bkg">
                            <div class="title">
                                <div class="ui-with-params" ng-show="1"><h2 class="home-main-section"> Our car
                                        OEMs </h2></div>
                            </div>
                            <div class="listing slider width-margin">
                                <div class="slider-container slider-slick slick-initialized slick-slider"><i
                                        class="mf mf-arrow-left slick-prev-custom slick-arrow" style=""></i>
                                    <div class="slick-list draggable">
                                        <div class="slick-track"
                                             style="opacity: 1; width: 60000px; transform: translate3d(-1020px, 0px, 0px);">
                                            <div class="slick-slide slick-cloned" data-slick-index="-6"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/luk_e006/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/006.png"
                                                                title="LuK"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="-5"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/mann-filter_e004/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/004.png"
                                                                title="MANN-FILTER"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="-4"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/monroe_e037/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/037.png"
                                                                title="MONROE"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="-3"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/skf_e050/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/050.png"
                                                                title="SKF"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="-2"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/trw_e161/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/161.png"
                                                                title="TRW"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="-1"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/valeo_e021/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/021.png"
                                                                title="VALEO"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-current slick-active" data-slick-index="0"
                                                 aria-hidden="false">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/bosch_e030/"
                                                            tabindex="0"> <img
                                                                src="../../public/app/030.png"
                                                                title="BOSCH"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-active" data-slick-index="1"
                                                 aria-hidden="false">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/castrol_e207/"
                                                            tabindex="0"> <img
                                                                src="../../public/app/207.png"
                                                                title="CASTROL"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-active" data-slick-index="2"
                                                 aria-hidden="false">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/contitech_e031/"
                                                            tabindex="0"> <img
                                                                src="../../public/app/031.png"
                                                                title="CONTITECH"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-active" data-slick-index="3"
                                                 aria-hidden="false">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/delphi_e089/"
                                                            tabindex="0"> <img
                                                                src="../../public/app/089.png"
                                                                title="DELPHI"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-active" data-slick-index="4"
                                                 aria-hidden="false">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/febi-bilstein_e101/"
                                                            tabindex="0"> <img
                                                                src="../../public/app/101.png"
                                                                title="FEBI BILSTEIN"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-active" data-slick-index="5"
                                                 aria-hidden="false">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/kyb_e085/" tabindex="0">
                                                            <img src="../../public/app/085.png"
                                                                 title="KYB"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide" data-slick-index="6" aria-hidden="true"
                                                 tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/luk_e006/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/006.png"
                                                                title="LuK"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide" data-slick-index="7" aria-hidden="true"
                                                 tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/mann-filter_e004/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/004.png"
                                                                title="MANN-FILTER"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide" data-slick-index="8" aria-hidden="true"
                                                 tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/monroe_e037/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/037.png"
                                                                title="MONROE"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide" data-slick-index="9" aria-hidden="true"
                                                 tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/skf_e050/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/050.png"
                                                                title="SKF"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide" data-slick-index="10" aria-hidden="true"
                                                 tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/trw_e161/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/161.png"
                                                                title="TRW"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide" data-slick-index="11" aria-hidden="true"
                                                 tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/valeo_e021/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/021.png"
                                                                title="VALEO"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="12"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/bosch_e030/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/030.png"
                                                                title="BOSCH"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="13"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/castrol_e207/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/207.png"
                                                                title="CASTROL"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="14"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/contitech_e031/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/031.png"
                                                                title="CONTITECH"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="15"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/delphi_e089/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/089.png"
                                                                title="DELPHI"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="16"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/febi-bilstein_e101/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/101.png"
                                                                title="FEBI BILSTEIN"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="17"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/kyb_e085/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/085.png"
                                                                title="KYB"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="18"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/luk_e006/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/006.png"
                                                                title="LuK"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="19"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/mann-filter_e004/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/004.png"
                                                                title="MANN-FILTER"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="20"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/monroe_e037/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/037.png"
                                                                title="MONROE"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="21"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/skf_e050/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/050.png"
                                                                title="SKF"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="22"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/trw_e161/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/161.png"
                                                                title="TRW"> </a></div>
                                                </div>
                                            </div>
                                            <div class="slick-slide slick-cloned" data-slick-index="23"
                                                 aria-hidden="true" tabindex="-1">
                                                <div>
                                                    <div class="manufacturer img-link"
                                                         style="width: 100%; display: inline-block;"><a
                                                            href="https://www.mister-auto.co.uk/valeo_e021/"
                                                            tabindex="-1"> <img
                                                                src="../../public/app/021.png"
                                                                title="VALEO"> </a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <i class="mf mf-arrow-right slick-next-custom slick-arrow" style=""></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-loader">
    <div class="loader"></div>
</div>
<footer id="main-footer">
    <div class="footer-reinsurance">
        <div class="container">
            <div class="row">
                <div class="reinsurance col-md-3"><i class="mf mf-customer-service"></i> <span>150 experts <br>ready to help you</span>
                </div>
                <div class="reinsurance col-md-3"><i class="mf mf-icon-price-security"></i>
                    <span>Price &amp; safety</span></div>
                <div class="reinsurance col-md-3"><i class="mf mf-sameday-shipping"></i> <span>Same day shipping</span>
                </div>
                <div class="reinsurance col-md-3"><i class="mf mf-easy-return"></i>
                    <span>Easy return <br>for 30 days</span></div>
            </div>
        </div>
    </div>
    <div class="footer-newsletter">
        <div class="container">
            <div class="footer-row row">
                <div class="col-md-6">
                    <div class="footer-block-newsletter">
                        <div class="title">Newsletter</div>
                        <form id="newsletter" method="post" action="https://www.mister-auto.co.uk/newsletter.html"
                              class="ng-pristine ng-valid"><input type="text" value="" name="news[email]"
                                                                  placeholder="Subscribe to the newsletter" id="email">
                            <button class="btn">Register</button>
                        </form>
                    </div>
                </div>
                <div class="col-md-6" id="footer-block-social">
                    <div class="title">Follow Us</div>
                    <div>
                        <ul>
                            <li class="footer-icon-facebook"><a target="_blank" href="http://www.facebook.com/"><i
                                        class="fa fa-facebook-f" aria-hidden="true"></i></a></li>
                            <li class="footer-icon-googleplus"><a target="_blank"
                                                                  href="http://plus.google.com/106818351378009942782?rel=author"><i
                                        class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                            <li class="footer-icon-twitter"><a target="_blank" href="http://twitter.com/misterautoUK"><i
                                        class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li class="footer-icon-youtube"><a target="_blank" href="http://www.youtube.com/"><i
                                        class="fa fa-youtube" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="footer-row row footer-links-row">
            <div class="col-md-3">
                <div class="footer-block-title"><span>You want to order ?</span></div>
                <div class="footer-block-list">
                    <ul>
                        <li><a href="https://www.mister-auto.co.uk/help.html#unit-1">How do I place an order?</a></li>
                        <li><a href="https://www.mister-auto.co.uk/guarantees.html#unit-1">Delivery Information</a></li>
                        <li><a href="https://www.mister-auto.co.uk/guarantees.html#unit-2">Secure Shopping</a></li>
                        <li><a href="https://www.mister-auto.co.uk/myaccount/orders.html">Track your order</a></li>
                        <li><a href="https://www.mister-auto.co.uk/help.html#unit-3">Return and Refund</a></li>
                        <li><a href="https://www.mister-auto.co.uk/contact.html">Contact us</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-block-title"><span>More information</span></div>
                <div class="footer-block-list">
                    <ul>
                        <li><a href="https://www.mister-auto.co.uk/about-us.html">About us</a></li>
                        <li><a href="https://www.mister-auto.co.uk/faq/">Question forum</a></li>
                        <li><a href="https://www.mister-auto.co.uk/newsletter.html">Subscribe to the newsletter</a></li>
                        <li><a href="https://www.mister-auto.co.uk/affiliation.html">Become an affiliate</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-block-title"><span>Makes</span></div>
                <div class="footer-block-list">
                    <div class="listing">
                        <ul class="list">
                            <li><a class="brand-linklabel " href="https://www.mister-auto.co.uk/parts-ford-v36/">
                                    FORD</a></li>
                            <li><a class="brand-linklabel " href="https://www.mister-auto.co.uk/parts-volkswagen-v121/">
                                    VOLKSWAGEN</a></li>
                            <li><a class="brand-linklabel " href="https://www.mister-auto.co.uk/parts-vauxhall-v117/">
                                    VAUXHALL</a></li>
                            <li><a class="brand-linklabel " href="https://www.mister-auto.co.uk/parts-peugeot-v88/">
                                    PEUGEOT</a></li>
                            <li><a class="brand-linklabel " href="https://www.mister-auto.co.uk/parts-renault-v93/">
                                    RENAULT</a></li>
                        </ul>
                    </div>
                    <a href="https://www.mister-auto.co.uk/makes/"><i aria-hidden="true"></i>Makes</a></div>
            </div>
            <div class="col-md-3">
                <div class="footer-block-title"><span>Car part brands</span></div>
                <div class="footer-block-list">
                    <div class="listing">
                        <ul class="list">
                            <li><a class="manufacturer-linklabel " href="https://www.mister-auto.co.uk/trw_e161/">
                                    TRW</a></li>
                            <li><a class="manufacturer-linklabel " href="https://www.mister-auto.co.uk/bosch_e030/">
                                    BOSCH</a></li>
                            <li><a class="manufacturer-linklabel " href="https://www.mister-auto.co.uk/moog_e134/">
                                    MOOG</a></li>
                            <li><a class="manufacturer-linklabel " href="https://www.mister-auto.co.uk/delphi_e089/">
                                    DELPHI</a></li>
                            <li><a class="manufacturer-linklabel "
                                   href="https://www.mister-auto.co.uk/blue-print_e350/"> BLUE PRINT</a></li>
                        </ul>
                    </div>
                    <a href="https://www.mister-auto.co.uk/car-part-suppliers/"><i aria-hidden="true"></i>Brands</a>
                </div>
            </div>
        </div>
        <div class="footer-row row">
            <div class="col-sm-6">
                <div id="footer-block-contact">
                    <div class="contact-us"><strong> Contact us at </strong></div>
                    <span class="load-phone-number">033 08 08 44 09 </span>
                    <div class="schedule">Monday to Friday from 9 am to 5 pm</div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="flags footer-row row flag-module">
                    <div class="default col-md-12 dropup"><p class="flags-title">Mister auto is present in 19
                            countries</p> <a href="https://www.mister-auto.co.uk/#" class="flags-btn dropdown-toggle"
                                             data-toggle="dropdown"> <span class="flag-group"> <span
                                    class="flag flag-GB"></span> <span class="flag-label">United Kingdom</span> <i
                                    class="mf mf-arrow-up"></i> </span> </a>
                        <div class="dropdown-menu"><p class="flags-title">Mister auto is present in 19 countries</p>
                            <ul class="flags">
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.com/';"
                                          style="cursor: pointer;"> <span class="flag flag-FR"></span> <span
                                            class="flag-label">France</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.nl/';"
                                          style="cursor: pointer;"> <span class="flag flag-NL"></span> <span
                                            class="flag-label">Netherlands</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.be/fr/';"
                                          style="cursor: pointer;"> <span class="flag flag-BE"></span> <span
                                            class="flag-label"> Belgium - FR</span> <i class="mf mf-checked"></i> </span>
                                </li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.be/fl/';"
                                          style="cursor: pointer;"> <span class="flag flag-BE"></span> <span
                                            class="flag-label"> Belgium - NL</span> <i class="mf mf-checked"></i> </span>
                                </li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.de/';"
                                          style="cursor: pointer;"> <span class="flag flag-DE"></span> <span
                                            class="flag-label">Germany</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.at/';"
                                          style="cursor: pointer;"> <span class="flag flag-AT"></span> <span
                                            class="flag-label">Austria</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.lu/fr/';"
                                          style="cursor: pointer;"> <span class="flag flag-LU"></span> <span
                                            class="flag-label"> Luxembourg - FR</span> <i class="mf mf-checked"></i> </span>
                                </li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.lu/de/';"
                                          style="cursor: pointer;"> <span class="flag flag-LU"></span> <span
                                            class="flag-label"> Luxembourg - GE</span> <i class="mf mf-checked"></i> </span>
                                </li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.es/';"
                                          style="cursor: pointer;"> <span class="flag flag-ES"></span> <span
                                            class="flag-label">Spain</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.it/';"
                                          style="cursor: pointer;"> <span class="flag flag-IT"></span> <span
                                            class="flag-label">Italy</span> <i class="mf mf-checked"></i> </span></li>
                                <li class="active-flag"><span class="flag-group"
                                                              onclick="window.location='https://www.mister-auto.co.uk/';"
                                                              style="cursor: pointer;"> <span
                                            class="flag flag-GB"></span> <span class="flag-label">United Kingdom</span> <i
                                            class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.ie/';"
                                          style="cursor: pointer;"> <span class="flag flag-IE"></span> <span
                                            class="flag-label">Ireland</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.pt/';"
                                          style="cursor: pointer;"> <span class="flag flag-PT"></span> <span
                                            class="flag-label">Portugal</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.fi/';"
                                          style="cursor: pointer;"> <span class="flag flag-FI"></span> <span
                                            class="flag-label">Finland</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.se/';"
                                          style="cursor: pointer;"> <span class="flag flag-SE"></span> <span
                                            class="flag-label">Sweden</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.dk/';"
                                          style="cursor: pointer;"> <span class="flag flag-DK"></span> <span
                                            class="flag-label">Denmark</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.gr/';"
                                          style="cursor: pointer;"> <span class="flag flag-GR"></span> <span
                                            class="flag-label">Greece</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.ch/fr/';"
                                          style="cursor: pointer;"> <span class="flag flag-CH"></span> <span
                                            class="flag-label"> Swiss - FR</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.ch/de/';"
                                          style="cursor: pointer;"> <span class="flag flag-CH"></span> <span
                                            class="flag-label"> Swiss - GE</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.no/';"
                                          style="cursor: pointer;"> <span class="flag flag-NO"></span> <span
                                            class="flag-label">Norway</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.re/';"
                                          style="cursor: pointer;"> <span class="flag flag-RE"></span> <span
                                            class="flag-label">Reunion</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.gp/';"
                                          style="cursor: pointer;"> <span class="flag flag-GP"></span> <span
                                            class="flag-label">Guadeloupe</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.mq/';"
                                          style="cursor: pointer;"> <span class="flag flag-MQ"></span> <span
                                            class="flag-label">Martinique</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.gf/';"
                                          style="cursor: pointer;"> <span class="flag flag-GF"></span> <span
                                            class="flag-label">Guyana</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.com.br/';"
                                          style="cursor: pointer;"> <span class="flag flag-BR"></span> <span
                                            class="flag-label">Brazil</span> <i class="mf mf-checked"></i> </span></li>
                                <li><span class="flag-group"
                                          onclick="window.location='https://www.mister-auto.ma/';"
                                          style="cursor: pointer;"> <span class="flag flag-MA"></span> <span
                                            class="flag-label">Morocco</span> <i class="mf mf-checked"></i> </span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="footer-versions-row" class="footer-row row">
            <div class="col-sm-12">
                <ul>
                    <li class="active-version"><span> <i class="fa fa-desktop"
                                                         aria-hidden="true"></i>Classic website</span></li>
                    <li><a href="https://m.mister-auto.co.uk/"> <i class="fa fa-mobile" aria-hidden="true"></i> Mobile
                            website </a></li>
                </ul>
            </div>
        </div>
        <div id="review-aggregate" class="row">
            <div itemscope="" itemtype="https://data-vocabulary.org/Review-aggregate"><span itemprop="rating"
                                                                                            itemscope=""
                                                                                            itemtype="https://data-vocabulary.org/Rating"> <span
                        itemprop="average">4.6</span> / <span itemprop="best">5</span> </span> <span> <span
                        class="stars-bg en_GB"> <img src="../../public/app/google-stars.png"
                                                     alt="google_stars"> </span> </span> (based on <span itemprop="votes">1399</span>
                reviews) costumer reviews based on data collected by <a class="google-review"
                                                                        href="https://www.google.fr/shopping/seller?q=mister-auto.co.uk"
                                                                        target="_blank">Google and/or its partners</a>
                <span>for <span itemprop="itemreviewed">mister-auto.co.uk</span></span></div>
        </div>
        <div id="footer-copyright-row" class="footer-row row">
            <div class="col-xs-12 col-md-2">
                <div id="footer-tecdoc-logo"><img src="../../public/app/tecdoc.png"
                                                  alt="Logo TecDoc"></div>
            </div>
            <div class="col-xs-12 col-md-10">
                <div id="footer-tecdoc-copyright"> The data shown here, especially the complete database, may not be
                    copied. It is strictly prohibited to duplicate the data and database and distribute the same, and/or
                    instruct third parties to engage in such activities, without prior consent from TecAlliance. Any use
                    of content in a manner not expressly authorized constitutes copyright infringement and violators
                    will be prosecuted.
                </div>
            </div>
            <div class="col-xs-12">
                <div id="footer-mister-auto-copyright">
                    <ul class="links">
                        <li><a href="https://www.mister-auto.co.uk/cgv.html">Terms&amp;Conditions</a></li>
                        -
                        <li><a href="https://www.mister-auto.co.uk/privacy-policy/">Privacy Policy</a></li>
                        -
                        <li> 2007 - 2018 © Mister Auto</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
var context = {
"isApplication": false,
"device": "desktop",
"userAgent": "Mozilla\/5.0 (X11; Linux i686; rv:8.0) Gecko\/20100101 Firefox\/8.0"
}; </script>
<script type="text/javascript" src="app/jquery.min.js"></script>
<script type="text/javascript" src="../../public/app/bootstrap.min.js"></script>
<!--<script type="text/javascript" src="app/slick.min.js"></script>-->
<script type="text/javascript" src="../../public/app/mustache.min.js"></script>
<script type="text/javascript" src="../../public/app/algoliasearch.min.js"></script>
<script type="text/javascript"
        src="../../public/app/autocomplete.jquery.min.js"></script>

<!--<script type="text/javascript" src="app/tracking.min.js"></script>-->
<script type="text/javascript"
        src="../../public/app/bootstrap-select.min.js"></script>
<script type="text/javascript"
        src="../../public/app/bootstrap-multiselect.min.js"></script>
<script type="text/javascript"
        src="../../public/app/jquery.fancybox.min.js"></script>
<script type="text/javascript" src="../../public/app/rawinflate.min.js"></script>

<script src="../../public/app/script.js"></script>
<script src="../../public/app/obfuscated-links.min.js"></script>
<script src="../../public/app/helpers.min.js"></script>
<script src="../../public/app/cookies.min.js"></script>
<script src="../../public/app/load-phone-number.min.js"></script>
<script src="../../public/app/sticky-selector.min.js"></script>
<script src="../../public/app/oldCampaign.min.js"></script>
<script src="../../public/app/esi.min.js"></script>
<!--<script src="app/client-infos.min.js"></script>-->
<!--<script src="app/script.min.js(1)"></script>-->
<script src="../../public/app/script.min.js(2)"></script>
<script src="../../public/app/script.min.js(3)"></script>
<script src="../../public/app/script.min.js(4)"></script>
<script src="../../public/app/script.min.js(5)"></script>
<script src="../../public/app/script.min.js(6)"></script>
<script src="../../public/app/main.js"></script>
<script src="../../public/app/script.min.js(8)"></script>
<script src="../../public/app/script.min.js(9)"></script>
<script type="application/ld+json">
     { "@context": "https://schema.org", "@id": "https://www.mister-auto.com/#organization" , "@type": "Organization", "name": "Mister-Auto", "url": "https://www.mister-auto.co.uk", "logo": "https://fr-static.cdn.mister-auto.com/img/commun/main/header/logo-ma-grey.png", "contactPoint": [ { "@type": "ContactPoint", "telephone": "+33892181181", "contactType": "customer support", "areaServed": ["GB"] } ], "sameAs": [ "https://www.facebook.com/misterauto.france/", "https://plus.google.com/+misterauto/posts?rel=author", "https://twitter.com/misterauto", "https://www.youtube.com/user/misterautofr", "https://fr.wikipedia.org/wiki/Mister-Auto" ] }
</script>
<script type="application/ld+json">
     { "@context": "https://schema.org", "@id": "https://www.mister-auto.com/#website", "@type": "WebSite", "url": "https://www.mister-auto.co.uk", "name": "Mister-Auto", "potentialAction": { "@type": "SearchAction", "target": "" , "query-input": "" } }
</script>
<span id="check-alive" style="display:none;">832d8e99543c9eb6058233655e7e90e0</span>
<script async="" defer="" src="../../public/app/api.js"></script>
<script type="text/javascript" id="">function srEnsureReady(a) {
        window.srReady ? a() : window.setTimeout(function () {
            srEnsureReady(a)
        }, 50)
    }</script>
<script type="text/javascript" id="">(function (b, c, e, f, d) {
        b[d] = b[d] || [];
        var g = function () {
            var a = {ti: "4021882"};
            a.q = b[d];
            b[d] = new UET(a);
            b[d].push("pageLoad")
        };
        var a = c.createElement(e);
        a.src = f;
        a.async = 1;
        a.onload = a.onreadystatechange = function () {
            var b = this.readyState;
            b && "loaded" !== b && "complete" !== b || (g(), a.onload = a.onreadystatechange = null)
        };
        c = c.getElementsByTagName(e)[0];
        c.parentNode.insertBefore(a, c)
    })(window, document, "script", "//bat.bing.com/bat.js", "uetq");</script>

<noscript>
    <img src="//bat.bing.com/action/0?ti=4021882&amp;Ver=2" height="0" width="0"
         style="display:none; visibility: hidden;">
</noscript>
<script src="../../public/app/f(1).txt"></script>
<div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.4354614772132659"><img
        style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.7194253921338012" width="0"
        height="0" alt="" src="../../public/app/0"></div>
<!--<iframe name="easyXDM_default3431_provider" id="easyXDM_default3431_provider"-->
<!--        src="app/cookie.html" frameborder="0"-->
<!--        style="position: absolute; top: -2000px; left: 0px;"></iframe>-->
<div style="visibility: hidden; position: absolute; width: 100%; top: -10000px; left: 0px; right: 0px; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0;">
    <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255); opacity: 0.5;"></div>

</div>
</body>
</html>
