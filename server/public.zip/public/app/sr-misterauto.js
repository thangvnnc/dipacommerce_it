var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.findInternal = function (a, e, p) {
    a instanceof String && (a = String(a));
    for (var m = a.length, c = 0; c < m; c++) {
        var k = a[c];
        if (e.call(p, k, c, a)) return {i: c, v: k}
    }
    return {i: -1, v: void 0}
};
$jscomp.defineProperty = "function" == typeof Object.defineProperties ? Object.defineProperty : function (a, e, p) {
    if (p.get || p.set) throw new TypeError("ES3 does not support getters and setters.");
    a != Array.prototype && a != Object.prototype && (a[e] = p.value)
};
$jscomp.getGlobal = function (a) {
    return "undefined" != typeof window && window === a ? a : "undefined" != typeof global && null != global ? global : a
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.polyfill = function (a, e, p, m) {
    if (e) {
        p = $jscomp.global;
        a = a.split(".");
        for (m = 0; m < a.length - 1; m++) {
            var c = a[m];
            c in p || (p[c] = {});
            p = p[c]
        }
        a = a[a.length - 1];
        m = p[a];
        e = e(m);
        e != m && null != e && $jscomp.defineProperty(p, a, {configurable: !0, writable: !0, value: e})
    }
};
$jscomp.polyfill("Array.prototype.find", function (a) {
    return a ? a : function (a, p) {
        return $jscomp.findInternal(this, a, p).v
    }
}, "es6-impl", "es3");
$jscomp.SYMBOL_PREFIX = "jscomp_symbol_";
$jscomp.initSymbol = function () {
    $jscomp.initSymbol = function () {
    };
    $jscomp.global.Symbol || ($jscomp.global.Symbol = $jscomp.Symbol)
};
$jscomp.symbolCounter_ = 0;
$jscomp.Symbol = function (a) {
    return $jscomp.SYMBOL_PREFIX + (a || "") + $jscomp.symbolCounter_++
};
$jscomp.initSymbolIterator = function () {
    $jscomp.initSymbol();
    var a = $jscomp.global.Symbol.iterator;
    a || (a = $jscomp.global.Symbol.iterator = $jscomp.global.Symbol("iterator"));
    "function" != typeof Array.prototype[a] && $jscomp.defineProperty(Array.prototype, a, {
        configurable: !0,
        writable: !0,
        value: function () {
            return $jscomp.arrayIterator(this)
        }
    });
    $jscomp.initSymbolIterator = function () {
    }
};
$jscomp.arrayIterator = function (a) {
    var e = 0;
    return $jscomp.iteratorPrototype(function () {
        return e < a.length ? {done: !1, value: a[e++]} : {done: !0}
    })
};
$jscomp.iteratorPrototype = function (a) {
    $jscomp.initSymbolIterator();
    a = {next: a};
    a[$jscomp.global.Symbol.iterator] = function () {
        return this
    };
    return a
};
$jscomp.iteratorFromArray = function (a, e) {
    $jscomp.initSymbolIterator();
    a instanceof String && (a += "");
    var p = 0, m = {
        next: function () {
            if (p < a.length) {
                var c = p++;
                return {value: e(c, a[c]), done: !1}
            }
            m.next = function () {
                return {done: !0, value: void 0}
            };
            return m.next()
        }
    };
    m[Symbol.iterator] = function () {
        return m
    };
    return m
};
$jscomp.polyfill("Array.prototype.keys", function (a) {
    return a ? a : function () {
        return $jscomp.iteratorFromArray(this, function (a) {
            return a
        })
    }
}, "es6-impl", "es3");
$jscomp.checkStringArgs = function (a, e, p) {
    if (null == a) throw new TypeError("The 'this' value for String.prototype." + p + " must not be null or undefined");
    if (e instanceof RegExp) throw new TypeError("First argument to String.prototype." + p + " must not be a regular expression");
    return a + ""
};
$jscomp.polyfill("String.prototype.startsWith", function (a) {
    return a ? a : function (a, p) {
        var e = $jscomp.checkStringArgs(this, a, "startsWith");
        a += "";
        for (var c = e.length, k = a.length, q = Math.max(0, Math.min(p | 0, e.length)), u = 0; u < k && q < c;) if (e[q++] != a[u++]) return !1;
        return u >= k
    }
}, "es6-impl", "es3");
(function (a, e, p, m, c, k) {
    function q(d, a) {
        var r = typeof d[a];
        return "function" == r || !("object" != r || !d[a]) || "unknown" == r
    }

    function u() {
        if (!R) {
            R = !0;
            for (var d = 0; d < S.length; d++) S[d]();
            S.length = 0
        }
    }

    function g(d, a) {
        R ? d.call(a) : S.push(function () {
            d.call(a)
        })
    }

    function v(d) {
        var a = d.toLowerCase().match(O);
        try {
            var c = a[2], r = a[3], e = a[4] || "";
            if ("http:" == c && ":80" == e || "https:" == c && ":443" == e) e = "";
            return c + "//" + r + e
        } catch (Ea) {
            return console.log("url could not be parsed", d), ""
        }
    }

    function z(d, a) {
        var c = "", r = d.indexOf("#");
        -1 !==
        r && (c = d.substring(r), d = d.substring(0, r));
        var r = [], e;
        for (e in a) a.hasOwnProperty(e) && r.push(e + "=" + k(a[e]));
        return d + (C ? "#" : -1 == d.indexOf("?") ? "?" : "&") + r.join("&") + c
    }

    function B(d) {
        return "undefined" === typeof d
    }

    function t(d, a, c) {
        var r, e;
        for (e in a) a.hasOwnProperty(e) && (e in d ? (r = a[e], "object" === typeof r ? t(d[e], r, c) : c || (d[e] = a[e])) : d[e] = a[e]);
        return d
    }

    function A(d) {
        if (B(l)) {
            var a = e.body.appendChild(e.createElement("form")), c = a.appendChild(e.createElement("input"));
            c.name = J + "TEST" + H;
            l = c !== a.elements[c.name];
            e.body.removeChild(a)
        }
        l ? a = e.createElement('<iframe name="' + d.props.name + '"/>') : (a = e.createElement("IFRAME"), a.name = d.props.name);
        a.id = a.name = d.props.name;
        delete d.props.name;
        "string" == typeof d.container && (d.container = e.getElementById(d.container));
        d.container || (t(a.style, {position: "absolute", top: "-2000px", left: "0px"}), d.container = e.body);
        c = d.props.src;
        d.props.src = "javascript:false";
        t(a, d.props);
        a.border = a.frameBorder = 0;
        a.allowTransparency = !0;
        d.container.appendChild(a);
        d.onLoad && E(a, "load", d.onLoad);
        if (d.usePost) {
            var r = d.container.appendChild(e.createElement("form")), g;
            r.target = a.name;
            r.action = c;
            r.method = "POST";
            if ("object" === typeof d.usePost) for (var k in d.usePost) d.usePost.hasOwnProperty(k) && (l ? g = e.createElement('<input name="' + k + '"/>') : (g = e.createElement("INPUT"), g.name = k), g.value = d.usePost[k], r.appendChild(g));
            r.submit();
            r.parentNode.removeChild(r)
        } else a.src = c;
        d.props.src = c;
        return a
    }

    function F(d) {
        var a;
        d.isHost = d.isHost || B(X.xdm_p);
        C = d.hash || !1;
        d.props || (d.props = {});
        if (d.isHost) {
            a = d.remote;
            a = a.replace(Q, "$1/");
            if (!a.match(/^(http||https):\/\//)) {
                var c = "/" === a.substring(0, 1) ? "" : p.pathname;
                "/" !== c.substring(c.length - 1) && (c = c.substring(0, c.lastIndexOf("/") + 1));
                a = p.protocol + "//" + p.host + c + a
            }
            for (; M.test(a);) a = a.replace(M, "");
            d.remote = a;
            d.channel = d.channel || "default" + H++;
            d.secret = Math.random().toString(16).substring(2)
        } else {
            d.channel = X.xdm_c.replace(/["'<>\\]/g, "");
            d.secret = X.xdm_s;
            d.remote = X.xdm_e.replace(/["'<>\\]/g, "");
            if (a = d.acl) {
                a:{
                    a = d.acl;
                    c = d.remote;
                    "string" == typeof a && (a = [a]);
                    for (var e,
                             r = a.length; r--;) if (e = a[r], e = new RegExp("^" == e.substr(0, 1) ? e : "^" + e.replace(/(\*)/g, ".$1").replace(/\?/g, ".") + "$"), e.test(c)) {
                        a = !0;
                        break a
                    }
                    a = !1
                }
                a = !a
            }
            if (a) throw Error("Access denied for " + d.remote);
        }
        d.protocol = "1";
        a = [new G.stack.PostMessageTransport(d)];
        a.push(new G.stack.QueueBehavior({lazy: d.lazy, remove: !0}));
        return a
    }

    function y(d) {
        for (var a, c = {
            incoming: function (d, a) {
                this.up.incoming(d, a)
            }, outgoing: function (d, a) {
                this.down.outgoing(d, a)
            }, callback: function (d) {
                this.up.callback(d)
            }, init: function () {
                this.down.init()
            },
            destroy: function () {
                this.down.destroy()
            }
        }, e = 0, r = d.length; e < r; e++) a = d[e], t(a, c, !0), 0 !== e && (a.down = d[e - 1]), e !== r - 1 && (a.up = d[e + 1]);
        return a
    }

    function D(d) {
        d.up.down = d.down;
        d.down.up = d.up;
        d.up = d.down = null
    }

    var H = Math.floor(1E4 * Math.random()), O = /^((http.?:)\/\/([^:\/\s]+)(:\d+)*)/, M = /[\-\w]+\/\.\.\//,
        Q = /([^:])\/\//g, V = "", G = {}, N = a.easyXDM, J = "easyXDM_", l, C = !1, E, w;
    if (q(a, "addEventListener")) E = function (d, a, c) {
        d.addEventListener(a, c, !1)
    }, w = function (d, a, c) {
        d.removeEventListener(a, c, !1)
    }; else if (q(a, "attachEvent")) E =
        function (d, a, c) {
            d.attachEvent("on" + a, c)
        }, w = function (d, a, c) {
        d.detachEvent("on" + a, c)
    }; else throw Error("Browser not supported");
    var R = !1, S = [], d;
    "readyState" in e ? (d = e.readyState, R = "complete" == d || ~navigator.userAgent.indexOf("AppleWebKit/") && ("loaded" == d || "interactive" == d)) : R = !!e.body;
    if (!R) {
        if (q(a, "addEventListener")) E(e, "DOMContentLoaded", u); else if (E(e, "readystatechange", function () {
            "complete" == e.readyState && u()
        }), e.documentElement.doScroll && a === top) {
            var U = function () {
                if (!R) {
                    try {
                        e.documentElement.doScroll("left")
                    } catch (r) {
                        m(U,
                            1);
                        return
                    }
                    u()
                }
            };
            U()
        }
        E(a, "load", u)
    }
    var X = function (d) {
        d = d.substring(1).split("&");
        for (var a = {}, e, r = d.length; r--;) e = d[r].split("="), a[e[0]] = c(e[1]);
        return a
    }(/xdm_e=/.test(p.search) ? p.search : p.hash), Y = function () {
        var d = {}, a = {a: [1, 2, 3]};
        if ("undefined" != typeof JSON && "function" === typeof JSON.stringify && '{"a":[1,2,3]}' === JSON.stringify(a).replace(/\s/g, "")) return JSON;
        Object.toJSON && '{"a":[1,2,3]}' === Object.toJSON(a).replace(/\s/g, "") && (d.stringify = Object.toJSON);
        "function" === typeof String.prototype.evalJSON &&
        (a = '{"a":[1,2,3]}'.evalJSON(), a.a && 3 === a.a.length && 3 === a.a[2] && (d.parse = function (d) {
            return d.evalJSON()
        }));
        return d.stringify && d.parse ? (Y = function () {
            return d
        }, d) : null
    };
    t(G, {
        version: "2.4.18.25",
        query: X,
        stack: {},
        apply: t,
        getJSONObject: Y,
        whenReady: g,
        noConflict: function (d) {
            a.easyXDM = N;
            (V = d) && (J = "easyXDM_" + V.replace(".", "_") + "_");
            return G
        }
    });
    G.DomHelper = {
        on: E, un: w, requiresJSON: function (d) {
            "object" == typeof a.JSON && a.JSON || e.write('<script type="text/javascript" src="' + d + '">\x3c/script>')
        }
    };
    (function () {
        var d =
            {};
        G.Fn = {
            set: function (a, c) {
                d[a] = c
            }, get: function (a, c) {
                var e = d[a];
                c && delete d[a];
                return e
            }
        }
    })();
    G.Socket = function (d) {
        var a = y(F(d).concat([{
            incoming: function (a, c) {
                d.onMessage(a, c)
            }, callback: function (a) {
                if (d.onReady) d.onReady(a)
            }
        }])), c = v(d.remote);
        this.origin = v(d.remote);
        this.destroy = function () {
            a.destroy()
        };
        this.postMessage = function (d) {
            a.outgoing(d, c)
        };
        a.init()
    };
    G.stack.PostMessageTransport = function (d) {
        function c(a) {
            var c;
            if (a.origin) c = v(a.origin); else if (a.uri) c = v(a.uri); else if (a.domain) c = p.protocol +
                "//" + a.domain; else throw"Unable to retrieve the origin of the event";
            c == r && a.data.substring(0, d.channel.length + 1) == d.channel + " " && e.up.incoming(a.data.substring(d.channel.length + 1), c)
        }

        var e, l, k, r;
        return e = {
            outgoing: function (a, c, e) {
                try {
                    k.postMessage(d.channel + " " + a, c || r), e && e()
                } catch (Z) {
                }
            }, destroy: function () {
                w(a, "message", c);
                l && (k = null, l.parentNode.removeChild(l), l = null)
            }, onDOMReady: function () {
                r = v(d.remote);
                if (d.isHost) {
                    var g = function (r) {
                        try {
                            r.data == d.channel + "-ready" && (k = "postMessage" in l.contentWindow ?
                                l.contentWindow : l.contentWindow.document, w(a, "message", g), E(a, "message", c), m(function () {
                                e.up.callback(!0)
                            }, 0))
                        } catch (sa) {
                        }
                    };
                    E(a, "message", g);
                    t(d.props, {
                        src: z(d.remote, {xdm_e: v(p.href), xdm_c: d.channel, xdm_p: 1}),
                        name: J + d.channel + "_provider"
                    });
                    l = A(d)
                } else E(a, "message", c), k = "postMessage" in a.parent ? a.parent : a.parent.document, k.postMessage(d.channel + "-ready", r), m(function () {
                    e.up.callback(!0)
                }, 0)
            }, init: function () {
                g(e.onDOMReady, e)
            }
        }
    };
    G.stack.QueueBehavior = function (d) {
        function a() {
            if (d.remove && 0 === l.length) D(e);
            else if (!g && 0 !== l.length && !q) {
                g = !0;
                var c = l.shift();
                e.down.outgoing(c.data, c.origin, function (d) {
                    g = !1;
                    c.callback && m(function () {
                        c.callback(d)
                    }, 0);
                    a()
                })
            }
        }

        var e, l = [], g = !0, r = "", q, t = 0, p = !1, C = !1;
        return e = {
            init: function () {
                B(d) && (d = {});
                d.maxLength && (t = d.maxLength, C = !0);
                d.lazy ? p = !0 : e.down.init()
            }, callback: function (d) {
                g = !1;
                var c = e.up;
                a();
                c.callback(d)
            }, incoming: function (a, l) {
                if (C) {
                    var g = a.indexOf("_"), k = parseInt(a.substring(0, g), 10);
                    r += a.substring(g + 1);
                    0 === k && (d.encode && (r = c(r)), e.up.incoming(r, l), r = "")
                } else e.up.incoming(a,
                    l)
            }, outgoing: function (c, g, r) {
                d.encode && (c = k(c));
                var q = [], m;
                if (C) {
                    for (; 0 !== c.length;) m = c.substring(0, t), c = c.substring(m.length), q.push(m);
                    for (; m = q.shift();) l.push({
                        data: q.length + "_" + m,
                        origin: g,
                        callback: 0 === q.length ? r : null
                    })
                } else l.push({data: c, origin: g, callback: r});
                p ? e.down.init() : a()
            }, destroy: function () {
                q = !0;
                e.down.destroy()
            }
        }
    };
    this.easyXDM = G
})(window, document, location, window.setTimeout, decodeURIComponent, encodeURIComponent);
window.avsr = window.avsr || {};
/*
 _jQuery v1.7.2 _jQuery.com | _jQuery.org/license */
(function (a, e) {
    function p(b) {
        return d.isWindow(b) ? b : 9 === b.nodeType ? b.defaultView || b.parentWindow : !1
    }

    function m(b) {
        if (!ua[b]) {
            var f = w.body, h = d("<" + b + ">").appendTo(f), n = h.css("display");
            h.remove();
            if ("none" === n || "" === n) aa || (aa = w.createElement("iframe"), aa.frameBorder = aa.width = aa.height = 0), f.appendChild(aa), ga && aa.createElement || (ga = (aa.contentWindow || aa.contentDocument).document, ga.write((d.support.boxModel ? "<!doctype html>" : "") + "<html><body>"), ga.close()), h = ga.createElement(b), ga.body.appendChild(h),
                n = d.css(h, "display"), f.removeChild(aa);
            ua[b] = n
        }
        return ua[b]
    }

    function c(b, f) {
        var h = {};
        d.each(la.concat.apply([], la.slice(0, f)), function () {
            h[this] = b
        });
        return h
    }

    function k() {
        ma = e
    }

    function q() {
        setTimeout(k, 0);
        return ma = d.now()
    }

    function u() {
        try {
            return new a.XMLHttpRequest
        } catch (b) {
        }
    }

    function g(b, f, h, n) {
        if (d.isArray(f)) d.each(f, function (d, f) {
            h || bb.test(b) ? n(b, f) : g(b + "[" + ("object" == typeof f ? d : "") + "]", f, h, n)
        }); else if (h || "object" !== d.type(f)) n(b, f); else for (var a in f) g(b + "[" + a + "]", f[a], h, n)
    }

    function v(b,
               f) {
        var h, n, a = d.ajaxSettings.flatOptions || {};
        for (h in f) f[h] !== e && ((a[h] ? b : n || (n = {}))[h] = f[h]);
        n && d.extend(!0, b, n)
    }

    function z(b, d, h, n, a, c) {
        a = a || d.dataTypes[0];
        c = c || {};
        c[a] = !0;
        a = b[a];
        for (var f = 0, x = a ? a.length : 0, P = b === va, l; f < x && (P || !l); f++) l = a[f](d, h, n), "string" == typeof l && (!P || c[l] ? l = e : (d.dataTypes.unshift(l), l = z(b, d, h, n, l, c)));
        !P && l || c["*"] || (l = z(b, d, h, n, "*", c));
        return l
    }

    function B(b) {
        return function (f, h) {
            "string" != typeof f && (h = f, f = "*");
            if (d.isFunction(h)) for (var n = f.toLowerCase().split(Ia), a = 0, c = n.length,
                                          e, l; a < c; a++) e = n[a], (l = /^\+/.test(e)) && (e = e.substr(1) || "*"), e = b[e] = b[e] || [], e[l ? "unshift" : "push"](h)
        }
    }

    function t(b, f, h) {
        var n = "width" === f ? b.offsetWidth : b.offsetHeight, a = "width" === f ? 1 : 0;
        if (0 < n) {
            if ("border" !== h) for (; 4 > a; a += 2) h || (n -= parseFloat(d.css(b, "padding" + da[a])) || 0), "margin" === h ? n += parseFloat(d.css(b, h + da[a])) || 0 : n -= parseFloat(d.css(b, "border" + da[a] + "Width")) || 0;
            return n + "px"
        }
        n = ha(b, f);
        if (0 > n || null == n) n = b.style[f];
        if (wa.test(n)) return n;
        n = parseFloat(n) || 0;
        if (h) for (; 4 > a; a += 2) n += parseFloat(d.css(b,
            "padding" + da[a])) || 0, "padding" !== h && (n += parseFloat(d.css(b, "border" + da[a] + "Width")) || 0), "margin" === h && (n += parseFloat(d.css(b, h + da[a])) || 0);
        return n + "px"
    }

    function A(b) {
        var f = (b.nodeName || "").toLowerCase();
        "input" === f ? F(b) : "script" !== f && "undefined" != typeof b.getElementsByTagName && d.grep(b.getElementsByTagName("input"), F)
    }

    function F(b) {
        if ("checkbox" === b.type || "radio" === b.type) b.defaultChecked = b.checked
    }

    function y(b) {
        return "undefined" != typeof b.getElementsByTagName ? b.getElementsByTagName("*") : "undefined" !=
        typeof b.querySelectorAll ? b.querySelectorAll("*") : []
    }

    function D(b, f) {
        var h;
        1 === f.nodeType && (f.clearAttributes && f.clearAttributes(), f.mergeAttributes && f.mergeAttributes(b), h = f.nodeName.toLowerCase(), "object" === h ? f.outerHTML = b.outerHTML : "input" !== h || "checkbox" !== b.type && "radio" !== b.type ? "option" === h ? f.selected = b.defaultSelected : "input" === h || "textarea" === h ? f.defaultValue = b.defaultValue : "script" === h && f.text !== b.text && (f.text = b.text) : (b.checked && (f.defaultChecked = f.checked = b.checked), f.value !== b.value &&
        (f.value = b.value)), f.removeAttribute(d.expando), f.removeAttribute("_submit_attached"), f.removeAttribute("_change_attached"))
    }

    function H(b, f) {
        if (1 === f.nodeType && d.hasData(b)) {
            var h, n, a;
            n = d._data(b);
            var c = d._data(f, n), e = n.events;
            if (e) for (h in delete c.handle, c.events = {}, e) for (n = 0, a = e[h].length; n < a; n++) d.event.add(f, h, e[h][n]);
            c.data && (c.data = d.extend({}, c.data))
        }
    }

    function O(b, f) {
        return d.nodeName(b, "table") ? b.getElementsByTagName("tbody")[0] || b.appendChild(b.ownerDocument.createElement("tbody")) : b
    }

    function M(b) {
        var d = Ja.split("|");
        b = b.createDocumentFragment();
        if (b.createElement) for (; d.length;) b.createElement(d.pop());
        return b
    }

    function Q(b, f, h) {
        f = f || 0;
        if (d.isFunction(f)) return d.grep(b, function (b, d) {
            return !!f.call(b, d, b) === h
        });
        if (f.nodeType) return d.grep(b, function (b, d) {
            return b === f === h
        });
        if ("string" == typeof f) {
            var n = d.grep(b, function (b) {
                return 1 === b.nodeType
            });
            if (cb.test(f)) return d.filter(f, n, !h);
            f = d.filter(f, n)
        }
        return d.grep(b, function (b, n) {
            return 0 <= d.inArray(b, f) === h
        })
    }

    function V(b) {
        return !b ||
            !b.parentNode || 11 === b.parentNode.nodeType
    }

    function G() {
        return !0
    }

    function N() {
        return !1
    }

    function J(b, f, h) {
        var n = f + "defer", a = f + "queue", c = f + "mark", e = d._data(b, n);
        !e || "queue" !== h && d._data(b, a) || "mark" !== h && d._data(b, c) || setTimeout(function () {
            d._data(b, a) || d._data(b, c) || (d.removeData(b, n, !0), e.fire())
        }, 0)
    }

    function l(b) {
        for (var f in b) if (("data" !== f || !d.isEmptyObject(b[f])) && "toJSON" !== f) return !1;
        return !0
    }

    function C(b, f, h) {
        if (h === e && 1 === b.nodeType) if (h = "data-" + f.replace(r, "-$1").toLowerCase(), h = b.getAttribute(h),
        "string" == typeof h) {
            try {
                h = "true" === h ? !0 : "false" === h ? !1 : "null" === h ? null : d.isNumeric(h) ? +h : Y.test(h) ? d.parseJSON(h) : h
            } catch (n) {
            }
            d.data(b, f, h)
        } else h = e;
        return h
    }

    function E(b) {
        var d = U[b] = {}, h, n;
        b = b.split(/\s+/);
        h = 0;
        for (n = b.length; h < n; h++) d[b[h]] = !0;
        return d
    }

    var w = a.document, R = a.navigator, S = a.location, d = function () {
        function b() {
            if (!d.isReady) {
                try {
                    w.documentElement.doScroll("left")
                } catch (Rb) {
                    setTimeout(b, 1);
                    return
                }
                d.ready()
            }
        }

        var d = function (b, f) {
                return new d.fn.init(b, f, c)
            }, h = a._jQuery, n = a._$, c, P = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,
            l = /\S/, k = /^\s+/, g = /\s+$/, r = /^<(\w+)\s*\/?>(?:<\/\1>)?$/, q = /^[\],:{}\s]*$/,
            t = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,
            p = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, m = /(?:^|:|,)(?:\s*\[)+/g,
            C = /(webkit)[ \/]([\w.]+)/, y = /(opera)(?:.*version)?[ \/]([\w.]+)/, u = /(msie) ([\w.]+)/,
            D = /(mozilla)(?:.*? rv:([\w.]+))?/, A = /-([a-z]|[0-9])/ig, E = /^-ms-/, z = function (b, d) {
                return (d + "").toUpperCase()
            }, K = R.userAgent, ba, ia, db = Object.prototype.toString, oa = Object.prototype.hasOwnProperty,
            ya = Array.prototype.push,
            B = Array.prototype.slice, v = String.prototype.trim, G = Array.prototype.indexOf, L = {};
        d.fn = d.prototype = {
            constructor: d, init: function (b, f, h) {
                var n, a;
                if (!b) return this;
                if (b.nodeType) return this.context = this[0] = b, this.length = 1, this;
                if ("body" === b && !f && w.body) return this.context = w, this[0] = w.body, this.selector = b, this.length = 1, this;
                if ("string" == typeof b) {
                    "<" !== b.charAt(0) || ">" !== b.charAt(b.length - 1) || 3 > b.length ? n = P.exec(b) : n = [null, b, null];
                    if (n && (n[1] || !f)) {
                        if (n[1]) return a = (f = f instanceof d ? f[0] : f) ? f.ownerDocument ||
                            f : w, (h = r.exec(b)) ? d.isPlainObject(f) ? (b = [w.createElement(h[1])], d.fn.attr.call(b, f, !0)) : b = [a.createElement(h[1])] : (h = d.buildFragment([n[1]], [a]), b = (h.cacheable ? d.clone(h.fragment) : h.fragment).childNodes), d.merge(this, b);
                        if ((f = w.getElementById(n[2])) && f.parentNode) {
                            if (f.id !== n[2]) return h.find(b);
                            this.length = 1;
                            this[0] = f
                        }
                        this.context = w;
                        this.selector = b;
                        return this
                    }
                    return !f || f._jQuery ? (f || h).find(b) : this.constructor(f).find(b)
                }
                if (d.isFunction(b)) return h.ready(b);
                b.selector !== e && (this.selector = b.selector,
                    this.context = b.context);
                return d.makeArray(b, this)
            }, selector: "", _jQuery: "1.7.2", length: 0, size: function () {
                return this.length
            }, toArray: function () {
                return B.call(this, 0)
            }, get: function (b) {
                return null == b ? this.toArray() : 0 > b ? this[this.length + b] : this[b]
            }, pushStack: function (b, f, h) {
                var n = this.constructor();
                d.isArray(b) ? ya.apply(n, b) : d.merge(n, b);
                n.prevObject = this;
                n.context = this.context;
                "find" === f ? n.selector = this.selector + (this.selector ? " " : "") + h : f && (n.selector = this.selector + "." + f + "(" + h + ")");
                return n
            }, each: function (b,
                               f) {
                return d.each(this, b, f)
            }, ready: function (b) {
                d.bindReady();
                ba.add(b);
                return this
            }, eq: function (b) {
                b = +b;
                return -1 === b ? this.slice(b) : this.slice(b, b + 1)
            }, first: function () {
                return this.eq(0)
            }, last: function () {
                return this.eq(-1)
            }, slice: function () {
                return this.pushStack(B.apply(this, arguments), "slice", B.call(arguments).join(","))
            }, map: function (b) {
                return this.pushStack(d.map(this, function (d, f) {
                    return b.call(d, f, d)
                }))
            }, end: function () {
                return this.prevObject || this.constructor(null)
            }, push: ya, sort: [].sort, splice: [].splice
        };
        d.fn.init.prototype = d.fn;
        d.extend = d.fn.extend = function () {
            var b, f, h, n, a, c, x = arguments[0] || {}, K = 1, P = arguments.length, l = !1;
            "boolean" == typeof x && (l = x, x = arguments[1] || {}, K = 2);
            "object" != typeof x && !d.isFunction(x) && (x = {});
            for (P === K && (x = this, --K); K < P; K++) if (null != (b = arguments[K])) for (f in b) h = x[f], n = b[f], x !== n && (l && n && (d.isPlainObject(n) || (a = d.isArray(n))) ? (a ? (a = !1, c = h && d.isArray(h) ? h : []) : c = h && d.isPlainObject(h) ? h : {}, x[f] = d.extend(l, c, n)) : n !== e && (x[f] = n));
            return x
        };
        d.extend({
            noConflict: function (b) {
                a._$ ===
                d && (a._$ = n);
                b && a._jQuery === d && (a._jQuery = h);
                return d
            }, isReady: !1, readyWait: 1, holdReady: function (b) {
                b ? d.readyWait++ : d.ready(!0)
            }, ready: function (b) {
                if (!0 === b && !--d.readyWait || !0 !== b && !d.isReady) {
                    if (!w.body) return setTimeout(d.ready, 1);
                    d.isReady = !0;
                    !0 !== b && 0 < --d.readyWait || (ba.fireWith(w, [d]), d.fn.trigger && d(w).trigger("ready").off("ready"))
                }
            }, bindReady: function () {
                if (!ba) {
                    ba = d.Callbacks("once memory");
                    if ("complete" === w.readyState) return setTimeout(d.ready, 1);
                    if (w.addEventListener) w.addEventListener("DOMContentLoaded",
                        ia, !1), a.addEventListener("load", d.ready, !1); else if (w.attachEvent) {
                        w.attachEvent("onreadystatechange", ia);
                        a.attachEvent("onload", d.ready);
                        var f = !1;
                        try {
                            f = null == a.frameElement
                        } catch (Sb) {
                        }
                        w.documentElement.doScroll && f && b()
                    }
                }
            }, isFunction: function (b) {
                return "function" === d.type(b)
            }, isArray: Array.isArray || function (b) {
                return "array" === d.type(b)
            }, isWindow: function (b) {
                return null != b && b == b.window
            }, isNumeric: function (b) {
                return !isNaN(parseFloat(b)) && isFinite(b)
            }, type: function (b) {
                return null == b ? String(b) : L[db.call(b)] ||
                    "object"
            }, isPlainObject: function (b) {
                if (!b || "object" !== d.type(b) || b.nodeType || d.isWindow(b)) return !1;
                try {
                    if (b.constructor && !oa.call(b, "constructor") && !oa.call(b.constructor.prototype, "isPrototypeOf")) return !1
                } catch (Ka) {
                    return !1
                }
                for (var f in b) ;
                return f === e || oa.call(b, f)
            }, isEmptyObject: function (b) {
                for (var d in b) return !1;
                return !0
            }, error: function (b) {
                throw Error(b);
            }, parseJSON: function (b) {
                if ("string" != typeof b || !b) return null;
                b = d.trim(b);
                if (a.JSON && a.JSON.parse) return a.JSON.parse(b);
                if (q.test(b.replace(t,
                    "@").replace(p, "]").replace(m, ""))) return (new Function("return " + b))();
                d.error("Invalid JSON: " + b)
            }, parseXML: function (b) {
                if ("string" != typeof b || !b) return null;
                var f, h;
                try {
                    a.DOMParser ? (h = new DOMParser, f = h.parseFromString(b, "text/xml")) : (f = new ActiveXObject("Microsoft.XMLDOM"), f.async = "false", f.loadXML(b))
                } catch (Ub) {
                    f = e
                }
                f && f.documentElement && !f.getElementsByTagName("parsererror").length || d.error("Invalid XML: " + b);
                return f
            }, noop: function () {
            }, globalEval: function (b) {
                b && l.test(b) && (a.execScript || function (b) {
                    a.eval.call(a,
                        b)
                })(b)
            }, camelCase: function (b) {
                return b.replace(E, "ms-").replace(A, z)
            }, nodeName: function (b, d) {
                return b.nodeName && b.nodeName.toUpperCase() === d.toUpperCase()
            }, each: function (b, f, h) {
                var n, a = 0, c = b.length, x = c === e || d.isFunction(b);
                if (h) if (x) for (n in b) {
                    if (!1 === f.apply(b[n], h)) break
                } else for (; a < c && !1 !== f.apply(b[a++], h);) ; else if (x) for (n in b) {
                    if (!1 === f.call(b[n], n, b[n])) break
                } else for (; a < c && !1 !== f.call(b[a], a, b[a++]);) ;
                return b
            }, trim: v ? function (b) {
                return null == b ? "" : v.call(b)
            } : function (b) {
                return null == b ?
                    "" : (b + "").replace(k, "").replace(g, "")
            }, makeArray: function (b, f) {
                var h = f || [];
                if (null != b) {
                    var n = d.type(b);
                    null == b.length || "string" === n || "function" === n || "regexp" === n || d.isWindow(b) ? ya.call(h, b) : d.merge(h, b)
                }
                return h
            }, inArray: function (b, d, f) {
                var h;
                if (d) {
                    if (G) return G.call(d, b, f);
                    h = d.length;
                    for (f = f ? 0 > f ? Math.max(0, h + f) : f : 0; f < h; f++) if (f in d && d[f] === b) return f
                }
                return -1
            }, merge: function (b, d) {
                var f = b.length, h = 0;
                if ("number" == typeof d.length) for (var n = d.length; h < n; h++) b[f++] = d[h]; else for (; d[h] !== e;) b[f++] = d[h++];
                b.length = f;
                return b
            }, grep: function (b, d, f) {
                var h = [], n;
                f = !!f;
                for (var a = 0, c = b.length; a < c; a++) n = !!d(b[a], a), f !== n && h.push(b[a]);
                return h
            }, map: function (b, f, h) {
                var n, a, c = [], x = 0, K = b.length;
                if (b instanceof d || K !== e && "number" == typeof K && (0 < K && b[0] && b[K - 1] || 0 === K || d.isArray(b))) for (; x < K; x++) n = f(b[x], x, h), null != n && (c[c.length] = n); else for (a in b) n = f(b[a], a, h), null != n && (c[c.length] = n);
                return c.concat.apply([], c)
            }, guid: 1, proxy: function (b, f) {
                if ("string" == typeof f) {
                    var h = b[f];
                    f = b;
                    b = h
                }
                if (!d.isFunction(b)) return e;
                var n = B.call(arguments, 2), h = function () {
                    return b.apply(f, n.concat(B.call(arguments)))
                };
                h.guid = b.guid = b.guid || h.guid || d.guid++;
                return h
            }, access: function (b, f, h, n, a, c, x) {
                var K, l = null == h, P = 0, k = b.length;
                if (h && "object" == typeof h) {
                    for (P in h) d.access(b, f, P, h[P], 1, c, n);
                    a = 1
                } else if (n !== e) {
                    K = x === e && d.isFunction(n);
                    l && (K ? (K = f, f = function (b, f, h) {
                        return K.call(d(b), h)
                    }) : (f.call(b, n), f = null));
                    if (f) for (; P < k; P++) f(b[P], h, K ? n.call(b[P], P, f(b[P], h)) : n, x);
                    a = 1
                }
                return a ? b : l ? f.call(b) : k ? f(b[0], h) : c
            }, now: function () {
                return (new Date).getTime()
            },
            uaMatch: function (b) {
                b = b.toLowerCase();
                b = C.exec(b) || y.exec(b) || u.exec(b) || 0 > b.indexOf("compatible") && D.exec(b) || [];
                return {browser: b[1] || "", version: b[2] || "0"}
            }, sub: function () {
                function b(d, f) {
                    return new b.fn.init(d, f)
                }

                d.extend(!0, b, this);
                b.superclass = this;
                b.fn = b.prototype = this();
                b.fn.constructor = b;
                b.sub = this.sub;
                b.fn.init = function (h, n) {
                    n && n instanceof d && !(n instanceof b) && (n = b(n));
                    return d.fn.init.call(this, h, n, f)
                };
                b.fn.init.prototype = b.fn;
                var f = b(w);
                return b
            }, browser: {}
        });
        d.each("Boolean Number String Function Array Date RegExp Object".split(" "),
            function (b, d) {
                L["[object " + d + "]"] = d.toLowerCase()
            });
        K = d.uaMatch(K);
        K.browser && (d.browser[K.browser] = !0, d.browser.version = K.version);
        d.browser.webkit && (d.browser.safari = !0);
        l.test(" ") && (k = /^[\s\xA0]+/, g = /[\s\xA0]+$/);
        c = d(w);
        w.addEventListener ? ia = function () {
            w.removeEventListener("DOMContentLoaded", ia, !1);
            d.ready()
        } : w.attachEvent && (ia = function () {
            "complete" === w.readyState && (w.detachEvent("onreadystatechange", ia), d.ready())
        });
        return d
    }(), U = {};
    d.Callbacks = function (b) {
        b = b ? U[b] || E(b) : {};
        var f = [], h = [], n,
            a, c, l, k, g, r = function (h) {
                var n, a, c, x;
                n = 0;
                for (a = h.length; n < a; n++) c = h[n], x = d.type(c), "array" === x ? r(c) : "function" !== x || b.unique && t.has(c) || f.push(c)
            }, q = function (d, x) {
                x = x || [];
                n = !b.memory || [d, x];
                c = a = !0;
                g = l || 0;
                l = 0;
                for (k = f.length; f && g < k; g++) if (!1 === f[g].apply(d, x) && b.stopOnFalse) {
                    n = !0;
                    break
                }
                c = !1;
                f && (b.once ? !0 === n ? t.disable() : f = [] : h && h.length && (n = h.shift(), t.fireWith(n[0], n[1])))
            }, t = {
                add: function () {
                    if (f) {
                        var b = f.length;
                        r(arguments);
                        c ? k = f.length : n && !0 !== n && (l = b, q(n[0], n[1]))
                    }
                    return this
                }, remove: function () {
                    if (f) for (var d =
                        arguments, h = 0, n = d.length; h < n; h++) for (var a = 0; a < f.length && (d[h] !== f[a] || (c && a <= k && (k--, a <= g && g--), f.splice(a--, 1), !b.unique)); a++) ;
                    return this
                }, has: function (b) {
                    if (f) for (var d = 0, h = f.length; d < h; d++) if (b === f[d]) return !0;
                    return !1
                }, empty: function () {
                    f = [];
                    return this
                }, disable: function () {
                    f = h = n = e;
                    return this
                }, disabled: function () {
                    return !f
                }, lock: function () {
                    h = e;
                    n && !0 !== n || t.disable();
                    return this
                }, locked: function () {
                    return !h
                }, fireWith: function (d, f) {
                    h && (c ? b.once || h.push([d, f]) : (!b.once || !n) && q(d, f));
                    return this
                },
                fire: function () {
                    t.fireWith(this, arguments);
                    return this
                }, fired: function () {
                    return !!a
                }
            };
        return t
    };
    var X = [].slice;
    d.extend({
        Deferred: function (b) {
            var f = d.Callbacks("once memory"), h = d.Callbacks("once memory"), n = d.Callbacks("memory"),
                a = "pending", c = {resolve: f, reject: h, notify: n}, e = {
                    done: f.add, fail: h.add, progress: n.add, state: function () {
                        return a
                    }, isResolved: f.fired, isRejected: h.fired, then: function (b, d, f) {
                        l.done(b).fail(d).progress(f);
                        return this
                    }, always: function () {
                        l.done.apply(l, arguments).fail.apply(l, arguments);
                        return this
                    }, pipe: function (b, f, h) {
                        return d.Deferred(function (n) {
                            d.each({done: [b, "resolve"], fail: [f, "reject"], progress: [h, "notify"]}, function (b, f) {
                                var h = f[0], a = f[1], c;
                                d.isFunction(h) ? l[b](function () {
                                    (c = h.apply(this, arguments)) && d.isFunction(c.promise) ? c.promise().then(n.resolve, n.reject, n.notify) : n[a + "With"](this === l ? n : this, [c])
                                }) : l[b](n[a])
                            })
                        }).promise()
                    }, promise: function (b) {
                        if (null == b) b = e; else for (var d in e) b[d] = e[d];
                        return b
                    }
                }, l = e.promise({}), k;
            for (k in c) l[k] = c[k].fire, l[k + "With"] = c[k].fireWith;
            l.done(function () {
                a = "resolved"
            }, h.disable, n.lock).fail(function () {
                a = "rejected"
            }, f.disable, n.lock);
            b && b.call(l, l);
            return l
        }, when: function (b) {
            function f(b) {
                return function (d) {
                    e[b] = 1 < arguments.length ? X.call(arguments, 0) : d;
                    k.notifyWith(g, e)
                }
            }

            function h(b) {
                return function (d) {
                    n[b] = 1 < arguments.length ? X.call(arguments, 0) : d;
                    --l || k.resolveWith(k, n)
                }
            }

            var n = X.call(arguments, 0), a = 0, c = n.length, e = Array(c), l = c,
                k = 1 >= c && b && d.isFunction(b.promise) ? b : d.Deferred(), g = k.promise();
            if (1 < c) {
                for (; a < c; a++) n[a] && n[a].promise &&
                d.isFunction(n[a].promise) ? n[a].promise().then(h(a), k.reject, f(a)) : --l;
                l || k.resolveWith(k, n)
            } else k !== b && k.resolveWith(k, c ? [b] : []);
            return g
        }
    });
    d.support = function () {
        var b, f, h, n, c, e, l, k, g = w.createElement("div");
        g.setAttribute("className", "t");
        g.innerHTML = "   <link/><table></table><a href='/a' style='top:1px;float:left;opacity:.55;'>a</a><input type='checkbox'/>";
        f = g.getElementsByTagName("*");
        h = g.getElementsByTagName("a")[0];
        if (!f || !f.length || !h) return {};
        n = w.createElement("select");
        c = n.appendChild(w.createElement("option"));
        f = g.getElementsByTagName("input")[0];
        b = {
            leadingWhitespace: 3 === g.firstChild.nodeType,
            tbody: !g.getElementsByTagName("tbody").length,
            htmlSerialize: !!g.getElementsByTagName("link").length,
            style: /top/.test(h.getAttribute("style")),
            hrefNormalized: "/a" === h.getAttribute("href"),
            opacity: /^0.55/.test(h.style.opacity),
            cssFloat: !!h.style.cssFloat,
            checkOn: "on" === f.value,
            optSelected: c.selected,
            getSetAttribute: "t" !== g.className,
            enctype: !!w.createElement("form").enctype,
            html5Clone: "<:nav></:nav>" !== w.createElement("nav").cloneNode(!0).outerHTML,
            submitBubbles: !0,
            changeBubbles: !0,
            focusinBubbles: !1,
            deleteExpando: !0,
            noCloneEvent: !0,
            inlineBlockNeedsLayout: !1,
            shrinkWrapBlocks: !1,
            reliableMarginRight: !0,
            pixelMargin: !0
        };
        d.boxModel = b.boxModel = "CSS1Compat" === w.compatMode;
        f.checked = !0;
        b.noCloneChecked = f.cloneNode(!0).checked;
        n.disabled = !0;
        b.optDisabled = !c.disabled;
        try {
            delete g.test
        } catch (Qb) {
            b.deleteExpando = !1
        }
        !g.addEventListener && g.attachEvent && g.fireEvent && (g.attachEvent("onclick", function () {
            b.noCloneEvent = !1
        }), g.cloneNode(!0).fireEvent("onclick"));
        f = w.createElement("input");
        f.value = "t";
        f.setAttribute("type", "radio");
        b.radioValue = "t" === f.value;
        f.setAttribute("checked", "checked");
        f.setAttribute("name", "t");
        g.appendChild(f);
        h = w.createDocumentFragment();
        h.appendChild(g.lastChild);
        b.checkClone = h.cloneNode(!0).cloneNode(!0).lastChild.checked;
        b.appendChecked = f.checked;
        h.removeChild(f);
        h.appendChild(g);
        if (g.attachEvent) for (l in{
            submit: 1,
            change: 1,
            focusin: 1
        }) f = "on" + l, (k = f in g) || (g.setAttribute(f, "return;"), k = "function" == typeof g[f]), b[l + "Bubbles"] =
            k;
        h.removeChild(g);
        h = n = c = g = f = null;
        d(function () {
            var f, h, n, c, x, l, P = w.getElementsByTagName("body")[0];
            !P || (f = w.createElement("div"), f.style.cssText = "padding:0;margin:0;border:0;visibility:hidden;width:0;height:0;position:static;top:0;margin-top:1px", P.insertBefore(f, P.firstChild), g = w.createElement("div"), f.appendChild(g), g.innerHTML = "<table><tr><td style='padding:0;margin:0;border:0;display:none'></td><td>t</td></tr></table>", e = g.getElementsByTagName("td"), k = 0 === e[0].offsetHeight, e[0].style.display =
                "", e[1].style.display = "none", b.reliableHiddenOffsets = k && 0 === e[0].offsetHeight, a.getComputedStyle && (g.innerHTML = "", l = w.createElement("div"), l.style.width = "0", l.style.marginRight = "0", g.style.width = "2px", g.appendChild(l), b.reliableMarginRight = 0 === (parseInt((a.getComputedStyle(l, null) || {marginRight: 0}).marginRight, 10) || 0)), "undefined" != typeof g.style.zoom && (g.innerHTML = "", g.style.width = g.style.padding = "1px", g.style.border = 0, g.style.overflow = "hidden", g.style.display = "inline", g.style.zoom = 1, b.inlineBlockNeedsLayout =
                3 === g.offsetWidth, g.style.display = "block", g.style.overflow = "visible", g.innerHTML = "<div style='width:5px;'></div>", b.shrinkWrapBlocks = 3 !== g.offsetWidth), g.style.cssText = "position:absolute;top:0;left:0;width:1px;height:1px;padding:0;margin:0;border:0;visibility:hidden;", g.innerHTML = "<div style='position:absolute;top:0;left:0;width:1px;height:1px;padding:0;margin:0;border:5px solid #000;display:block;'><div style='padding:0;margin:0;border:0;display:block;overflow:hidden;'></div></div><table style='position:absolute;top:0;left:0;width:1px;height:1px;padding:0;margin:0;border:5px solid #000;' cellpadding='0' cellspacing='0'><tr><td></td></tr></table>",
                h = g.firstChild, n = h.firstChild, c = h.nextSibling.firstChild.firstChild, x = {
                doesNotAddBorder: 5 !== n.offsetTop,
                doesAddBorderForTableAndCells: 5 === c.offsetTop
            }, n.style.position = "fixed", n.style.top = "20px", x.fixedPosition = 20 === n.offsetTop || 15 === n.offsetTop, n.style.position = n.style.top = "", h.style.overflow = "hidden", h.style.position = "relative", x.subtractsBorderForOverflowNotVisible = -5 === n.offsetTop, x.doesNotIncludeMarginInBodyOffset = 1 !== P.offsetTop, a.getComputedStyle && (g.style.marginTop = "1%", b.pixelMargin = "1%" !==
                (a.getComputedStyle(g, null) || {marginTop: 0}).marginTop), "undefined" != typeof f.style.zoom && (f.style.zoom = 1), P.removeChild(f), g = null, d.extend(b, x))
        });
        return b
    }();
    var Y = /^(?:\{.*\}|\[.*\])$/, r = /([A-Z])/g;
    d.extend({
        cache: {},
        uuid: 0,
        expando: "_jQuery" + (d.fn._jQuery + Math.random()).replace(/\D/g, ""),
        noData: {embed: !0, object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000", applet: !0},
        hasData: function (b) {
            b = b.nodeType ? d.cache[b[d.expando]] : b[d.expando];
            return !!b && !l(b)
        },
        data: function (b, f, h, n) {
            if (d.acceptData(b)) {
                var a,
                    c;
                a = d.expando;
                var l = "string" == typeof f, g = b.nodeType, k = g ? d.cache : b, r = g ? b[a] : b[a] && a,
                    q = "events" === f;
                if (r && k[r] && (q || n || k[r].data) || !l || h !== e) {
                    r || (g ? b[a] = r = ++d.uuid : r = a);
                    k[r] || (k[r] = {}, g || (k[r].toJSON = d.noop));
                    if ("object" == typeof f || "function" == typeof f) n ? k[r] = d.extend(k[r], f) : k[r].data = d.extend(k[r].data, f);
                    b = a = k[r];
                    n || (a.data || (a.data = {}), a = a.data);
                    h !== e && (a[d.camelCase(f)] = h);
                    if (q && !a[f]) return b.events;
                    l ? (c = a[f], null == c && (c = a[d.camelCase(f)])) : c = a;
                    return c
                }
            }
        },
        removeData: function (b, f, h) {
            if (d.acceptData(b)) {
                var n,
                    a, c, e = d.expando, g = b.nodeType, k = g ? d.cache : b, r = g ? b[e] : e;
                if (k[r]) {
                    if (f && (n = h ? k[r] : k[r].data)) {
                        d.isArray(f) || (f in n ? f = [f] : (f = d.camelCase(f), f in n ? f = [f] : f = f.split(" ")));
                        a = 0;
                        for (c = f.length; a < c; a++) delete n[f[a]];
                        if (!(h ? l : d.isEmptyObject)(n)) return
                    }
                    if (!h && (delete k[r].data, !l(k[r]))) return;
                    d.support.deleteExpando || !k.setInterval ? delete k[r] : k[r] = null;
                    g && (d.support.deleteExpando ? delete b[e] : b.removeAttribute ? b.removeAttribute(e) : b[e] = null)
                }
            }
        },
        _data: function (b, f, h) {
            return d.data(b, f, h, !0)
        },
        acceptData: function (b) {
            if (b.nodeName) {
                var f =
                    d.noData[b.nodeName.toLowerCase()];
                if (f) return !0 !== f && b.getAttribute("classid") === f
            }
            return !0
        }
    });
    d.fn.extend({
        data: function (b, f) {
            var h, n, a, c, l, g = this[0], k = 0, r = null;
            if (b === e) {
                if (this.length && (r = d.data(g), 1 === g.nodeType && !d._data(g, "parsedAttrs"))) {
                    a = g.attributes;
                    for (l = a.length; k < l; k++) c = a[k].name, 0 === c.indexOf("data-") && (c = d.camelCase(c.substring(5)), C(g, c, r[c]));
                    d._data(g, "parsedAttrs", !0)
                }
                return r
            }
            if ("object" == typeof b) return this.each(function () {
                d.data(this, b)
            });
            h = b.split(".", 2);
            h[1] = h[1] ? "." + h[1] :
                "";
            n = h[1] + "!";
            return d.access(this, function (f) {
                if (f === e) return r = this.triggerHandler("getData" + n, [h[0]]), r === e && g && (r = d.data(g, b), r = C(g, b, r)), r === e && h[1] ? this.data(h[0]) : r;
                h[1] = f;
                this.each(function () {
                    var a = d(this);
                    a.triggerHandler("setData" + n, h);
                    d.data(this, b, f);
                    a.triggerHandler("changeData" + n, h)
                })
            }, null, f, 1 < arguments.length, null, !1)
        }, removeData: function (b) {
            return this.each(function () {
                d.removeData(this, b)
            })
        }
    });
    d.extend({
        _mark: function (b, f) {
            b && (f = (f || "fx") + "mark", d._data(b, f, (d._data(b, f) || 0) + 1))
        },
        _unmark: function (b, f, h) {
            !0 !== b && (h = f, f = b, b = !1);
            if (f) {
                h = h || "fx";
                var n = h + "mark";
                (b = b ? 0 : (d._data(f, n) || 1) - 1) ? d._data(f, n, b) : (d.removeData(f, n, !0), J(f, h, "mark"))
            }
        }, queue: function (b, f, h) {
            var n;
            if (b) return f = (f || "fx") + "queue", n = d._data(b, f), h && (!n || d.isArray(h) ? n = d._data(b, f, d.makeArray(h)) : n.push(h)), n || []
        }, dequeue: function (b, f) {
            f = f || "fx";
            var h = d.queue(b, f), n = h.shift(), a = {};
            "inprogress" === n && (n = h.shift());
            n && ("fx" === f && h.unshift("inprogress"), d._data(b, f + ".run", a), n.call(b, function () {
                d.dequeue(b, f)
            }, a));
            h.length || (d.removeData(b, f + "queue " + f + ".run", !0), J(b, f, "queue"))
        }
    });
    d.fn.extend({
        queue: function (b, f) {
            var h = 2;
            "string" != typeof b && (f = b, b = "fx", h--);
            return arguments.length < h ? d.queue(this[0], b) : f === e ? this : this.each(function () {
                var h = d.queue(this, b, f);
                "fx" === b && "inprogress" !== h[0] && d.dequeue(this, b)
            })
        }, dequeue: function (b) {
            return this.each(function () {
                d.dequeue(this, b)
            })
        }, delay: function (b, f) {
            b = d.fx ? d.fx.speeds[b] || b : b;
            return this.queue(f || "fx", function (d, f) {
                var h = setTimeout(d, b);
                f.stop = function () {
                    clearTimeout(h)
                }
            })
        },
        clearQueue: function (b) {
            return this.queue(b || "fx", [])
        }, promise: function (b, f) {
            function h() {
                --l || n.resolveWith(a, [a])
            }

            "string" != typeof b && (f = b, b = e);
            b = b || "fx";
            for (var n = d.Deferred(), a = this, c = a.length, l = 1, g = b + "defer", k = b + "queue", r = b + "mark", q; c--;) if (q = d.data(a[c], g, e, !0) || (d.data(a[c], k, e, !0) || d.data(a[c], r, e, !0)) && d.data(a[c], g, d.Callbacks("once memory"), !0)) l++, q.add(h);
            h();
            return n.promise(f)
        }
    });
    var L = /[\n\t\r]/g, T = /\s+/, ka = /\r/g, I = /^(?:button|input)$/i,
        Ea = /^(?:button|input|object|select|textarea)$/i,
        ab = /^a(?:rea)?$/i,
        ra = /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,
        sa = d.support.getSetAttribute, Z, Fa, Ga;
    d.fn.extend({
        attr: function (b, f) {
            return d.access(this, d.attr, b, f, 1 < arguments.length)
        }, removeAttr: function (b) {
            return this.each(function () {
                d.removeAttr(this, b)
            })
        }, prop: function (b, f) {
            return d.access(this, d.prop, b, f, 1 < arguments.length)
        }, removeProp: function (b) {
            b = d.propFix[b] || b;
            return this.each(function () {
                try {
                    this[b] = e, delete this[b]
                } catch (f) {
                }
            })
        },
        addClass: function (b) {
            var f, h, n, a, c, e, l;
            if (d.isFunction(b)) return this.each(function (f) {
                d(this).addClass(b.call(this, f, this.className))
            });
            if (b && "string" == typeof b) for (f = b.split(T), h = 0, n = this.length; h < n; h++) if (a = this[h], 1 === a.nodeType) if (a.className || 1 !== f.length) {
                c = " " + a.className + " ";
                e = 0;
                for (l = f.length; e < l; e++) ~c.indexOf(" " + f[e] + " ") || (c += f[e] + " ");
                a.className = d.trim(c)
            } else a.className = b;
            return this
        }, removeClass: function (b) {
            var f, h, n, a, c, l, g;
            if (d.isFunction(b)) return this.each(function (f) {
                d(this).removeClass(b.call(this,
                    f, this.className))
            });
            if (b && "string" == typeof b || b === e) for (f = (b || "").split(T), h = 0, n = this.length; h < n; h++) if (a = this[h], 1 === a.nodeType && a.className) if (b) {
                c = (" " + a.className + " ").replace(L, " ");
                l = 0;
                for (g = f.length; l < g; l++) c = c.replace(" " + f[l] + " ", " ");
                a.className = d.trim(c)
            } else a.className = "";
            return this
        }, toggleClass: function (b, f) {
            var h = typeof b, a = "boolean" == typeof f;
            return d.isFunction(b) ? this.each(function (h) {
                d(this).toggleClass(b.call(this, h, this.className, f), f)
            }) : this.each(function () {
                if ("string" === h) for (var n,
                                             c = 0, e = d(this), l = f, g = b.split(T); n = g[c++];) l = a ? l : !e.hasClass(n), e[l ? "addClass" : "removeClass"](n); else if ("undefined" === h || "boolean" === h) this.className && d._data(this, "__className__", this.className), this.className = this.className || !1 === b ? "" : d._data(this, "__className__") || ""
            })
        }, hasClass: function (b) {
            b = " " + b + " ";
            for (var d = 0, h = this.length; d < h; d++) if (1 === this[d].nodeType && -1 < (" " + this[d].className + " ").replace(L, " ").indexOf(b)) return !0;
            return !1
        }, val: function (b) {
            var f, h, a, c = this[0];
            if (arguments.length) return a =
                d.isFunction(b), this.each(function (h) {
                var n = d(this), c;
                1 === this.nodeType && (a ? c = b.call(this, h, n.val()) : c = b, null == c ? c = "" : "number" == typeof c ? c += "" : d.isArray(c) && (c = d.map(c, function (b) {
                    return null == b ? "" : b + ""
                })), f = d.valHooks[this.type] || d.valHooks[this.nodeName.toLowerCase()], f && "set" in f && f.set(this, c, "value") !== e || (this.value = c))
            });
            if (c) {
                if ((f = d.valHooks[c.type] || d.valHooks[c.nodeName.toLowerCase()]) && "get" in f && (h = f.get(c, "value")) !== e) return h;
                h = c.value;
                return "string" == typeof h ? h.replace(ka, "") : null ==
                h ? "" : h
            }
        }
    });
    d.extend({
        valHooks: {
            option: {
                get: function (b) {
                    var d = b.attributes.value;
                    return !d || d.specified ? b.value : b.text
                }
            }, select: {
                get: function (b) {
                    var f, h, a = b.selectedIndex, c = [], e = b.options, l = "select-one" === b.type;
                    if (0 > a) return null;
                    b = l ? a : 0;
                    for (h = l ? a + 1 : e.length; b < h; b++) if (f = e[b], !(!f.selected || (d.support.optDisabled ? f.disabled : null !== f.getAttribute("disabled")) || f.parentNode.disabled && d.nodeName(f.parentNode, "optgroup"))) {
                        f = d(f).val();
                        if (l) return f;
                        c.push(f)
                    }
                    return l && !c.length && e.length ? d(e[a]).val() :
                        c
                }, set: function (b, f) {
                    var h = d.makeArray(f);
                    d(b).find("option").each(function () {
                        this.selected = 0 <= d.inArray(d(this).val(), h)
                    });
                    h.length || (b.selectedIndex = -1);
                    return h
                }
            }
        },
        attrFn: {val: !0, css: !0, html: !0, text: !0, data: !0, width: !0, height: !0, offset: !0},
        attr: function (b, f, h, a) {
            var n, c, l = b.nodeType;
            if (b && 3 !== l && 8 !== l && 2 !== l) {
                if (a && f in d.attrFn) return d(b)[f](h);
                if ("undefined" == typeof b.getAttribute) return d.prop(b, f, h);
                (a = 1 !== l || !d.isXMLDoc(b)) && (f = f.toLowerCase(), c = d.attrHooks[f] || (ra.test(f) ? Fa : Z));
                if (h !==
                    e) {
                    if (null === h) {
                        d.removeAttr(b, f);
                        return
                    }
                    if (c && "set" in c && a && (n = c.set(b, h, f)) !== e) return n;
                    b.setAttribute(f, "" + h);
                    return h
                }
                if (c && "get" in c && a && null !== (n = c.get(b, f))) return n;
                n = b.getAttribute(f);
                return null === n ? e : n
            }
        },
        removeAttr: function (b, f) {
            var h, a, c, e, l, g = 0;
            if (f && 1 === b.nodeType) for (a = f.toLowerCase().split(T), e = a.length; g < e; g++) (c = a[g]) && (h = d.propFix[c] || c, l = ra.test(c), l || d.attr(b, c, ""), b.removeAttribute(sa ? c : h), l && h in b && (b[h] = !1))
        },
        attrHooks: {
            type: {
                set: function (b, f) {
                    if (I.test(b.nodeName) && b.parentNode) d.error("type property can't be changed");
                    else if (!d.support.radioValue && "radio" === f && d.nodeName(b, "input")) {
                        var h = b.value;
                        b.setAttribute("type", f);
                        h && (b.value = h);
                        return f
                    }
                }
            }, value: {
                get: function (b, f) {
                    return Z && d.nodeName(b, "button") ? Z.get(b, f) : f in b ? b.value : null
                }, set: function (b, f, h) {
                    if (Z && d.nodeName(b, "button")) return Z.set(b, f, h);
                    b.value = f
                }
            }
        },
        propFix: {
            tabindex: "tabIndex",
            readonly: "readOnly",
            "for": "htmlFor",
            "class": "className",
            maxlength: "maxLength",
            cellspacing: "cellSpacing",
            cellpadding: "cellPadding",
            rowspan: "rowSpan",
            colspan: "colSpan",
            usemap: "useMap",
            frameborder: "frameBorder",
            contenteditable: "contentEditable"
        },
        prop: function (b, f, h) {
            var a, c, l;
            l = b.nodeType;
            if (b && 3 !== l && 8 !== l && 2 !== l) return (l = 1 !== l || !d.isXMLDoc(b)) && (f = d.propFix[f] || f, c = d.propHooks[f]), h !== e ? c && "set" in c && (a = c.set(b, h, f)) !== e ? a : b[f] = h : c && "get" in c && null !== (a = c.get(b, f)) ? a : b[f]
        },
        propHooks: {
            tabIndex: {
                get: function (b) {
                    var d = b.getAttributeNode("tabindex");
                    return d && d.specified ? parseInt(d.value, 10) : Ea.test(b.nodeName) || ab.test(b.nodeName) && b.href ? 0 : e
                }
            }
        }
    });
    d.attrHooks.tabindex = d.propHooks.tabIndex;
    Fa = {
        get: function (b, f) {
            var h, a = d.prop(b, f);
            return !0 === a || "boolean" != typeof a && (h = b.getAttributeNode(f)) && !1 !== h.nodeValue ? f.toLowerCase() : e
        }, set: function (b, f, h) {
            var a;
            !1 === f ? d.removeAttr(b, h) : (a = d.propFix[h] || h, a in b && (b[a] = !0), b.setAttribute(h, h.toLowerCase()));
            return h
        }
    };
    sa || (Ga = {name: !0, id: !0, coords: !0}, Z = d.valHooks.button = {
        get: function (b, d) {
            var f;
            return (f = b.getAttributeNode(d)) && (Ga[d] ? "" !== f.nodeValue : f.specified) ? f.nodeValue : e
        }, set: function (b, d, h) {
            var f = b.getAttributeNode(h);
            f || (f = w.createAttribute(h),
                b.setAttributeNode(f));
            return f.nodeValue = d + ""
        }
    }, d.attrHooks.tabindex.set = Z.set, d.each(["width", "height"], function (b, f) {
        d.attrHooks[f] = d.extend(d.attrHooks[f], {
            set: function (b, d) {
                if ("" === d) return b.setAttribute(f, "auto"), d
            }
        })
    }), d.attrHooks.contenteditable = {
        get: Z.get, set: function (b, d, h) {
            "" === d && (d = "false");
            Z.set(b, d, h)
        }
    });
    d.support.hrefNormalized || d.each(["href", "src", "width", "height"], function (b, f) {
        d.attrHooks[f] = d.extend(d.attrHooks[f], {
            get: function (b) {
                b = b.getAttribute(f, 2);
                return null === b ? e : b
            }
        })
    });
    d.support.style || (d.attrHooks.style = {
        get: function (b) {
            return b.style.cssText.toLowerCase() || e
        }, set: function (b, d) {
            return b.style.cssText = "" + d
        }
    });
    d.support.optSelected || (d.propHooks.selected = d.extend(d.propHooks.selected, {
        get: function (b) {
            b = b.parentNode;
            b && (b.selectedIndex, b.parentNode && b.parentNode.selectedIndex);
            return null
        }
    }));
    d.support.enctype || (d.propFix.enctype = "encoding");
    d.support.checkOn || d.each(["radio", "checkbox"], function () {
        d.valHooks[this] = {
            get: function (b) {
                return null === b.getAttribute("value") ?
                    "on" : b.value
            }
        }
    });
    d.each(["radio", "checkbox"], function () {
        d.valHooks[this] = d.extend(d.valHooks[this], {
            set: function (b, f) {
                if (d.isArray(f)) return b.checked = 0 <= d.inArray(d(b).val(), f)
            }
        })
    });
    var ta = /^(?:textarea|input|select)$/i, Ha = /^([^\.]*)?(?:\.(.+))?$/, ca = /(?:^|\s)hover(\.\S+)?\b/, eb = /^key/,
        fb = /^(?:mouse|contextmenu)|click/, La = /^(?:focusinfocus|focusoutblur)$/,
        gb = /^(\w*)(?:#([\w\-]+))?(?:\.([\w\-]+))?$/, hb = function (b) {
            (b = gb.exec(b)) && (b[1] = (b[1] || "").toLowerCase(), b[3] = b[3] && new RegExp("(?:^|\\s)" + b[3] +
                "(?:\\s|$)"));
            return b
        }, Ma = function (b) {
            return d.event.special.hover ? b : b.replace(ca, "mouseenter$1 mouseleave$1")
        };
    d.event = {
        add: function (b, f, h, a, c) {
            var n, l, g, k, x, r, q, t, p;
            if (3 !== b.nodeType && 8 !== b.nodeType && f && h && (n = d._data(b))) {
                h.handler && (q = h, h = q.handler, c = q.selector);
                h.guid || (h.guid = d.guid++);
                (g = n.events) || (n.events = g = {});
                (l = n.handle) || (n.handle = l = function (b) {
                    return "undefined" == typeof d || b && d.event.triggered === b.type ? e : d.event.dispatch.apply(l.elem, arguments)
                }, l.elem = b);
                f = d.trim(Ma(f)).split(" ");
                for (n = 0; n < f.length; n++) k = Ha.exec(f[n]) || [], x = k[1], r = (k[2] || "").split(".").sort(), p = d.event.special[x] || {}, x = (c ? p.delegateType : p.bindType) || x, p = d.event.special[x] || {}, k = d.extend({
                    type: x,
                    origType: k[1],
                    data: a,
                    handler: h,
                    guid: h.guid,
                    selector: c,
                    quick: c && hb(c),
                    namespace: r.join(".")
                }, q), t = g[x], t || (t = g[x] = [], t.delegateCount = 0, p.setup && !1 !== p.setup.call(b, a, r, l) || (b.addEventListener ? b.addEventListener(x, l, !1) : b.attachEvent && b.attachEvent("on" + x, l))), p.add && (p.add.call(b, k), k.handler.guid || (k.handler.guid = h.guid)),
                    c ? t.splice(t.delegateCount++, 0, k) : t.push(k), d.event.global[x] = !0;
                b = null
            }
        },
        global: {},
        remove: function (b, f, a, n, c) {
            var h = d.hasData(b) && d._data(b), e, l, g, k, x, r, q, t, p, m, C;
            if (h && (q = h.events)) {
                f = d.trim(Ma(f || "")).split(" ");
                for (e = 0; e < f.length; e++) if (l = Ha.exec(f[e]) || [], g = k = l[1], l = l[2], g) {
                    t = d.event.special[g] || {};
                    g = (n ? t.delegateType : t.bindType) || g;
                    m = q[g] || [];
                    x = m.length;
                    l = l ? new RegExp("(^|\\.)" + l.split(".").sort().join("\\.(?:.*\\.)?") + "(\\.|$)") : null;
                    for (r = 0; r < m.length; r++) C = m[r], !c && k !== C.origType || a && a.guid !==
                    C.guid || l && !l.test(C.namespace) || n && n !== C.selector && ("**" !== n || !C.selector) || (m.splice(r--, 1), C.selector && m.delegateCount--, !t.remove || t.remove.call(b, C));
                    0 === m.length && x !== m.length && ((!t.teardown || !1 === t.teardown.call(b, l)) && d.removeEvent(b, g, h.handle), delete q[g])
                } else for (g in q) d.event.remove(b, g + f[e], a, n, !0);
                d.isEmptyObject(q) && (p = h.handle, p && (p.elem = null), d.removeData(b, ["events", "handle"], !0))
            }
        },
        customEvent: {getData: !0, setData: !0, changeData: !0},
        trigger: function (b, f, h, n) {
            if (!h || 3 !== h.nodeType &&
                8 !== h.nodeType) {
                var c = b.type || b, l = [], g, k, r, q, t, p;
                if (!La.test(c + d.event.triggered) && (0 <= c.indexOf("!") && (c = c.slice(0, -1), g = !0), 0 <= c.indexOf(".") && (l = c.split("."), c = l.shift(), l.sort()), h && !d.event.customEvent[c] || d.event.global[c])) if (b = "object" == typeof b ? b[d.expando] ? b : new d.Event(c, b) : new d.Event(c), b.type = c, b.isTrigger = !0, b.exclusive = g, b.namespace = l.join("."), b.namespace_re = b.namespace ? new RegExp("(^|\\.)" + l.join("\\.(?:.*\\.)?") + "(\\.|$)") : null, g = 0 > c.indexOf(":") ? "on" + c : "", h) {
                    if (b.result = e, b.target ||
                    (b.target = h), f = null != f ? d.makeArray(f) : [], f.unshift(b), q = d.event.special[c] || {}, !q.trigger || !1 !== q.trigger.apply(h, f)) {
                        p = [[h, q.bindType || c]];
                        if (!n && !q.noBubble && !d.isWindow(h)) {
                            k = q.delegateType || c;
                            l = La.test(k + c) ? h : h.parentNode;
                            for (r = null; l; l = l.parentNode) p.push([l, k]), r = l;
                            r && r === h.ownerDocument && p.push([r.defaultView || r.parentWindow || a, k])
                        }
                        for (k = 0; k < p.length && !b.isPropagationStopped(); k++) l = p[k][0], b.type = p[k][1], (t = (d._data(l, "events") || {})[b.type] && d._data(l, "handle")) && t.apply(l, f), (t = g && l[g]) &&
                        d.acceptData(l) && !1 === t.apply(l, f) && b.preventDefault();
                        b.type = c;
                        !(n || b.isDefaultPrevented() || q._default && !1 !== q._default.apply(h.ownerDocument, f) || "click" === c && d.nodeName(h, "a")) && d.acceptData(h) && g && h[c] && ("focus" !== c && "blur" !== c || 0 !== b.target.offsetWidth) && !d.isWindow(h) && (r = h[g], r && (h[g] = null), d.event.triggered = c, h[c](), d.event.triggered = e, r && (h[g] = r));
                        return b.result
                    }
                } else for (k in h = d.cache, h) h[k].events && h[k].events[c] && d.event.trigger(b, f, h[k].handle.elem, !0)
            }
        },
        dispatch: function (b) {
            b = d.event.fix(b ||
                a.event);
            var f = (d._data(this, "events") || {})[b.type] || [], h = f.delegateCount, n = [].slice.call(arguments, 0),
                c = !b.exclusive && !b.namespace, l = d.event.special[b.type] || {}, g = [], k, r, q, t, p, m, C;
            n[0] = b;
            b.delegateTarget = this;
            if (!l.preDispatch || !1 !== l.preDispatch.call(this, b)) {
                if (h && (!b.button || "click" !== b.type)) for (q = d(this), q.context = this.ownerDocument || this, r = b.target; r != this; r = r.parentNode || this) if (!0 !== r.disabled) {
                    p = {};
                    m = [];
                    q[0] = r;
                    for (k = 0; k < h; k++) {
                        t = f[k];
                        C = t.selector;
                        if (p[C] === e) {
                            var w = p, y = C, u;
                            if (t.quick) {
                                u =
                                    t.quick;
                                var D = r.attributes || {};
                                u = (!u[1] || r.nodeName.toLowerCase() === u[1]) && (!u[2] || (D.id || {}).value === u[2]) && (!u[3] || u[3].test((D["class"] || {}).value))
                            } else u = q.is(C);
                            w[y] = u
                        }
                        p[C] && m.push(t)
                    }
                    m.length && g.push({elem: r, matches: m})
                }
                f.length > h && g.push({elem: this, matches: f.slice(h)});
                for (k = 0; k < g.length && !b.isPropagationStopped(); k++) for (h = g[k], b.currentTarget = h.elem, f = 0; f < h.matches.length && !b.isImmediatePropagationStopped(); f++) if (t = h.matches[f], c || !b.namespace && !t.namespace || b.namespace_re && b.namespace_re.test(t.namespace)) b.data =
                    t.data, b.handleObj = t, t = ((d.event.special[t.origType] || {}).handle || t.handler).apply(h.elem, n), t !== e && (b.result = t, !1 === t && (b.preventDefault(), b.stopPropagation()));
                l.postDispatch && l.postDispatch.call(this, b);
                return b.result
            }
        },
        props: "attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: ["char", "charCode", "key", "keyCode"], filter: function (b, d) {
                null == b.which &&
                (b.which = null != d.charCode ? d.charCode : d.keyCode);
                return b
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function (b, d) {
                var f, a, c, l = d.button, g = d.fromElement;
                null == b.pageX && null != d.clientX && (f = b.target.ownerDocument || w, a = f.documentElement, c = f.body, b.pageX = d.clientX + (a && a.scrollLeft || c && c.scrollLeft || 0) - (a && a.clientLeft || c && c.clientLeft || 0), b.pageY = d.clientY + (a && a.scrollTop || c && c.scrollTop || 0) - (a && a.clientTop || c &&
                    c.clientTop || 0));
                !b.relatedTarget && g && (b.relatedTarget = g === b.target ? d.toElement : g);
                !b.which && l !== e && (b.which = l & 1 ? 1 : l & 2 ? 3 : l & 4 ? 2 : 0);
                return b
            }
        },
        fix: function (b) {
            if (b[d.expando]) return b;
            var f, a, n = b, c = d.event.fixHooks[b.type] || {}, l = c.props ? this.props.concat(c.props) : this.props;
            b = d.Event(n);
            for (f = l.length; f;) a = l[--f], b[a] = n[a];
            b.target || (b.target = n.srcElement || w);
            3 === b.target.nodeType && (b.target = b.target.parentNode);
            b.metaKey === e && (b.metaKey = b.ctrlKey);
            return c.filter ? c.filter(b, n) : b
        },
        special: {
            ready: {setup: d.bindReady},
            load: {noBubble: !0},
            focus: {delegateType: "focusin"},
            blur: {delegateType: "focusout"},
            beforeunload: {
                setup: function (b, f, a) {
                    d.isWindow(this) && (this.onbeforeunload = a)
                }, teardown: function (b, d) {
                    this.onbeforeunload === d && (this.onbeforeunload = null)
                }
            }
        },
        simulate: function (b, f, a, n) {
            b = d.extend(new d.Event, a, {type: b, isSimulated: !0, originalEvent: {}});
            n ? d.event.trigger(b, null, f) : d.event.dispatch.call(f, b);
            b.isDefaultPrevented() && a.preventDefault()
        }
    };
    d.event.handle = d.event.dispatch;
    d.removeEvent = w.removeEventListener ? function (b,
                                                      d, a) {
        b.removeEventListener && b.removeEventListener(d, a, !1)
    } : function (b, d, a) {
        b.detachEvent && b.detachEvent("on" + d, a)
    };
    d.Event = function (b, f) {
        if (!(this instanceof d.Event)) return new d.Event(b, f);
        b && b.type ? (this.originalEvent = b, this.type = b.type, this.isDefaultPrevented = b.defaultPrevented || !1 === b.returnValue || b.getPreventDefault && b.getPreventDefault() ? G : N) : this.type = b;
        f && d.extend(this, f);
        this.timeStamp = b && b.timeStamp || d.now();
        this[d.expando] = !0
    };
    d.Event.prototype = {
        preventDefault: function () {
            this.isDefaultPrevented =
                G;
            var b = this.originalEvent;
            !b || (b.preventDefault ? b.preventDefault() : b.returnValue = !1)
        }, stopPropagation: function () {
            this.isPropagationStopped = G;
            var b = this.originalEvent;
            !b || (b.stopPropagation && b.stopPropagation(), b.cancelBubble = !0)
        }, stopImmediatePropagation: function () {
            this.isImmediatePropagationStopped = G;
            this.stopPropagation()
        }, isDefaultPrevented: N, isPropagationStopped: N, isImmediatePropagationStopped: N
    };
    d.each({mouseenter: "mouseover", mouseleave: "mouseout"}, function (b, f) {
        d.event.special[b] = {
            delegateType: f,
            bindType: f, handle: function (b) {
                var a = b.relatedTarget, h = b.handleObj, c;
                if (!a || a !== this && !d.contains(this, a)) b.type = h.origType, c = h.handler.apply(this, arguments), b.type = f;
                return c
            }
        }
    });
    d.support.submitBubbles || (d.event.special.submit = {
        setup: function () {
            if (d.nodeName(this, "form")) return !1;
            d.event.add(this, "click._submit keypress._submit", function (b) {
                b = b.target;
                (b = d.nodeName(b, "input") || d.nodeName(b, "button") ? b.form : e) && !b._submit_attached && (d.event.add(b, "submit._submit", function (b) {
                    b._submit_bubble = !0
                }),
                    b._submit_attached = !0)
            })
        }, postDispatch: function (b) {
            b._submit_bubble && (delete b._submit_bubble, this.parentNode && !b.isTrigger && d.event.simulate("submit", this.parentNode, b, !0))
        }, teardown: function () {
            if (d.nodeName(this, "form")) return !1;
            d.event.remove(this, "._submit")
        }
    });
    d.support.changeBubbles || (d.event.special.change = {
        setup: function () {
            if (ta.test(this.nodeName)) {
                if ("checkbox" === this.type || "radio" === this.type) d.event.add(this, "propertychange._change", function (b) {
                    "checked" === b.originalEvent.propertyName &&
                    (this._just_changed = !0)
                }), d.event.add(this, "click._change", function (b) {
                    this._just_changed && !b.isTrigger && (this._just_changed = !1, d.event.simulate("change", this, b, !0))
                });
                return !1
            }
            d.event.add(this, "beforeactivate._change", function (b) {
                b = b.target;
                ta.test(b.nodeName) && !b._change_attached && (d.event.add(b, "change._change", function (b) {
                    this.parentNode && !b.isSimulated && !b.isTrigger && d.event.simulate("change", this.parentNode, b, !0)
                }), b._change_attached = !0)
            })
        }, handle: function (b) {
            var d = b.target;
            if (this !== d || b.isSimulated ||
                b.isTrigger || "radio" !== d.type && "checkbox" !== d.type) return b.handleObj.handler.apply(this, arguments)
        }, teardown: function () {
            d.event.remove(this, "._change");
            return ta.test(this.nodeName)
        }
    });
    d.support.focusinBubbles || d.each({focus: "focusin", blur: "focusout"}, function (b, f) {
        var a = 0, n = function (b) {
            d.event.simulate(f, b.target, d.event.fix(b), !0)
        };
        d.event.special[f] = {
            setup: function () {
                0 === a++ && w.addEventListener(b, n, !0)
            }, teardown: function () {
                0 === --a && w.removeEventListener(b, n, !0)
            }
        }
    });
    d.fn.extend({
        on: function (b,
                      f, a, n, c) {
            var h, l;
            if ("object" == typeof b) {
                "string" != typeof f && (a = a || f, f = e);
                for (l in b) this.on(l, f, a, b[l], c);
                return this
            }
            null == a && null == n ? (n = f, a = f = e) : null == n && ("string" == typeof f ? (n = a, a = e) : (n = a, a = f, f = e));
            if (!1 === n) n = N; else if (!n) return this;
            1 === c && (h = n, n = function (b) {
                d().off(b);
                return h.apply(this, arguments)
            }, n.guid = h.guid || (h.guid = d.guid++));
            return this.each(function () {
                d.event.add(this, b, n, a, f)
            })
        }, one: function (b, d, a, n) {
            return this.on(b, d, a, n, 1)
        }, off: function (b, f, a) {
            if (b && b.preventDefault && b.handleObj) {
                var h =
                    b.handleObj;
                d(b.delegateTarget).off(h.namespace ? h.origType + "." + h.namespace : h.origType, h.selector, h.handler);
                return this
            }
            if ("object" == typeof b) {
                for (h in b) this.off(h, f, b[h]);
                return this
            }
            if (!1 === f || "function" == typeof f) a = f, f = e;
            !1 === a && (a = N);
            return this.each(function () {
                d.event.remove(this, b, a, f)
            })
        }, bind: function (b, d, a) {
            return this.on(b, null, d, a)
        }, unbind: function (b, d) {
            return this.off(b, null, d)
        }, live: function (b, f, a) {
            d(this.context).on(b, this.selector, f, a);
            return this
        }, die: function (b, f) {
            d(this.context).off(b,
                this.selector || "**", f);
            return this
        }, delegate: function (b, d, a, c) {
            return this.on(d, b, a, c)
        }, undelegate: function (b, d, a) {
            return 1 == arguments.length ? this.off(b, "**") : this.off(d, b, a)
        }, trigger: function (b, f) {
            return this.each(function () {
                d.event.trigger(b, f, this)
            })
        }, triggerHandler: function (b, f) {
            if (this[0]) return d.event.trigger(b, f, this[0], !0)
        }, toggle: function (b) {
            var f = arguments, a = b.guid || d.guid++, c = 0, l = function (a) {
                var h = (d._data(this, "lastToggle" + b.guid) || 0) % c;
                d._data(this, "lastToggle" + b.guid, h + 1);
                a.preventDefault();
                return f[h].apply(this, arguments) || !1
            };
            for (l.guid = a; c < f.length;) f[c++].guid = a;
            return this.click(l)
        }, hover: function (b, d) {
            return this.mouseenter(b).mouseleave(d || b)
        }
    });
    d.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function (b, f) {
        d.fn[f] = function (b, d) {
            null == d && (d = b, b = null);
            return 0 < arguments.length ? this.on(f, null, b, d) : this.trigger(f)
        };
        d.attrFn && (d.attrFn[f] = !0);
        eb.test(f) && (d.event.fixHooks[f] = d.event.keyHooks);
        fb.test(f) && (d.event.fixHooks[f] = d.event.mouseHooks)
    });
    (function () {
        function b(b, d, f, a, h, n) {
            h = 0;
            for (var l = a.length; h < l; h++) {
                var e = a[h];
                if (e) {
                    for (var g = !1, e = e[b]; e;) {
                        if (e[c] === f) {
                            g = a[e.sizset];
                            break
                        }
                        if (1 === e.nodeType) if (n || (e[c] = f, e.sizset = h), "string" != typeof d) {
                            if (e === d) {
                                g = !0;
                                break
                            }
                        } else if (0 < m.filter(d, [e]).length) {
                            g = e;
                            break
                        }
                        e = e[b]
                    }
                    a[h] = g
                }
            }
        }

        function f(b, d, f, a, h, n) {
            h = 0;
            for (var l = a.length; h < l; h++) {
                var e = a[h];
                if (e) {
                    for (var g =
                        !1, e = e[b]; e;) {
                        if (e[c] === f) {
                            g = a[e.sizset];
                            break
                        }
                        1 === e.nodeType && !n && (e[c] = f, e.sizset = h);
                        if (e.nodeName.toLowerCase() === d) {
                            g = e;
                            break
                        }
                        e = e[b]
                    }
                    a[h] = g
                }
            }
        }

        var a = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,
            c = "sizcache" + (Math.random() + "").replace(".", ""), l = 0, g = Object.prototype.toString, k = !1,
            r = !0, t = /\\/g, q = /\r\n/g, p = /\W/;
        [0, 0].sort(function () {
            r = !1;
            return 0
        });
        var m = function (b, d, f, h) {
            f = f || [];
            var c = d = d || w;
            if (1 !== d.nodeType &&
                9 !== d.nodeType) return [];
            if (!b || "string" != typeof b) return f;
            var n, e, l, k, r, K, t = !0, q = m.isXML(d), x = [], ba = b;
            do if (a.exec(""), n = a.exec(ba)) if (ba = n[3], x.push(n[1]), n[2]) {
                k = n[3];
                break
            } while (n);
            if (1 < x.length && u.exec(b)) if (2 === x.length && y.relative[x[0]]) e = v(x[0] + x[1], d, h); else for (e = y.relative[x[0]] ? [d] : m(x.shift(), d); x.length;) b = x.shift(), y.relative[b] && (b += x.shift()), e = v(b, e, h); else if (!h && 1 < x.length && 9 === d.nodeType && !q && y.match.ID.test(x[0]) && !y.match.ID.test(x[x.length - 1]) && (r = m.find(x.shift(), d, q), d = r.expr ?
                m.filter(r.expr, r.set)[0] : r.set[0]), d) for (r = h ? {
                expr: x.pop(),
                set: E(h)
            } : m.find(x.pop(), 1 !== x.length || "~" !== x[0] && "+" !== x[0] || !d.parentNode ? d : d.parentNode, q), e = r.expr ? m.filter(r.expr, r.set) : r.set, 0 < x.length ? l = E(e) : t = !1; x.length;) n = K = x.pop(), y.relative[K] ? n = x.pop() : K = "", null == n && (n = d), y.relative[K](l, n, q); else l = [];
            l || (l = e);
            l || m.error(K || b);
            if ("[object Array]" === g.call(l)) if (t) if (d && 1 === d.nodeType) for (b = 0; null != l[b]; b++) l[b] && (!0 === l[b] || 1 === l[b].nodeType && m.contains(d, l[b])) && f.push(e[b]); else for (b =
                                                                                                                                                                                                                    0; null != l[b]; b++) l[b] && 1 === l[b].nodeType && f.push(e[b]); else f.push.apply(f, l); else E(l, f);
            k && (m(k, c, f, h), m.uniqueSort(f));
            return f
        };
        m.uniqueSort = function (b) {
            if (z && (k = r, b.sort(z), k)) for (var d = 1; d < b.length; d++) b[d] === b[d - 1] && b.splice(d--, 1);
            return b
        };
        m.matches = function (b, d) {
            return m(b, null, null, d)
        };
        m.matchesSelector = function (b, d) {
            return 0 < m(d, null, null, [b]).length
        };
        m.find = function (b, d, f) {
            var a, h, c, n, l, e;
            if (!b) return [];
            h = 0;
            for (c = y.order.length; h < c; h++) if (l = y.order[h], n = y.leftMatch[l].exec(b)) if (e = n[1],
                n.splice(1, 1), "\\" !== e.substr(e.length - 1) && (n[1] = (n[1] || "").replace(t, ""), a = y.find[l](n, d, f), null != a)) {
                b = b.replace(y.match[l], "");
                break
            }
            a || (a = "undefined" != typeof d.getElementsByTagName ? d.getElementsByTagName("*") : []);
            return {set: a, expr: b}
        };
        m.filter = function (b, d, f, a) {
            for (var h, c, n, l, g, k, r, K, x = b, t = [], q = d, p = d && d[0] && m.isXML(d[0]); b && d.length;) {
                for (n in y.filter) if (null != (h = y.leftMatch[n].exec(b)) && h[2] && (k = y.filter[n], g = h[1], c = !1, h.splice(1, 1), "\\" !== g.substr(g.length - 1))) {
                    q === t && (t = []);
                    if (y.preFilter[n]) if (h =
                        y.preFilter[n](h, q, f, t, a, p), !h) c = l = !0; else if (!0 === h) continue;
                    if (h) for (r = 0; null != (g = q[r]); r++) g && (l = k(g, h, r, q), K = a ^ l, f && null != l ? K ? c = !0 : q[r] = !1 : K && (t.push(g), c = !0));
                    if (l !== e) {
                        f || (q = t);
                        b = b.replace(y.match[n], "");
                        if (!c) return [];
                        break
                    }
                }
                if (b === x) if (null == c) m.error(b); else break;
                x = b
            }
            return q
        };
        m.error = function (b) {
            throw Error("Syntax error, unrecognized expression: " + b);
        };
        var C = m.getText = function (b) {
            var d, f;
            d = b.nodeType;
            var a = "";
            if (d) if (1 === d || 9 === d || 11 === d) {
                if ("string" == typeof b.textContent) return b.textContent;
                if ("string" == typeof b.innerText) return b.innerText.replace(q, "");
                for (b = b.firstChild; b; b = b.nextSibling) a += C(b)
            } else {
                if (3 === d || 4 === d) return b.nodeValue
            } else for (d = 0; f = b[d]; d++) 8 !== f.nodeType && (a += C(f));
            return a
        }, y = m.selectors = {
            order: ["ID", "NAME", "TAG"], match: {
                ID: /#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
                CLASS: /\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
                NAME: /\[name=['"]*((?:[\w\u00c0-\uFFFF\-]|\\.)+)['"]*\]/,
                ATTR: /\[\s*((?:[\w\u00c0-\uFFFF\-]|\\.)+)\s*(?:(\S?=)\s*(?:(['"])(.*?)\3|(#?(?:[\w\u00c0-\uFFFF\-]|\\.)*)|)|)\s*\]/,
                TAG: /^((?:[\w\u00c0-\uFFFF\*\-]|\\.)+)/,
                CHILD: /:(only|nth|last|first)-child(?:\(\s*(even|odd|(?:[+\-]?\d+|(?:[+\-]?\d*)?n\s*(?:[+\-]\s*\d+)?))\s*\))?/,
                POS: /:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^\-]|$)/,
                PSEUDO: /:((?:[\w\u00c0-\uFFFF\-]|\\.)+)(?:\((['"]?)((?:\([^\)]+\)|[^\(\)]*)+)\2\))?/
            }, leftMatch: {}, attrMap: {"class": "className", "for": "htmlFor"}, attrHandle: {
                href: function (b) {
                    return b.getAttribute("href")
                }, type: function (b) {
                    return b.getAttribute("type")
                }
            }, relative: {
                "+": function (b, d) {
                    var f =
                        "string" == typeof d, a = f && !p.test(d), f = f && !a;
                    a && (d = d.toLowerCase());
                    for (var a = 0, h = b.length, c; a < h; a++) if (c = b[a]) {
                        for (; (c = c.previousSibling) && 1 !== c.nodeType;) ;
                        b[a] = f || c && c.nodeName.toLowerCase() === d ? c || !1 : c === d
                    }
                    f && m.filter(d, b, !0)
                }, ">": function (b, d) {
                    var f, a = "string" == typeof d, h = 0, c = b.length;
                    if (a && !p.test(d)) for (d = d.toLowerCase(); h < c; h++) {
                        if (f = b[h]) f = f.parentNode, b[h] = f.nodeName.toLowerCase() === d ? f : !1
                    } else {
                        for (; h < c; h++) (f = b[h]) && (b[h] = a ? f.parentNode : f.parentNode === d);
                        a && m.filter(d, b, !0)
                    }
                }, "": function (d,
                                 a, h) {
                    var c, n = l++, e = b;
                    "string" == typeof a && !p.test(a) && (a = a.toLowerCase(), c = a, e = f);
                    e("parentNode", a, n, d, c, h)
                }, "~": function (d, a, h) {
                    var c, n = l++, e = b;
                    "string" == typeof a && !p.test(a) && (a = a.toLowerCase(), c = a, e = f);
                    e("previousSibling", a, n, d, c, h)
                }
            }, find: {
                ID: function (b, d, f) {
                    if ("undefined" != typeof d.getElementById && !f) return (b = d.getElementById(b[1])) && b.parentNode ? [b] : []
                }, NAME: function (b, d) {
                    if ("undefined" != typeof d.getElementsByName) {
                        for (var f = [], a = d.getElementsByName(b[1]), h = 0, c = a.length; h < c; h++) a[h].getAttribute("name") ===
                        b[1] && f.push(a[h]);
                        return 0 === f.length ? null : f
                    }
                }, TAG: function (b, d) {
                    if ("undefined" != typeof d.getElementsByTagName) return d.getElementsByTagName(b[1])
                }
            }, preFilter: {
                CLASS: function (b, d, f, a, h, c) {
                    b = " " + b[1].replace(t, "") + " ";
                    if (c) return b;
                    c = 0;
                    for (var n; null != (n = d[c]); c++) n && (h ^ (n.className && 0 <= (" " + n.className + " ").replace(/[\t\n\r]/g, " ").indexOf(b)) ? f || a.push(n) : f && (d[c] = !1));
                    return !1
                }, ID: function (b) {
                    return b[1].replace(t, "")
                }, TAG: function (b, d) {
                    return b[1].replace(t, "").toLowerCase()
                }, CHILD: function (b) {
                    if ("nth" ===
                        b[1]) {
                        b[2] || m.error(b[0]);
                        b[2] = b[2].replace(/^\+|\s*/g, "");
                        var d = /(-?)(\d*)(?:n([+\-]?\d*))?/.exec("even" === b[2] && "2n" || "odd" === b[2] && "2n+1" || !/\D/.test(b[2]) && "0n+" + b[2] || b[2]);
                        b[2] = d[1] + (d[2] || 1) - 0;
                        b[3] = d[3] - 0
                    } else b[2] && m.error(b[0]);
                    b[0] = l++;
                    return b
                }, ATTR: function (b, d, f, a, h, c) {
                    d = b[1] = b[1].replace(t, "");
                    !c && y.attrMap[d] && (b[1] = y.attrMap[d]);
                    b[4] = (b[4] || b[5] || "").replace(t, "");
                    "~=" === b[2] && (b[4] = " " + b[4] + " ");
                    return b
                }, PSEUDO: function (b, d, f, h, c) {
                    if ("not" === b[1]) if (1 < (a.exec(b[3]) || "").length ||
                        /^\w/.test(b[3])) b[3] = m(b[3], null, null, d); else return b = m.filter(b[3], d, f, 1 ^ c), f || h.push.apply(h, b), !1; else if (y.match.POS.test(b[0]) || y.match.CHILD.test(b[0])) return !0;
                    return b
                }, POS: function (b) {
                    b.unshift(!0);
                    return b
                }
            }, filters: {
                enabled: function (b) {
                    return !1 === b.disabled && "hidden" !== b.type
                }, disabled: function (b) {
                    return !0 === b.disabled
                }, checked: function (b) {
                    return !0 === b.checked
                }, selected: function (b) {
                    b.parentNode && b.parentNode.selectedIndex;
                    return !0 === b.selected
                }, parent: function (b) {
                    return !!b.firstChild
                },
                empty: function (b) {
                    return !b.firstChild
                }, has: function (b, d, f) {
                    return !!m(f[3], b).length
                }, header: function (b) {
                    return /h\d/i.test(b.nodeName)
                }, text: function (b) {
                    var d = b.getAttribute("type"), f = b.type;
                    return "input" === b.nodeName.toLowerCase() && "text" === f && (d === f || null === d)
                }, radio: function (b) {
                    return "input" === b.nodeName.toLowerCase() && "radio" === b.type
                }, checkbox: function (b) {
                    return "input" === b.nodeName.toLowerCase() && "checkbox" === b.type
                }, file: function (b) {
                    return "input" === b.nodeName.toLowerCase() && "file" === b.type
                },
                password: function (b) {
                    return "input" === b.nodeName.toLowerCase() && "password" === b.type
                }, submit: function (b) {
                    var d = b.nodeName.toLowerCase();
                    return ("input" === d || "button" === d) && "submit" === b.type
                }, image: function (b) {
                    return "input" === b.nodeName.toLowerCase() && "image" === b.type
                }, reset: function (b) {
                    var d = b.nodeName.toLowerCase();
                    return ("input" === d || "button" === d) && "reset" === b.type
                }, button: function (b) {
                    var d = b.nodeName.toLowerCase();
                    return "input" === d && "button" === b.type || "button" === d
                }, input: function (b) {
                    return /input|select|textarea|button/i.test(b.nodeName)
                },
                focus: function (b) {
                    return b === b.ownerDocument.activeElement
                }
            }, setFilters: {
                first: function (b, d) {
                    return 0 === d
                }, last: function (b, d, f, a) {
                    return d === a.length - 1
                }, even: function (b, d) {
                    return 0 === d % 2
                }, odd: function (b, d) {
                    return 1 === d % 2
                }, lt: function (b, d, f) {
                    return d < f[3] - 0
                }, gt: function (b, d, f) {
                    return d > f[3] - 0
                }, nth: function (b, d, f) {
                    return f[3] - 0 === d
                }, eq: function (b, d, f) {
                    return f[3] - 0 === d
                }
            }, filter: {
                PSEUDO: function (b, d, f, a) {
                    var h = d[1], c = y.filters[h];
                    if (c) return c(b, f, d, a);
                    if ("contains" === h) return 0 <= (b.textContent || b.innerText ||
                        C([b]) || "").indexOf(d[3]);
                    if ("not" === h) {
                        d = d[3];
                        f = 0;
                        for (a = d.length; f < a; f++) if (d[f] === b) return !1;
                        return !0
                    }
                    m.error(h)
                }, CHILD: function (b, d) {
                    var f, a, h, n, l, e;
                    f = d[1];
                    e = b;
                    switch (f) {
                        case "only":
                        case "first":
                            for (; e = e.previousSibling;) if (1 === e.nodeType) return !1;
                            if ("first" === f) return !0;
                            e = b;
                        case "last":
                            for (; e = e.nextSibling;) if (1 === e.nodeType) return !1;
                            return !0;
                        case "nth":
                            f = d[2];
                            a = d[3];
                            if (1 === f && 0 === a) return !0;
                            h = d[0];
                            if ((n = b.parentNode) && (n[c] !== h || !b.nodeIndex)) {
                                l = 0;
                                for (e = n.firstChild; e; e = e.nextSibling) 1 === e.nodeType &&
                                (e.nodeIndex = ++l);
                                n[c] = h
                            }
                            e = b.nodeIndex - a;
                            return 0 === f ? 0 === e : 0 === e % f && 0 <= e / f
                    }
                }, ID: function (b, d) {
                    return 1 === b.nodeType && b.getAttribute("id") === d
                }, TAG: function (b, d) {
                    return "*" === d && 1 === b.nodeType || !!b.nodeName && b.nodeName.toLowerCase() === d
                }, CLASS: function (b, d) {
                    return -1 < (" " + (b.className || b.getAttribute("class")) + " ").indexOf(d)
                }, ATTR: function (b, d) {
                    var f = d[1],
                        f = m.attr ? m.attr(b, f) : y.attrHandle[f] ? y.attrHandle[f](b) : null != b[f] ? b[f] : b.getAttribute(f),
                        a = f + "", h = d[2], c = d[4];
                    return null == f ? "!=" === h : !h && m.attr ?
                        null != f : "=" === h ? a === c : "*=" === h ? 0 <= a.indexOf(c) : "~=" === h ? 0 <= (" " + a + " ").indexOf(c) : c ? "!=" === h ? a !== c : "^=" === h ? 0 === a.indexOf(c) : "$=" === h ? a.substr(a.length - c.length) === c : "|=" === h ? a === c || a.substr(0, c.length + 1) === c + "-" : !1 : a && !1 !== f
                }, POS: function (b, d, f, a) {
                    var h = y.setFilters[d[2]];
                    if (h) return h(b, f, d, a)
                }
            }
        }, u = y.match.POS, D = function (b, d) {
            return "\\" + (d - 0 + 1)
        }, A;
        for (A in y.match) y.match[A] = new RegExp(y.match[A].source + /(?![^\[]*\])(?![^\(]*\))/.source), y.leftMatch[A] = new RegExp(/(^(?:.|\r|\n)*?)/.source + y.match[A].source.replace(/\\(\d+)/g,
            D));
        y.match.globalPOS = u;
        var E = function (b, d) {
            b = Array.prototype.slice.call(b, 0);
            return d ? (d.push.apply(d, b), d) : b
        };
        try {
            Array.prototype.slice.call(w.documentElement.childNodes, 0)[0].nodeType
        } catch (K) {
            E = function (b, d) {
                var f = 0, a = d || [];
                if ("[object Array]" === g.call(b)) Array.prototype.push.apply(a, b); else if ("number" == typeof b.length) for (var h = b.length; f < h; f++) a.push(b[f]); else for (; b[f]; f++) a.push(b[f]);
                return a
            }
        }
        var z, B;
        w.documentElement.compareDocumentPosition ? z = function (b, d) {
            return b === d ? (k = !0, 0) : b.compareDocumentPosition &&
            d.compareDocumentPosition ? b.compareDocumentPosition(d) & 4 ? -1 : 1 : b.compareDocumentPosition ? -1 : 1
        } : (z = function (b, d) {
            if (b === d) return k = !0, 0;
            if (b.sourceIndex && d.sourceIndex) return b.sourceIndex - d.sourceIndex;
            var f, a, h = [], c = [];
            f = b.parentNode;
            a = d.parentNode;
            var n = f;
            if (f === a) return B(b, d);
            if (!f) return -1;
            if (!a) return 1;
            for (; n;) h.unshift(n), n = n.parentNode;
            for (n = a; n;) c.unshift(n), n = n.parentNode;
            f = h.length;
            a = c.length;
            for (n = 0; n < f && n < a; n++) if (h[n] !== c[n]) return B(h[n], c[n]);
            return n === f ? B(b, c[n], -1) : B(h[n], d, 1)
        },
            B = function (b, d, f) {
                if (b === d) return f;
                for (b = b.nextSibling; b;) {
                    if (b === d) return -1;
                    b = b.nextSibling
                }
                return 1
            });
        (function () {
            var b = w.createElement("div"), d = "script" + (new Date).getTime(), f = w.documentElement;
            b.innerHTML = "<a name='" + d + "'/>";
            f.insertBefore(b, f.firstChild);
            w.getElementById(d) && (y.find.ID = function (b, d, f) {
                if ("undefined" != typeof d.getElementById && !f) return (d = d.getElementById(b[1])) ? d.id === b[1] || "undefined" != typeof d.getAttributeNode && d.getAttributeNode("id").nodeValue === b[1] ? [d] : e : []
            }, y.filter.ID =
                function (b, d) {
                    var f = "undefined" != typeof b.getAttributeNode && b.getAttributeNode("id");
                    return 1 === b.nodeType && f && f.nodeValue === d
                });
            f.removeChild(b);
            f = b = null
        })();
        (function () {
            var b = w.createElement("div");
            b.appendChild(w.createComment(""));
            0 < b.getElementsByTagName("*").length && (y.find.TAG = function (b, d) {
                var f = d.getElementsByTagName(b[1]);
                if ("*" === b[1]) {
                    for (var a = [], h = 0; f[h]; h++) 1 === f[h].nodeType && a.push(f[h]);
                    f = a
                }
                return f
            });
            b.innerHTML = "<a href='#'></a>";
            b.firstChild && "undefined" != typeof b.firstChild.getAttribute &&
            "#" !== b.firstChild.getAttribute("href") && (y.attrHandle.href = function (b) {
                return b.getAttribute("href", 2)
            });
            b = null
        })();
        w.querySelectorAll && function () {
            var b = m, d = w.createElement("div");
            d.innerHTML = "<p class='TEST'></p>";
            if (!d.querySelectorAll || 0 !== d.querySelectorAll(".TEST").length) {
                m = function (d, f, a, h) {
                    f = f || w;
                    if (!h && !m.isXML(f)) {
                        var c = /^(\w+$)|^\.([\w\-]+$)|^#([\w\-]+$)/.exec(d);
                        if (c && (1 === f.nodeType || 9 === f.nodeType)) {
                            if (c[1]) return E(f.getElementsByTagName(d), a);
                            if (c[2] && y.find.CLASS && f.getElementsByClassName) return E(f.getElementsByClassName(c[2]),
                                a)
                        }
                        if (9 === f.nodeType) {
                            if ("body" === d && f.body) return E([f.body], a);
                            if (c && c[3]) {
                                var n = f.getElementById(c[3]);
                                if (!n || !n.parentNode) return E([], a);
                                if (n.id === c[3]) return E([n], a)
                            }
                            try {
                                return E(f.querySelectorAll(d), a)
                            } catch (Ka) {
                            }
                        } else if (1 === f.nodeType && "object" !== f.nodeName.toLowerCase()) {
                            var c = f, e = (n = f.getAttribute("id")) || "__sizzle__", l = f.parentNode,
                                g = /^\s*[+~]/.test(d);
                            n ? e = e.replace(/'/g, "\\$&") : f.setAttribute("id", e);
                            g && l && (f = f.parentNode);
                            try {
                                if (!g || l) return E(f.querySelectorAll("[id='" + e + "'] " + d),
                                    a)
                            } catch (Ka) {
                            } finally {
                                n || c.removeAttribute("id")
                            }
                        }
                    }
                    return b(d, f, a, h)
                };
                for (var f in b) m[f] = b[f];
                d = null
            }
        }();
        (function () {
            var b = w.documentElement,
                d = b.matchesSelector || b.mozMatchesSelector || b.webkitMatchesSelector || b.msMatchesSelector;
            if (d) {
                var f = !d.call(w.createElement("div"), "div"), a = !1;
                try {
                    d.call(w.documentElement, "[test!='']:sizzle")
                } catch (oa) {
                    a = !0
                }
                m.matchesSelector = function (b, h) {
                    h = h.replace(/\=\s*([^'"\]]*)\s*\]/g, "='$1']");
                    if (!m.isXML(b)) try {
                        if (a || !y.match.PSEUDO.test(h) && !/!=/.test(h)) {
                            var c = d.call(b,
                                h);
                            if (c || !f || b.document && 11 !== b.document.nodeType) return c
                        }
                    } catch (Tb) {
                    }
                    return 0 < m(h, null, null, [b]).length
                }
            }
        })();
        (function () {
            var b = w.createElement("div");
            b.innerHTML = "<div class='test e'></div><div class='test'></div>";
            b.getElementsByClassName && 0 !== b.getElementsByClassName("e").length && (b.lastChild.className = "e", 1 !== b.getElementsByClassName("e").length && (y.order.splice(1, 0, "CLASS"), y.find.CLASS = function (b, d, f) {
                if ("undefined" != typeof d.getElementsByClassName && !f) return d.getElementsByClassName(b[1])
            },
                b = null))
        })();
        w.documentElement.contains ? m.contains = function (b, d) {
            return b !== d && (b.contains ? b.contains(d) : !0)
        } : w.documentElement.compareDocumentPosition ? m.contains = function (b, d) {
            return !!(b.compareDocumentPosition(d) & 16)
        } : m.contains = function () {
            return !1
        };
        m.isXML = function (b) {
            return (b = (b ? b.ownerDocument || b : 0).documentElement) ? "HTML" !== b.nodeName : !1
        };
        var v = function (b, d, f) {
            var a, h = [], c = "";
            for (d = d.nodeType ? [d] : d; a = y.match.PSEUDO.exec(b);) c += a[0], b = b.replace(y.match.PSEUDO, "");
            b = y.relative[b] ? b + "*" : b;
            a = 0;
            for (var n = d.length; a < n; a++) m(b, d[a], h, f);
            return m.filter(c, h)
        };
        m.attr = d.attr;
        m.selectors.attrMap = {};
        d.find = m;
        d.expr = m.selectors;
        d.expr[":"] = d.expr.filters;
        d.unique = m.uniqueSort;
        d.text = m.getText;
        d.isXMLDoc = m.isXML;
        d.contains = m.contains
    })();
    var ib = /Until$/, jb = /^(?:parents|prevUntil|prevAll)/, kb = /,/, cb = /^.[^:#\[\.,]*$/,
        lb = Array.prototype.slice, Na = d.expr.match.globalPOS, mb = {children: !0, contents: !0, next: !0, prev: !0};
    d.fn.extend({
        find: function (b) {
            var f = this, a, c;
            if ("string" != typeof b) return d(b).filter(function () {
                a =
                    0;
                for (c = f.length; a < c; a++) if (d.contains(f[a], this)) return !0
            });
            var e = this.pushStack("", "find", b), l, g, k;
            a = 0;
            for (c = this.length; a < c; a++) if (l = e.length, d.find(b, this[a], e), 0 < a) for (g = l; g < e.length; g++) for (k = 0; k < l; k++) if (e[k] === e[g]) {
                e.splice(g--, 1);
                break
            }
            return e
        }, has: function (b) {
            var f = d(b);
            return this.filter(function () {
                for (var b = 0, a = f.length; b < a; b++) if (d.contains(this, f[b])) return !0
            })
        }, not: function (b) {
            return this.pushStack(Q(this, b, !1), "not", b)
        }, filter: function (b) {
            return this.pushStack(Q(this, b, !0), "filter",
                b)
        }, is: function (b) {
            return !!b && ("string" == typeof b ? Na.test(b) ? 0 <= d(b, this.context).index(this[0]) : 0 < d.filter(b, this).length : 0 < this.filter(b).length)
        }, closest: function (b, f) {
            var a = [], c, e, l = this[0];
            if (d.isArray(b)) {
                for (e = 1; l && l.ownerDocument && l !== f;) {
                    for (c = 0; c < b.length; c++) d(l).is(b[c]) && a.push({selector: b[c], elem: l, level: e});
                    l = l.parentNode;
                    e++
                }
                return a
            }
            var g = Na.test(b) || "string" != typeof b ? d(b, f || this.context) : 0;
            c = 0;
            for (e = this.length; c < e; c++) for (l = this[c]; l;) {
                if (g ? -1 < g.index(l) : d.find.matchesSelector(l,
                    b)) {
                    a.push(l);
                    break
                }
                l = l.parentNode;
                if (!l || !l.ownerDocument || l === f || 11 === l.nodeType) break
            }
            a = 1 < a.length ? d.unique(a) : a;
            return this.pushStack(a, "closest", b)
        }, index: function (b) {
            return b ? "string" == typeof b ? d.inArray(this[0], d(b)) : d.inArray(b._jQuery ? b[0] : b, this) : this[0] && this[0].parentNode ? this.prevAll().length : -1
        }, add: function (b, f) {
            var a = "string" == typeof b ? d(b, f) : d.makeArray(b && b.nodeType ? [b] : b), c = d.merge(this.get(), a);
            return this.pushStack(V(a[0]) || V(c[0]) ? c : d.unique(c))
        }, andSelf: function () {
            return this.add(this.prevObject)
        }
    });
    d.each({
        parent: function (b) {
            return (b = b.parentNode) && 11 !== b.nodeType ? b : null
        }, parents: function (b) {
            return d.dir(b, "parentNode")
        }, parentsUntil: function (b, f, a) {
            return d.dir(b, "parentNode", a)
        }, next: function (b) {
            return d.nth(b, 2, "nextSibling")
        }, prev: function (b) {
            return d.nth(b, 2, "previousSibling")
        }, nextAll: function (b) {
            return d.dir(b, "nextSibling")
        }, prevAll: function (b) {
            return d.dir(b, "previousSibling")
        }, nextUntil: function (b, f, a) {
            return d.dir(b, "nextSibling", a)
        }, prevUntil: function (b, f, a) {
            return d.dir(b, "previousSibling",
                a)
        }, siblings: function (b) {
            return d.sibling((b.parentNode || {}).firstChild, b)
        }, children: function (b) {
            return d.sibling(b.firstChild)
        }, contents: function (b) {
            return d.nodeName(b, "iframe") ? b.contentDocument || b.contentWindow.document : d.makeArray(b.childNodes)
        }
    }, function (b, f) {
        d.fn[b] = function (a, c) {
            var h = d.map(this, f, a);
            ib.test(b) || (c = a);
            c && "string" == typeof c && (h = d.filter(c, h));
            h = 1 < this.length && !mb[b] ? d.unique(h) : h;
            (1 < this.length || kb.test(c)) && jb.test(b) && (h = h.reverse());
            return this.pushStack(h, b, lb.call(arguments).join(","))
        }
    });
    d.extend({
        filter: function (b, f, a) {
            a && (b = ":not(" + b + ")");
            return 1 === f.length ? d.find.matchesSelector(f[0], b) ? [f[0]] : [] : d.find.matches(b, f)
        }, dir: function (b, f, a) {
            var c = [];
            for (b = b[f]; b && 9 !== b.nodeType && (a === e || 1 !== b.nodeType || !d(b).is(a));) 1 === b.nodeType && c.push(b), b = b[f];
            return c
        }, nth: function (b, d, a, c) {
            d = d || 1;
            for (c = 0; b && (1 !== b.nodeType || ++c !== d); b = b[a]) ;
            return b
        }, sibling: function (b, d) {
            for (var f = []; b; b = b.nextSibling) 1 === b.nodeType && b !== d && f.push(b);
            return f
        }
    });
    var Ja = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
        nb = / _jQuery\d+="(?:\d+|null)"/g, za = /^\s+/,
        Oa = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/ig, Pa = /<([\w:]+)/,
        ob = /<tbody/i, pb = /<|&#?\w+;/, qb = /<(?:script|style)/i, rb = /<(?:script|object|embed|option|style)/i,
        Qa = new RegExp("<(?:" + Ja + ")[\\s/>]", "i"), Ra = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Sa = /\/(java|ecma)script/i, sb = /^\s*<!(?:\[CDATA\[|\-\-)/, W = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            legend: [1, "<fieldset>", "</fieldset>"],
            thead: [1, "<table>", "</table>"],
            tr: [2, "<table><tbody>",
                "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
            area: [1, "<map>", "</map>"],
            _default: [0, "", ""]
        }, Aa = M(w);
    W.optgroup = W.option;
    W.tbody = W.tfoot = W.colgroup = W.caption = W.thead;
    W.th = W.td;
    d.support.htmlSerialize || (W._default = [1, "div<div>", "</div>"]);
    d.fn.extend({
        text: function (b) {
            return d.access(this, function (b) {
                return b === e ? d.text(this) : this.empty().append((this[0] && this[0].ownerDocument || w).createTextNode(b))
            }, null, b, arguments.length)
        },
        wrapAll: function (b) {
            if (d.isFunction(b)) return this.each(function (f) {
                d(this).wrapAll(b.call(this, f))
            });
            if (this[0]) {
                var f = d(b, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && f.insertBefore(this[0]);
                f.map(function () {
                    for (var b = this; b.firstChild && 1 === b.firstChild.nodeType;) b = b.firstChild;
                    return b
                }).append(this)
            }
            return this
        }, wrapInner: function (b) {
            return d.isFunction(b) ? this.each(function (f) {
                d(this).wrapInner(b.call(this, f))
            }) : this.each(function () {
                var f = d(this), a = f.contents();
                a.length ? a.wrapAll(b) :
                    f.append(b)
            })
        }, wrap: function (b) {
            var f = d.isFunction(b);
            return this.each(function (a) {
                d(this).wrapAll(f ? b.call(this, a) : b)
            })
        }, unwrap: function () {
            return this.parent().each(function () {
                d.nodeName(this, "body") || d(this).replaceWith(this.childNodes)
            }).end()
        }, append: function () {
            return this.domManip(arguments, !0, function (b) {
                1 === this.nodeType && this.appendChild(b)
            })
        }, prepend: function () {
            return this.domManip(arguments, !0, function (b) {
                1 === this.nodeType && this.insertBefore(b, this.firstChild)
            })
        }, before: function () {
            if (this[0] &&
                this[0].parentNode) return this.domManip(arguments, !1, function (b) {
                this.parentNode.insertBefore(b, this)
            });
            if (arguments.length) {
                var b = d.clean(arguments);
                b.push.apply(b, this.toArray());
                return this.pushStack(b, "before", arguments)
            }
        }, after: function () {
            if (this[0] && this[0].parentNode) return this.domManip(arguments, !1, function (b) {
                this.parentNode.insertBefore(b, this.nextSibling)
            });
            if (arguments.length) {
                var b = this.pushStack(this, "after", arguments);
                b.push.apply(b, d.clean(arguments));
                return b
            }
        }, remove: function (b,
                             f) {
            for (var a = 0, c; null != (c = this[a]); a++) if (!b || d.filter(b, [c]).length) !f && 1 === c.nodeType && (d.cleanData(c.getElementsByTagName("*")), d.cleanData([c])), c.parentNode && c.parentNode.removeChild(c);
            return this
        }, empty: function () {
            for (var b = 0, f; null != (f = this[b]); b++) for (1 === f.nodeType && d.cleanData(f.getElementsByTagName("*")); f.firstChild;) f.removeChild(f.firstChild);
            return this
        }, clone: function (b, f) {
            b = null == b ? !1 : b;
            f = null == f ? b : f;
            return this.map(function () {
                return d.clone(this, b, f)
            })
        }, html: function (b) {
            return d.access(this,
                function (b) {
                    var f = this[0] || {}, a = 0, c = this.length;
                    if (b === e) return 1 === f.nodeType ? f.innerHTML.replace(nb, "") : null;
                    if (!("string" != typeof b || qb.test(b) || !d.support.leadingWhitespace && za.test(b) || W[(Pa.exec(b) || ["", ""])[1].toLowerCase()])) {
                        b = b.replace(Oa, "<$1></$2>");
                        try {
                            for (; a < c; a++) f = this[a] || {}, 1 === f.nodeType && (d.cleanData(f.getElementsByTagName("*")), f.innerHTML = b);
                            f = 0
                        } catch (P) {
                        }
                    }
                    f && this.empty().append(b)
                }, null, b, arguments.length)
        }, replaceWith: function (b) {
            if (this[0] && this[0].parentNode) {
                if (d.isFunction(b)) return this.each(function (f) {
                    var a =
                        d(this), c = a.html();
                    a.replaceWith(b.call(this, f, c))
                });
                "string" != typeof b && (b = d(b).detach());
                return this.each(function () {
                    var f = this.nextSibling, a = this.parentNode;
                    d(this).remove();
                    f ? d(f).before(b) : d(a).append(b)
                })
            }
            return this.length ? this.pushStack(d(d.isFunction(b) ? b() : b), "replaceWith", b) : this
        }, detach: function (b) {
            return this.remove(b, !0)
        }, domManip: function (b, f, a) {
            var c, h, l, g = b[0], k = [];
            if (!d.support.checkClone && 3 === arguments.length && "string" == typeof g && Ra.test(g)) return this.each(function () {
                d(this).domManip(b,
                    f, a, !0)
            });
            if (d.isFunction(g)) return this.each(function (c) {
                var h = d(this);
                b[0] = g.call(this, c, f ? h.html() : e);
                h.domManip(b, f, a)
            });
            if (this[0]) {
                l = g && g.parentNode;
                d.support.parentNode && l && 11 === l.nodeType && l.childNodes.length === this.length ? c = {fragment: l} : c = d.buildFragment(b, this, k);
                l = c.fragment;
                1 === l.childNodes.length ? h = l = l.firstChild : h = l.firstChild;
                if (h) {
                    f = f && d.nodeName(h, "tr");
                    for (var r = 0, t = this.length, q = t - 1; r < t; r++) a.call(f ? O(this[r], h) : this[r], c.cacheable || 1 < t && r < q ? d.clone(l, !0, !0) : l)
                }
                k.length && d.each(k,
                    function (b, f) {
                        f.src ? d.ajax({
                            type: "GET",
                            global: !1,
                            url: f.src,
                            async: !1,
                            dataType: "script"
                        }) : d.globalEval((f.text || f.textContent || f.innerHTML || "").replace(sb, "/*$0*/"));
                        f.parentNode && f.parentNode.removeChild(f)
                    })
            }
            return this
        }
    });
    d.buildFragment = function (b, f, a) {
        var c, h, l, e, g = b[0];
        f && f[0] && (e = f[0].ownerDocument || f[0]);
        e.createDocumentFragment || (e = w);
        1 === b.length && "string" == typeof g && 512 > g.length && e === w && "<" === g.charAt(0) && !rb.test(g) && (d.support.checkClone || !Ra.test(g)) && (d.support.html5Clone || !Qa.test(g)) &&
        (h = !0, l = d.fragments[g], l && 1 !== l && (c = l));
        c || (c = e.createDocumentFragment(), d.clean(b, e, c, a));
        h && (d.fragments[g] = l ? c : 1);
        return {fragment: c, cacheable: h}
    };
    d.fragments = {};
    d.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function (b, f) {
        d.fn[b] = function (a) {
            var c = [];
            a = d(a);
            var h = 1 === this.length && this[0].parentNode;
            if (h && 11 === h.nodeType && 1 === h.childNodes.length && 1 === a.length) return a[f](this[0]), this;
            for (var h = 0, l = a.length; h < l; h++) {
                var e = (0 < h ? this.clone(!0) :
                    this).get();
                d(a[h])[f](e);
                c = c.concat(e)
            }
            return this.pushStack(c, b, a.selector)
        }
    });
    d.extend({
        clone: function (b, f, a) {
            var c, h, l;
            d.support.html5Clone || d.isXMLDoc(b) || !Qa.test("<" + b.nodeName + ">") ? c = b.cloneNode(!0) : (c = w.createElement("div"), Aa.appendChild(c), c.innerHTML = b.outerHTML, c = c.firstChild);
            var e = c;
            if (!(d.support.noCloneEvent && d.support.noCloneChecked || 1 !== b.nodeType && 11 !== b.nodeType || d.isXMLDoc(b))) for (D(b, e), c = y(b), h = y(e), l = 0; c[l]; ++l) h[l] && D(c[l], h[l]);
            if (f && (H(b, e), a)) for (c = y(b), h = y(e), l = 0; c[l]; ++l) H(c[l],
                h[l]);
            return e
        }, clean: function (b, f, a, c) {
            var h, n = [];
            f = f || w;
            "undefined" == typeof f.createElement && (f = f.ownerDocument || f[0] && f[0].ownerDocument || w);
            for (var l = 0, e; null != (e = b[l]); l++) if ("number" == typeof e && (e += ""), e) {
                if ("string" == typeof e) if (pb.test(e)) {
                    e = e.replace(Oa, "<$1></$2>");
                    h = (Pa.exec(e) || ["", ""])[1].toLowerCase();
                    var g = W[h] || W._default, k = g[0], r = f.createElement("div"), t = Aa.childNodes, q;
                    f === w ? Aa.appendChild(r) : M(f).appendChild(r);
                    for (r.innerHTML = g[1] + e + g[2]; k--;) r = r.lastChild;
                    if (!d.support.tbody) for (k =
                                                   ob.test(e), g = "table" !== h || k ? "<table>" !== g[1] || k ? [] : r.childNodes : r.firstChild && r.firstChild.childNodes, h = g.length - 1; 0 <= h; --h) d.nodeName(g[h], "tbody") && !g[h].childNodes.length && g[h].parentNode.removeChild(g[h]);
                    !d.support.leadingWhitespace && za.test(e) && r.insertBefore(f.createTextNode(za.exec(e)[0]), r.firstChild);
                    e = r.childNodes;
                    r && (r.parentNode.removeChild(r), 0 < t.length && (q = t[t.length - 1], q && q.parentNode && q.parentNode.removeChild(q)))
                } else e = f.createTextNode(e);
                var m;
                if (!d.support.appendChecked) if (e[0] &&
                    "number" == typeof(m = e.length)) for (h = 0; h < m; h++) A(e[h]); else A(e);
                e.nodeType ? n.push(e) : n = d.merge(n, e)
            }
            if (a) for (b = function (b) {
                return !b.type || Sa.test(b.type)
            }, l = 0; n[l]; l++) f = n[l], c && d.nodeName(f, "script") && (!f.type || Sa.test(f.type)) ? c.push(f.parentNode ? f.parentNode.removeChild(f) : f) : (1 === f.nodeType && (e = d.grep(f.getElementsByTagName("script"), b), n.splice.apply(n, [l + 1, 0].concat(e))), a.appendChild(f));
            return n
        }, cleanData: function (b) {
            for (var f, a, c = d.cache, e = d.event.special, l = d.support.deleteExpando, g = 0, k; null !=
            (k = b[g]); g++) if (!k.nodeName || !d.noData[k.nodeName.toLowerCase()]) if (a = k[d.expando]) {
                if ((f = c[a]) && f.events) {
                    for (var r in f.events) e[r] ? d.event.remove(k, r) : d.removeEvent(k, r, f.handle);
                    f.handle && (f.handle.elem = null)
                }
                l ? delete k[d.expando] : k.removeAttribute && k.removeAttribute(d.expando);
                delete c[a]
            }
        }
    });
    var Ba = /alpha\([^)]*\)/i, tb = /opacity=([^)]*)/, ub = /([A-Z]|^ms)/g, vb = /^[\-+]?(?:\d*\.)?\d+$/i,
        wa = /^-?(?:\d*\.)?\d+(?!px)[^\d\s]+$/i, wb = /^([\-+])=([\-+.\de]+)/, xb = /^margin/, yb = {
            position: "absolute", visibility: "hidden",
            display: "block"
        }, da = ["Top", "Right", "Bottom", "Left"], ha, Ta, Ua;
    d.fn.css = function (b, f) {
        return d.access(this, function (b, f, a) {
            return a !== e ? d.style(b, f, a) : d.css(b, f)
        }, b, f, 1 < arguments.length)
    };
    d.extend({
        cssHooks: {
            opacity: {
                get: function (b, d) {
                    if (d) {
                        var f = ha(b, "opacity");
                        return "" === f ? "1" : f
                    }
                    return b.style.opacity
                }
            }
        },
        cssNumber: {
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {"float": d.support.cssFloat ? "cssFloat" : "styleFloat"},
        style: function (b, f, a, c) {
            if (b &&
                3 !== b.nodeType && 8 !== b.nodeType && b.style) {
                var h, n = d.camelCase(f), l = b.style, g = d.cssHooks[n];
                f = d.cssProps[n] || n;
                if (a === e) return g && "get" in g && (h = g.get(b, !1, c)) !== e ? h : l[f];
                c = typeof a;
                "string" === c && (h = wb.exec(a)) && (a = +(h[1] + 1) * +h[2] + parseFloat(d.css(b, f)), c = "number");
                if (!(null == a || "number" === c && isNaN(a) || ("number" === c && !d.cssNumber[n] && (a += "px"), g && "set" in g && (a = g.set(b, a)) === e))) try {
                    l[f] = a
                } catch (Pb) {
                }
            }
        },
        css: function (b, f, a) {
            var c, h;
            f = d.camelCase(f);
            h = d.cssHooks[f];
            f = d.cssProps[f] || f;
            "cssFloat" === f && (f =
                "float");
            if (h && "get" in h && (c = h.get(b, !0, a)) !== e) return c;
            if (ha) return ha(b, f)
        },
        swap: function (b, d, a) {
            var f = {}, c;
            for (c in d) f[c] = b.style[c], b.style[c] = d[c];
            a = a.call(b);
            for (c in d) b.style[c] = f[c];
            return a
        }
    });
    d.curCSS = d.css;
    w.defaultView && w.defaultView.getComputedStyle && (Ta = function (b, f) {
        var a, c, l, e, g = b.style;
        f = f.replace(ub, "-$1").toLowerCase();
        (c = b.ownerDocument.defaultView) && (l = c.getComputedStyle(b, null)) && (a = l.getPropertyValue(f), "" === a && !d.contains(b.ownerDocument.documentElement, b) && (a = d.style(b,
            f)));
        !d.support.pixelMargin && l && xb.test(f) && wa.test(a) && (e = g.width, g.width = a, a = l.width, g.width = e);
        return a
    });
    w.documentElement.currentStyle && (Ua = function (b, d) {
        var f, a, c, l = b.currentStyle && b.currentStyle[d], e = b.style;
        null == l && e && (c = e[d]) && (l = c);
        wa.test(l) && (f = e.left, a = b.runtimeStyle && b.runtimeStyle.left, a && (b.runtimeStyle.left = b.currentStyle.left), e.left = "fontSize" === d ? "1em" : l, l = e.pixelLeft + "px", e.left = f, a && (b.runtimeStyle.left = a));
        return "" === l ? "auto" : l
    });
    ha = Ta || Ua;
    d.each(["height", "width"], function (b,
                                          f) {
        d.cssHooks[f] = {
            get: function (b, a, c) {
                if (a) return 0 !== b.offsetWidth ? t(b, f, c) : d.swap(b, yb, function () {
                    return t(b, f, c)
                })
            }, set: function (b, d) {
                return vb.test(d) ? d + "px" : d
            }
        }
    });
    d.support.opacity || (d.cssHooks.opacity = {
        get: function (b, d) {
            return tb.test((d && b.currentStyle ? b.currentStyle.filter : b.style.filter) || "") ? parseFloat(RegExp.$1) / 100 + "" : d ? "1" : ""
        }, set: function (b, f) {
            var a = b.style, c = b.currentStyle, l = d.isNumeric(f) ? "alpha(opacity=" + 100 * f + ")" : "",
                e = c && c.filter || a.filter || "";
            a.zoom = 1;
            if (1 <= f && "" === d.trim(e.replace(Ba,
                "")) && (a.removeAttribute("filter"), c && !c.filter)) return;
            a.filter = Ba.test(e) ? e.replace(Ba, l) : e + " " + l
        }
    });
    d(function () {
        d.support.reliableMarginRight || (d.cssHooks.marginRight = {
            get: function (b, f) {
                return d.swap(b, {display: "inline-block"}, function () {
                    return f ? ha(b, "margin-right") : b.style.marginRight
                })
            }
        })
    });
    d.expr && d.expr.filters && (d.expr.filters.hidden = function (b) {
        var f = b.offsetHeight;
        return 0 === b.offsetWidth && 0 === f || !d.support.reliableHiddenOffsets && "none" === (b.style && b.style.display || d.css(b, "display"))
    },
        d.expr.filters.visible = function (b) {
            return !d.expr.filters.hidden(b)
        });
    d.each({margin: "", padding: "", border: "Width"}, function (b, f) {
        d.cssHooks[b + f] = {
            expand: function (d) {
                var a = "string" == typeof d ? d.split(" ") : [d], c = {};
                for (d = 0; 4 > d; d++) c[b + da[d] + f] = a[d] || a[d - 2] || a[0];
                return c
            }
        }
    });
    var zb = /%20/g, bb = /\[\]$/, Va = /\r?\n/g, Ab = /#.*$/, Bb = /^(.*?):[ \t]*([^\r\n]*)\r?$/mg,
        Cb = /^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,
        Db = /^(?:GET|HEAD)$/, Eb = /^\/\//,
        Wa = /\?/, Fb = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, Gb = /^(?:select|textarea)/i, Ia = /\s+/,
        Hb = /([?&])_=[^&]*/, Xa = /^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+))?)?/, Ya = d.fn.load, va = {}, Za = {},
        ea, fa;
    try {
        ea = S.href
    } catch (b) {
        ea = w.createElement("a"), ea.href = "", ea = ea.href
    }
    fa = Xa.exec(ea.toLowerCase()) || [];
    d.fn.extend({
        load: function (b, f, a) {
            if ("string" != typeof b && Ya) return Ya.apply(this, arguments);
            if (!this.length) return this;
            var c = b.indexOf(" ");
            if (0 <= c) {
                var h = b.slice(c, b.length);
                b = b.slice(0, c)
            }
            c = "GET";
            f && (d.isFunction(f) ? (a = f, f = e) : "object" == typeof f && (f = d.param(f, d.ajaxSettings.traditional), c = "POST"));
            var l = this;
            d.ajax({
                url: b, type: c, dataType: "html", data: f, complete: function (b, f, c) {
                    c = b.responseText;
                    b.isResolved() && (b.done(function (b) {
                        c = b
                    }), l.html(h ? d("<div>").append(c.replace(Fb, "")).find(h) : c));
                    a && l.each(a, [c, f, b])
                }
            });
            return this
        }, serialize: function () {
            return d.param(this.serializeArray())
        }, serializeArray: function () {
            return this.map(function () {
                return this.elements ? d.makeArray(this.elements) : this
            }).filter(function () {
                return this.name &&
                    !this.disabled && (this.checked || Gb.test(this.nodeName) || Cb.test(this.type))
            }).map(function (b, f) {
                var a = d(this).val();
                return null == a ? null : d.isArray(a) ? d.map(a, function (b, d) {
                    return {name: f.name, value: b.replace(Va, "\r\n")}
                }) : {name: f.name, value: a.replace(Va, "\r\n")}
            }).get()
        }
    });
    d.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "), function (b, f) {
        d.fn[f] = function (b) {
            return this.on(f, b)
        }
    });
    d.each(["get", "post"], function (b, f) {
        d[f] = function (b, a, c, l) {
            d.isFunction(a) && (l = l || c, c = a, a =
                e);
            return d.ajax({type: f, url: b, data: a, success: c, dataType: l})
        }
    });
    d.extend({
        getScript: function (b, f) {
            return d.get(b, e, f, "script")
        }, getJSON: function (b, f, a) {
            return d.get(b, f, a, "json")
        }, ajaxSetup: function (b, f) {
            f ? v(b, d.ajaxSettings) : (f = b, b = d.ajaxSettings);
            v(b, f);
            return b
        }, ajaxSettings: {
            url: ea,
            isLocal: /^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/.test(fa[1]),
            global: !0,
            type: "GET",
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            processData: !0,
            async: !0,
            accepts: {
                xml: "application/xml, text/xml",
                html: "text/html", text: "text/plain", json: "application/json, text/javascript", "*": "*/*"
            },
            contents: {xml: /xml/, html: /html/, json: /json/},
            responseFields: {xml: "responseXML", text: "responseText"},
            converters: {"* text": a.String, "text html": !0, "text json": d.parseJSON, "text xml": d.parseXML},
            flatOptions: {context: !0, url: !0}
        }, ajaxPrefilter: B(va), ajaxTransport: B(Za), ajax: function (b, f) {
            function a(b, f, a, h) {
                if (2 !== D) {
                    D = 2;
                    u && clearTimeout(u);
                    w = e;
                    y = h || "";
                    v.readyState = 0 < b ? 4 : 0;
                    var n, m, p;
                    h = f;
                    if (a) {
                        var C = c, A = v, x = C.contents,
                            z = C.dataTypes, B = C.responseFields, G, L, F, N;
                        for (L in B) L in a && (A[B[L]] = a[L]);
                        for (; "*" === z[0];) z.shift(), G === e && (G = C.mimeType || A.getResponseHeader("content-type"));
                        if (G) for (L in x) if (x[L] && x[L].test(G)) {
                            z.unshift(L);
                            break
                        }
                        if (z[0] in a) F = z[0]; else {
                            for (L in a) {
                                if (!z[0] || C.converters[L + " " + z[0]]) {
                                    F = L;
                                    break
                                }
                                N || (N = L)
                            }
                            F = F || N
                        }
                        F ? (F !== z[0] && z.unshift(F), a = a[F]) : a = void 0
                    } else a = e;
                    if (200 <= b && 300 > b || 304 === b) {
                        if (c.ifModified) {
                            if (G = v.getResponseHeader("Last-Modified")) d.lastModified[q] = G;
                            if (G = v.getResponseHeader("Etag")) d.etag[q] =
                                G
                        }
                        if (304 === b) h = "notmodified", n = !0; else try {
                            G = c;
                            G.dataFilter && (a = G.dataFilter(a, G.dataType));
                            var H = G.dataTypes;
                            L = {};
                            var R, S, I = H.length, na, M = H[0], J, P, T, U, O;
                            for (R = 1; R < I; R++) {
                                if (1 === R) for (S in G.converters) "string" == typeof S && (L[S.toLowerCase()] = G.converters[S]);
                                J = M;
                                M = H[R];
                                if ("*" === M) M = J; else if ("*" !== J && J !== M) {
                                    P = J + " " + M;
                                    T = L[P] || L["* " + M];
                                    if (!T) for (U in O = e, L) if (na = U.split(" "), na[0] === J || "*" === na[0]) if (O = L[na[1] + " " + M]) {
                                        U = L[U];
                                        !0 === U ? T = O : !0 === O && (T = U);
                                        break
                                    }
                                    T || O || d.error("No conversion from " + P.replace(" ",
                                        " to "));
                                    !0 !== T && (a = T ? T(a) : O(U(a)))
                                }
                            }
                            m = a;
                            h = "success";
                            n = !0
                        } catch (Ib) {
                            h = "parsererror", p = Ib
                        }
                    } else if (p = h, !h || b) h = "error", 0 > b && (b = 0);
                    v.status = b;
                    v.statusText = "" + (f || h);
                    n ? k.resolveWith(l, [m, h, v]) : k.rejectWith(l, [v, h, p]);
                    v.statusCode(t);
                    t = e;
                    E && g.trigger("ajax" + (n ? "Success" : "Error"), [v, c, n ? m : p]);
                    r.fireWith(l, [v, h]);
                    E && (g.trigger("ajaxComplete", [v, c]), --d.active || d.event.trigger("ajaxStop"))
                }
            }

            "object" == typeof b && (f = b, b = e);
            f = f || {};
            var c = d.ajaxSetup({}, f), l = c.context || c, g = l !== c && (l.nodeType || l instanceof d) ?
                d(l) : d.event, k = d.Deferred(), r = d.Callbacks("once memory"), t = c.statusCode || {}, q, m = {},
                p = {}, y, C, w, u, A, D = 0, E, B, v = {
                    readyState: 0, setRequestHeader: function (b, d) {
                        if (!D) {
                            var f = b.toLowerCase();
                            b = p[f] = p[f] || b;
                            m[b] = d
                        }
                        return this
                    }, getAllResponseHeaders: function () {
                        return 2 === D ? y : null
                    }, getResponseHeader: function (b) {
                        var d;
                        if (2 === D) {
                            if (!C) for (C = {}; d = Bb.exec(y);) C[d[1].toLowerCase()] = d[2];
                            d = C[b.toLowerCase()]
                        }
                        return d === e ? null : d
                    }, overrideMimeType: function (b) {
                        D || (c.mimeType = b);
                        return this
                    }, abort: function (b) {
                        b = b || "abort";
                        w && w.abort(b);
                        a(0, b);
                        return this
                    }
                };
            k.promise(v);
            v.success = v.done;
            v.error = v.fail;
            v.complete = r.add;
            v.statusCode = function (b) {
                if (b) {
                    var d;
                    if (2 > D) for (d in b) t[d] = [t[d], b[d]]; else d = b[v.status], v.then(d, d)
                }
                return this
            };
            c.url = ((b || c.url) + "").replace(Ab, "").replace(Eb, fa[1] + "//");
            c.dataTypes = d.trim(c.dataType || "*").toLowerCase().split(Ia);
            null == c.crossDomain && (A = Xa.exec(c.url.toLowerCase()), c.crossDomain = !(!A || A[1] == fa[1] && A[2] == fa[2] && (A[3] || ("http:" === A[1] ? 80 : 443)) == (fa[3] || ("http:" === fa[1] ? 80 : 443))));
            c.data && c.processData && "string" != typeof c.data && (c.data = d.param(c.data, c.traditional));
            z(va, c, f, v);
            if (2 === D) return !1;
            E = c.global;
            c.type = c.type.toUpperCase();
            c.hasContent = !Db.test(c.type);
            E && 0 === d.active++ && d.event.trigger("ajaxStart");
            if (!c.hasContent && (c.data && (c.url += (Wa.test(c.url) ? "&" : "?") + c.data, delete c.data), q = c.url, !1 === c.cache)) {
                A = d.now();
                var G = c.url.replace(Hb, "$1_=" + A);
                c.url = G + (G === c.url ? (Wa.test(c.url) ? "&" : "?") + "_=" + A : "")
            }
            (c.data && c.hasContent && !1 !== c.contentType || f.contentType) && v.setRequestHeader("Content-Type",
                c.contentType);
            c.ifModified && (q = q || c.url, d.lastModified[q] && v.setRequestHeader("If-Modified-Since", d.lastModified[q]), d.etag[q] && v.setRequestHeader("If-None-Match", d.etag[q]));
            v.setRequestHeader("Accept", c.dataTypes[0] && c.accepts[c.dataTypes[0]] ? c.accepts[c.dataTypes[0]] + ("*" !== c.dataTypes[0] ? ", */*; q=0.01" : "") : c.accepts["*"]);
            for (B in c.headers) v.setRequestHeader(B, c.headers[B]);
            if (c.beforeSend && (!1 === c.beforeSend.call(l, v, c) || 2 === D)) return v.abort(), !1;
            for (B in{success: 1, error: 1, complete: 1}) v[B](c[B]);
            if (w = z(Za, c, f, v)) {
                v.readyState = 1;
                E && g.trigger("ajaxSend", [v, c]);
                c.async && 0 < c.timeout && (u = setTimeout(function () {
                    v.abort("timeout")
                }, c.timeout));
                try {
                    D = 1, w.send(m, a)
                } catch (ba) {
                    if (2 > D) a(-1, ba); else throw ba;
                }
            } else a(-1, "No Transport");
            return v
        }, param: function (b, f) {
            var a = [], c = function (b, f) {
                f = d.isFunction(f) ? f() : f;
                a[a.length] = encodeURIComponent(b) + "=" + encodeURIComponent(f)
            };
            f === e && (f = d.ajaxSettings.traditional);
            if (d.isArray(b) || b._jQuery && !d.isPlainObject(b)) d.each(b, function () {
                c(this.name, this.value)
            });
            else for (var l in b) g(l, b[l], f, c);
            return a.join("&").replace(zb, "+")
        }
    });
    d.extend({active: 0, lastModified: {}, etag: {}});
    var Jb = d.now(), pa = /(\=)\?(&|$)|\?\?/i;
    d.ajaxSetup({
        jsonp: "callback", jsonpCallback: function () {
            return d.expando + "_" + Jb++
        }
    });
    d.ajaxPrefilter("json jsonp", function (b, f, c) {
        f = "string" == typeof b.data && /^application\/x\-www\-form\-urlencoded/.test(b.contentType);
        if ("jsonp" === b.dataTypes[0] || !1 !== b.jsonp && (pa.test(b.url) || f && pa.test(b.data))) {
            var h, l = b.jsonpCallback = d.isFunction(b.jsonpCallback) ?
                b.jsonpCallback() : b.jsonpCallback, e = a[l], g = b.url, k = b.data, r = "$1" + l + "$2";
            !1 !== b.jsonp && (g = g.replace(pa, r), b.url === g && (f && (k = k.replace(pa, r)), b.data === k && (g += (/\?/.test(g) ? "&" : "?") + b.jsonp + "=" + l)));
            b.url = g;
            b.data = k;
            a[l] = function (b) {
                h = [b]
            };
            c.always(function () {
                a[l] = e;
                h && d.isFunction(e) && a[l](h[0])
            });
            b.converters["script json"] = function () {
                h || d.error(l + " was not called");
                return h[0]
            };
            b.dataTypes[0] = "json";
            return "script"
        }
    });
    d.ajaxSetup({
        accepts: {script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},
        contents: {script: /javascript|ecmascript/}, converters: {
            "text script": function (b) {
                d.globalEval(b);
                return b
            }
        }
    });
    d.ajaxPrefilter("script", function (b) {
        b.cache === e && (b.cache = !1);
        b.crossDomain && (b.type = "GET", b.global = !1)
    });
    d.ajaxTransport("script", function (b) {
        if (b.crossDomain) {
            var d, a = w.head || w.getElementsByTagName("head")[0] || w.documentElement;
            return {
                send: function (f, c) {
                    d = w.createElement("script");
                    d.async = "async";
                    b.scriptCharset && (d.charset = b.scriptCharset);
                    d.src = b.url;
                    d.onload = d.onreadystatechange = function (b,
                                                                f) {
                        if (f || !d.readyState || /loaded|complete/.test(d.readyState)) d.onload = d.onreadystatechange = null, a && d.parentNode && a.removeChild(d), d = e, f || c(200, "success")
                    };
                    a.insertBefore(d, a.firstChild)
                }, abort: function () {
                    d && d.onload(0, 1)
                }
            }
        }
    });
    var Ca = a.ActiveXObject ? function () {
        for (var b in ja) ja[b](0, 1)
    } : !1, Kb = 0, ja;
    d.ajaxSettings.xhr = a.ActiveXObject ? function () {
        var b;
        if (!(b = !this.isLocal && u())) a:{
            try {
                b = new a.ActiveXObject("Microsoft.XMLHTTP");
                break a
            } catch (f) {
            }
            b = void 0
        }
        return b
    } : u;
    (function (b) {
        d.extend(d.support, {
            ajax: !!b,
            cors: !!b && "withCredentials" in b
        })
    })(d.ajaxSettings.xhr());
    d.support.ajax && d.ajaxTransport(function (b) {
        if (!b.crossDomain || d.support.cors) {
            var f;
            return {
                send: function (c, l) {
                    var h = b.xhr(), n, g;
                    b.username ? h.open(b.type, b.url, b.async, b.username, b.password) : h.open(b.type, b.url, b.async);
                    if (b.xhrFields) for (g in b.xhrFields) h[g] = b.xhrFields[g];
                    b.mimeType && h.overrideMimeType && h.overrideMimeType(b.mimeType);
                    b.crossDomain || c["X-Requested-With"] || (c["X-Requested-With"] = "XMLHttpRequest");
                    try {
                        for (g in c) h.setRequestHeader(g,
                            c[g])
                    } catch (Ob) {
                    }
                    h.send(b.hasContent && b.data || null);
                    f = function (a, c) {
                        var g, k, r, q, t;
                        try {
                            if (f && (c || 4 === h.readyState)) if (f = e, n && (h.onreadystatechange = d.noop, Ca && delete ja[n]), c) 4 !== h.readyState && h.abort(); else {
                                g = h.status;
                                r = h.getAllResponseHeaders();
                                q = {};
                                (t = h.responseXML) && t.documentElement && (q.xml = t);
                                try {
                                    q.text = h.responseText
                                } catch (xa) {
                                }
                                try {
                                    k = h.statusText
                                } catch (xa) {
                                    k = ""
                                }
                                g || !b.isLocal || b.crossDomain ? 1223 === g && (g = 204) : g = q.text ? 200 : 404
                            }
                        } catch (xa) {
                            c || l(-1, xa)
                        }
                        q && l(g, k, q, r)
                    };
                    b.async && 4 !== h.readyState ? (n = ++Kb,
                    Ca && (ja || (ja = {}, d(a).unload(Ca)), ja[n] = f), h.onreadystatechange = f) : f()
                }, abort: function () {
                    f && f(0, 1)
                }
            }
        }
    });
    var ua = {}, aa, ga, Lb = /^(?:toggle|show|hide)$/, Mb = /^([+\-]=)?([\d+.\-]+)([a-z%]*)$/i, qa,
        la = [["height", "marginTop", "marginBottom", "paddingTop", "paddingBottom"], ["width", "marginLeft", "marginRight", "paddingLeft", "paddingRight"], ["opacity"]],
        ma;
    d.fn.extend({
        show: function (b, f, a) {
            var h;
            if (b || 0 === b) return this.animate(c("show", 3), b, f, a);
            f = 0;
            for (a = this.length; f < a; f++) b = this[f], b.style && (h = b.style.display, !d._data(b,
                "olddisplay") && "none" === h && (h = b.style.display = ""), ("" === h && "none" === d.css(b, "display") || !d.contains(b.ownerDocument.documentElement, b)) && d._data(b, "olddisplay", m(b.nodeName)));
            for (f = 0; f < a; f++) if (b = this[f], b.style && (h = b.style.display, "" === h || "none" === h)) b.style.display = d._data(b, "olddisplay") || "";
            return this
        }, hide: function (b, f, a) {
            if (b || 0 === b) return this.animate(c("hide", 3), b, f, a);
            var h;
            f = 0;
            for (a = this.length; f < a; f++) b = this[f], b.style && (h = d.css(b, "display"), "none" !== h && !d._data(b, "olddisplay") && d._data(b,
                "olddisplay", h));
            for (f = 0; f < a; f++) this[f].style && (this[f].style.display = "none");
            return this
        }, _toggle: d.fn.toggle, toggle: function (b, a, h) {
            var f = "boolean" == typeof b;
            d.isFunction(b) && d.isFunction(a) ? this._toggle.apply(this, arguments) : null == b || f ? this.each(function () {
                var a = f ? b : d(this).is(":hidden");
                d(this)[a ? "show" : "hide"]()
            }) : this.animate(c("toggle", 3), b, a, h);
            return this
        }, fadeTo: function (b, d, a, c) {
            return this.filter(":hidden").css("opacity", 0).show().end().animate({opacity: d}, b, a, c)
        }, animate: function (b,
                              a, c, l) {
            function f() {
                !1 === h.queue && d._mark(this);
                var a = d.extend({}, h), f = 1 === this.nodeType, c = f && d(this).is(":hidden"), l, e, g, n, k, r, q,
                    t, p;
                a.animatedProperties = {};
                for (g in b) if (l = d.camelCase(g), g !== l && (b[l] = b[g], delete b[g]), (e = d.cssHooks[l]) && "expand" in e) for (g in n = e.expand(b[l]), delete b[l], n) g in b || (b[g] = n[g]);
                for (l in b) {
                    e = b[l];
                    d.isArray(e) ? (a.animatedProperties[l] = e[1], e = b[l] = e[0]) : a.animatedProperties[l] = a.specialEasing && a.specialEasing[l] || a.easing || "swing";
                    if ("hide" === e && c || "show" === e && !c) return a.complete.call(this);
                    f && ("height" === l || "width" === l) && (a.overflow = [this.style.overflow, this.style.overflowX, this.style.overflowY], "inline" === d.css(this, "display") && "none" === d.css(this, "float") && (d.support.inlineBlockNeedsLayout && "inline" !== m(this.nodeName) ? this.style.zoom = 1 : this.style.display = "inline-block"))
                }
                null != a.overflow && (this.style.overflow = "hidden");
                for (g in b) f = new d.fx(this, a, g), e = b[g], Lb.test(e) ? (p = d._data(this, "toggle" + g) || ("toggle" === e ? c ? "show" : "hide" : 0), p ? (d._data(this, "toggle" + g, "show" === p ? "hide" : "show"),
                    f[p]()) : f[e]()) : (k = Mb.exec(e), r = f.cur(), k ? (q = parseFloat(k[2]), t = k[3] || (d.cssNumber[g] ? "" : "px"), "px" !== t && (d.style(this, g, (q || 1) + t), r *= (q || 1) / f.cur(), d.style(this, g, r + t)), k[1] && (q = ("-=" === k[1] ? -1 : 1) * q + r), f.custom(r, q, t)) : f.custom(r, e, ""));
                return !0
            }

            var h = d.speed(a, c, l);
            if (d.isEmptyObject(b)) return this.each(h.complete, [!1]);
            b = d.extend({}, b);
            return !1 === h.queue ? this.each(f) : this.queue(h.queue, f)
        }, stop: function (b, a, c) {
            "string" != typeof b && (c = a, a = b, b = e);
            a && !1 !== b && this.queue(b || "fx", []);
            return this.each(function () {
                var a,
                    f = !1, h = d.timers, l = d._data(this);
                c || d._unmark(!0, this);
                if (null == b) for (a in l) {
                    if (l[a] && l[a].stop && a.indexOf(".run") === a.length - 4) {
                        var e = l[a];
                        d.removeData(this, a, !0);
                        e.stop(c)
                    }
                } else l[a = b + ".run"] && l[a].stop && (l = l[a], d.removeData(this, a, !0), l.stop(c));
                for (a = h.length; a--;) h[a].elem !== this || null != b && h[a].queue !== b || (c ? h[a](!0) : h[a].saveState(), f = !0, h.splice(a, 1));
                c && f || d.dequeue(this, b)
            })
        }
    });
    d.each({
        slideDown: c("show", 1),
        slideUp: c("hide", 1),
        slideToggle: c("toggle", 1),
        fadeIn: {opacity: "show"},
        fadeOut: {opacity: "hide"},
        fadeToggle: {opacity: "toggle"}
    }, function (b, a) {
        d.fn[b] = function (b, d, f) {
            return this.animate(a, b, d, f)
        }
    });
    d.extend({
        speed: function (b, a, c) {
            var f = b && "object" == typeof b ? d.extend({}, b) : {
                complete: c || !c && a || d.isFunction(b) && b,
                duration: b,
                easing: c && a || a && !d.isFunction(a) && a
            };
            f.duration = d.fx.off ? 0 : "number" == typeof f.duration ? f.duration : f.duration in d.fx.speeds ? d.fx.speeds[f.duration] : d.fx.speeds._default;
            if (null == f.queue || !0 === f.queue) f.queue = "fx";
            f.old = f.complete;
            f.complete = function (b) {
                d.isFunction(f.old) && f.old.call(this);
                f.queue ? d.dequeue(this, f.queue) : !1 !== b && d._unmark(this)
            };
            return f
        }, easing: {
            linear: function (b) {
                return b
            }, swing: function (b) {
                return -Math.cos(b * Math.PI) / 2 + .5
            }
        }, timers: [], fx: function (b, d, a) {
            this.options = d;
            this.elem = b;
            this.prop = a;
            d.orig = d.orig || {}
        }
    });
    d.fx.prototype = {
        update: function () {
            this.options.step && this.options.step.call(this.elem, this.now, this);
            (d.fx.step[this.prop] || d.fx.step._default)(this)
        }, cur: function () {
            if (null != this.elem[this.prop] && (!this.elem.style || null == this.elem.style[this.prop])) return this.elem[this.prop];
            var b, a = d.css(this.elem, this.prop);
            return isNaN(b = parseFloat(a)) ? a && "auto" !== a ? a : 0 : b
        }, custom: function (b, a, c) {
            function f(b) {
                return h.step(b)
            }

            var h = this, l = d.fx;
            this.startTime = ma || q();
            this.end = a;
            this.now = this.start = b;
            this.pos = this.state = 0;
            this.unit = c || this.unit || (d.cssNumber[this.prop] ? "" : "px");
            f.queue = this.options.queue;
            f.elem = this.elem;
            f.saveState = function () {
                d._data(h.elem, "fxshow" + h.prop) === e && (h.options.hide ? d._data(h.elem, "fxshow" + h.prop, h.start) : h.options.show && d._data(h.elem, "fxshow" + h.prop, h.end))
            };
            f() && d.timers.push(f) && !qa && (qa = setInterval(l.tick, l.interval))
        }, show: function () {
            var b = d._data(this.elem, "fxshow" + this.prop);
            this.options.orig[this.prop] = b || d.style(this.elem, this.prop);
            this.options.show = !0;
            b !== e ? this.custom(this.cur(), b) : this.custom("width" === this.prop || "height" === this.prop ? 1 : 0, this.cur());
            d(this.elem).show()
        }, hide: function () {
            this.options.orig[this.prop] = d._data(this.elem, "fxshow" + this.prop) || d.style(this.elem, this.prop);
            this.options.hide = !0;
            this.custom(this.cur(), 0)
        }, step: function (b) {
            var a,
                c, l = ma || q(), e = !0, g = this.elem, k = this.options;
            if (b || l >= k.duration + this.startTime) {
                this.now = this.end;
                this.pos = this.state = 1;
                this.update();
                k.animatedProperties[this.prop] = !0;
                for (a in k.animatedProperties) !0 !== k.animatedProperties[a] && (e = !1);
                if (e) {
                    null != k.overflow && !d.support.shrinkWrapBlocks && d.each(["", "X", "Y"], function (b, d) {
                        g.style["overflow" + d] = k.overflow[b]
                    });
                    k.hide && d(g).hide();
                    if (k.hide || k.show) for (a in k.animatedProperties) d.style(g, a, k.orig[a]), d.removeData(g, "fxshow" + a, !0), d.removeData(g, "toggle" +
                        a, !0);
                    (b = k.complete) && (k.complete = !1, b.call(g))
                }
                return !1
            }
            Infinity == k.duration ? this.now = l : (c = l - this.startTime, this.state = c / k.duration, this.pos = d.easing[k.animatedProperties[this.prop]](this.state, c, 0, 1, k.duration), this.now = this.start + (this.end - this.start) * this.pos);
            this.update();
            return !0
        }
    };
    d.extend(d.fx, {
        tick: function () {
            for (var b, a = d.timers, c = 0; c < a.length; c++) b = a[c], !b() && a[c] === b && a.splice(c--, 1);
            a.length || d.fx.stop()
        }, interval: 13, stop: function () {
            clearInterval(qa);
            qa = null
        }, speeds: {
            slow: 600, fast: 200,
            _default: 400
        }, step: {
            opacity: function (b) {
                d.style(b.elem, "opacity", b.now)
            }, _default: function (b) {
                b.elem.style && null != b.elem.style[b.prop] ? b.elem.style[b.prop] = b.now + b.unit : b.elem[b.prop] = b.now
            }
        }
    });
    d.each(la.concat.apply([], la), function (b, a) {
        a.indexOf("margin") && (d.fx.step[a] = function (b) {
            d.style(b.elem, a, Math.max(0, b.now) + b.unit)
        })
    });
    d.expr && d.expr.filters && (d.expr.filters.animated = function (b) {
        return d.grep(d.timers, function (d) {
            return b === d.elem
        }).length
    });
    var Da, Nb = /^t(?:able|d|h)$/i, $a = /^(?:body|html)$/i;
    "getBoundingClientRect" in w.documentElement ? Da = function (b, a, c, l) {
        try {
            l = b.getBoundingClientRect()
        } catch (x) {
        }
        if (!l || !d.contains(c, b)) return l ? {top: l.top, left: l.left} : {top: 0, left: 0};
        b = a.body;
        a = p(a);
        return {
            top: l.top + (a.pageYOffset || d.support.boxModel && c.scrollTop || b.scrollTop) - (c.clientTop || b.clientTop || 0),
            left: l.left + (a.pageXOffset || d.support.boxModel && c.scrollLeft || b.scrollLeft) - (c.clientLeft || b.clientLeft || 0)
        }
    } : Da = function (b, a, c) {
        var f, h = b.offsetParent, l = a.body;
        f = (a = a.defaultView) ? a.getComputedStyle(b,
            null) : b.currentStyle;
        for (var e = b.offsetTop, g = b.offsetLeft; (b = b.parentNode) && b !== l && b !== c && (!d.support.fixedPosition || "fixed" !== f.position);) f = a ? a.getComputedStyle(b, null) : b.currentStyle, e -= b.scrollTop, g -= b.scrollLeft, b === h && (e += b.offsetTop, g += b.offsetLeft, d.support.doesNotAddBorder && (!d.support.doesAddBorderForTableAndCells || !Nb.test(b.nodeName)) && (e += parseFloat(f.borderTopWidth) || 0, g += parseFloat(f.borderLeftWidth) || 0), h = b.offsetParent), d.support.subtractsBorderForOverflowNotVisible && "visible" !==
        f.overflow && (e += parseFloat(f.borderTopWidth) || 0, g += parseFloat(f.borderLeftWidth) || 0);
        if ("relative" === f.position || "static" === f.position) e += l.offsetTop, g += l.offsetLeft;
        d.support.fixedPosition && "fixed" === f.position && (e += Math.max(c.scrollTop, l.scrollTop), g += Math.max(c.scrollLeft, l.scrollLeft));
        return {top: e, left: g}
    };
    d.fn.offset = function (b) {
        if (arguments.length) return b === e ? this : this.each(function (a) {
            d.offset.setOffset(this, b, a)
        });
        var a = this[0], c = a && a.ownerDocument;
        return c ? a === c.body ? d.offset.bodyOffset(a) :
            Da(a, c, c.documentElement) : null
    };
    d.offset = {
        bodyOffset: function (b) {
            var a = b.offsetTop, c = b.offsetLeft;
            d.support.doesNotIncludeMarginInBodyOffset && (a += parseFloat(d.css(b, "marginTop")) || 0, c += parseFloat(d.css(b, "marginLeft")) || 0);
            return {top: a, left: c}
        }, setOffset: function (b, a, c) {
            var f = d.css(b, "position");
            "static" === f && (b.style.position = "relative");
            var h = d(b), l = h.offset(), e = d.css(b, "top"), g = d.css(b, "left"), k = {}, r = {}, q, t;
            ("absolute" === f || "fixed" === f) && -1 < d.inArray("auto", [e, g]) ? (r = h.position(), q = r.top, t = r.left) :
                (q = parseFloat(e) || 0, t = parseFloat(g) || 0);
            d.isFunction(a) && (a = a.call(b, c, l));
            null != a.top && (k.top = a.top - l.top + q);
            null != a.left && (k.left = a.left - l.left + t);
            "using" in a ? a.using.call(b, k) : h.css(k)
        }
    };
    d.fn.extend({
        position: function () {
            if (!this[0]) return null;
            var b = this[0], a = this.offsetParent(), c = this.offset(),
                l = $a.test(a[0].nodeName) ? {top: 0, left: 0} : a.offset();
            c.top -= parseFloat(d.css(b, "marginTop")) || 0;
            c.left -= parseFloat(d.css(b, "marginLeft")) || 0;
            l.top += parseFloat(d.css(a[0], "borderTopWidth")) || 0;
            l.left += parseFloat(d.css(a[0],
                "borderLeftWidth")) || 0;
            return {top: c.top - l.top, left: c.left - l.left}
        }, offsetParent: function () {
            return this.map(function () {
                for (var b = this.offsetParent || w.body; b && !$a.test(b.nodeName) && "static" === d.css(b, "position");) b = b.offsetParent;
                return b
            })
        }
    });
    d.each({scrollLeft: "pageXOffset", scrollTop: "pageYOffset"}, function (b, a) {
        var f = /Y/.test(a);
        d.fn[b] = function (c) {
            return d.access(this, function (b, c, l) {
                var h = p(b);
                if (l === e) return h ? a in h ? h[a] : d.support.boxModel && h.document.documentElement[c] || h.document.body[c] : b[c];
                h ? h.scrollTo(f ? d(h).scrollLeft() : l, f ? l : d(h).scrollTop()) : b[c] = l
            }, b, c, arguments.length, null)
        }
    });
    d.each({Height: "height", Width: "width"}, function (b, a) {
        var f = "client" + b, c = "scroll" + b, l = "offset" + b;
        d.fn["inner" + b] = function () {
            var b = this[0];
            return b ? b.style ? parseFloat(d.css(b, a, "padding")) : this[a]() : null
        };
        d.fn["outer" + b] = function (b) {
            var f = this[0];
            return f ? f.style ? parseFloat(d.css(f, a, b ? "margin" : "border")) : this[a]() : null
        };
        d.fn[a] = function (b) {
            return d.access(this, function (b, a, h) {
                if (d.isWindow(b)) return a = b.document,
                    b = a.documentElement[f], d.support.boxModel && b || a.body && a.body[f] || b;
                if (9 === b.nodeType) return a = b.documentElement, a[f] >= a[c] ? a[f] : Math.max(b.body[c], a[c], b.body[l], a[l]);
                if (h === e) return b = d.css(b, a), a = parseFloat(b), d.isNumeric(a) ? a : b;
                d(b).css(a, h)
            }, a, b, arguments.length, null)
        }
    });
    a._jQuery = a._$ = d;
    "function" == typeof define && define.amd && define.amd._jQuery && define("_jQuery", [], function () {
        return d
    })
})(window);
/*
 loadCSS: load a CSS file asynchronously.
[c]2015 @scottjehl, Filament Group, Inc.
Licensed MIT
 onloadCSS: adds onload support for asynchronous stylesheets loaded with loadCSS.
[c]2014 @zachleat, Filament Group, Inc.
Licensed MIT
*/
(function (a) {
    a.loadCSS = function (e, p, m) {
        var c = a.document.createElement("link"), k;
        p ? k = p : a.document.querySelectorAll ? (k = a.document.querySelectorAll("style,link[rel=stylesheet],script"), k = k[k.length - 1]) : k = a.document.getElementsByTagName("script")[0];
        c.rel = "stylesheet";
        c.href = e;
        c.media = m || "all";
        k.parentNode.insertBefore(c, p ? k : k.nextSibling);
        return c
    }
})(this);

function onloadCSS(a, e) {
    a.onload = function () {
        a.onload = null;
        e && e.call(a)
    };
    if ("isApplicationInstalled" in navigator && "onloadcssdefined" in a) a.onloadcssdefined(e)
};(function () {
    var a = "msie" == (/(msie) ([\w.]+)/.exec(navigator.userAgent.toLowerCase()) || [])[1];
    window.avsr = window.avsr || {};
    window.avsr.ajax = new function () {
        _$.support.cors = !0;
        this.post = function (e, p, m, c) {
            e = e.replace("http:", document.location.protocol);
            var k = "";
            "?sandbox" == document.location.search.substr(0, 8) && (k = "sandbox=true&");
            if (window.avsr.specifics && window.avsr.utils.getSpecificsConf().availability && window.avsr.utils.getSpecificsConf().availability.logParametersInQuery && (-1 == e.indexOf("Monitoring/Log") ||
                -1 != e.indexOf("Monitoring/LogCall"))) {
                var q = {
                    market: p.market ? p.market : "null",
                    lang: p.lang ? p.lang : "null",
                    ownerId: p.ownerId ? p.ownerId : p.webSiteId ? p.webSiteId : "null",
                    catalogId: p.catalogId ? p.catalogId : "null",
                    action: p.action ? p.action : "null",
                    userId: p.userId ? p.userId : "null",
                    rel: p.actionName ? p.actionName : "null",
                    location: p.location ? p.location : "null",
                    trackerLabel: p.trackerLabel ? p.trackerLabel : "null",
                    subTrackerLabel: p.subTrackerLabel ? p.subTrackerLabel : "null",
                    clientProductId: p.clientProductId ? p.clientProductId :
                        p.clientProductIds ? p.clientProductIds : "null"
                };
                -1 != e.indexOf("Monitoring/LogCall") && (q = {
                    webSiteId: window.avsr.utils.getSpecificsConf().project.Id,
                    cookieEnabled: navigator.cookieEnabled,
                    counter: p.counter ? p.counter : "null",
                    url: document.location.href
                });
                k += _$.param(q)
            }
            e = 0 < e.indexOf("?") ? e + "&" + k : e + "?" + k;
            p.domain = document.location.hostname;
            if (a && window.XDomainRequest) {
                var u = new XDomainRequest;
                u.open("POST", e);
                u.contentType = "application/json";
                u.timeout = avsr.ajaxTimeout;
                u.onprogress = function () {
                };
                u.onerror = function () {
                    _$.isFunction(c) &&
                    c(u.responseText, "error")
                };
                u.ontimeout = function () {
                    _$.isFunction(c) && c(u.responseText, "timeout")
                };
                u.onload = function () {
                    if (_$.isFunction(m) && (m(JSON.parse(u.responseText)), avsr.main && avsr.main.onCallSuccess)) avsr.main.onCallSuccess(JSON.parse(u.responseText))
                };
                u.send(avsr.main.stringify(p))
            } else {
                var g = !1, v = _$.ajax({
                    url: e,
                    xhrFields: {withCredentials: !0},
                    type: "POST",
                    dataType: "json",
                    accept: "application/json",
                    data: p,
                    success: function (a) {
                        g = !0;
                        if (_$.isFunction(m) && (m(a), avsr.main && avsr.main.onCallSuccess)) avsr.main.onCallSuccess(a)
                    },
                    error: function (a, e, k) {
                        g = !0;
                        _$.isFunction(c) && c(a, e, k)
                    }
                });
                e = 3E4;
                avsr.ajaxTimeout && (e = avsr.ajaxTimeout);
                window.setTimeout(function () {
                    g || (v.abort(), _$.isFunction(c) && c(v, "timeout"))
                }, e)
            }
        };
        this.getHtml = function (e, p, m, c) {
            e = e.replace("http:", document.location.protocol);
            if (a && window.XDomainRequest) {
                var k = new XDomainRequest;
                k.open("GET", e);
                k.timeout = avsr.ajaxTimeout;
                k.onprogress = function () {
                };
                k.onerror = function () {
                    _$.isFunction(m) && m(k.responseText, "error")
                };
                k.ontimeout = function () {
                    _$.isFunction(m) && m(k.responseText,
                        "timeout")
                };
                k.onload = function () {
                    _$.isFunction(p) && p(k.responseText)
                };
                k.send()
            } else e = {
                url: e, type: "GET", dataType: "html", success: function (a) {
                    "undefined" !== typeof p && _$.isFunction(p) && p(a)
                }, error: function (a, c, e) {
                    "undefined" !== typeof m && _$.isFunction(m) && m(a, c, e)
                }
            }, !0 !== c && (e.xhrFields = {withCredentials: !0}), _jQuery.ajax(e)
        }
    }
})();
window.avsr = window.avsr || {};
window.avsr.browserSupport = window.avsr.browserSupport || function () {
    var a = "google;googlebot;yahooseeker;yahoo! slurp;msnbot;bingbot;baiduspider;ask jeeves/teoma;wkhtmltoimage;yandexbot;applebot;visualrevenue.com;pingbot;exabot;seznam;catchpoint;taginspector;evidon;phantomjs;http://s-books.net/crawl_policy;webissimo;evaliant;forusp;hola server".split(";"),
        e = !1, p = 0, m = function (a) {
            window.avsr && window.avsr.log && window.avsr.logException && window.avsr.logXhr ? a() : 5 >= p && (p++, setTimeout(function () {
                m(a)
            }, 50))
        };
    return {
        isSupported: function () {
            for (var c = navigator.userAgent.toLowerCase(), e = 0; e < a.length; e++) if (-1 != c.indexOf(a[e])) return m(function () {
                window.avsr.log("User agent contains global blocklist", "error", "browserSupport", "Blacklisted part : " + a[e])
            }), !1;
            if (avsr.specifics.userAgentBlockList && avsr.specifics.userAgentBlockList.length) for (e = 0; e < avsr.specifics.userAgentBlockList.length; e++) if (-1 != c.indexOf(avsr.specifics.userAgentBlockList[e])) return m(function () {
                window.avsr.log("User agent contains avsr.specifics blocklist",
                    "error", "browserSupport", "Blacklisted part : " + avsr.specifics.userAgentBlockList[e])
            }), !1;
            return !0
        }, isDisabledFunctionalities: function () {
            return e
        }, splitQueryString: function (a) {
            var c = {};
            if (!a || "" == a) return c;
            if ("" != a) {
                a = a.split("&");
                for (var e = 0; e < a.length; e++) {
                    var m = a[e].split("=");
                    c[m[0]] = m[1]
                }
                return c
            }
        }, isLocalStorageSupported: function () {
            var a = !1;
            try {
                var e = window.localStorage;
                if (e) try {
                    e.setItem("av-test-localstorage", "av-test-localstorage"), e.removeItem("av-test-localstorage"), a = !0
                } catch (q) {
                    m(function () {
                        window.avsr.logException("Exception while trying to write to localStorage",
                            "isLocalStorageSupported", q)
                    })
                }
            } catch (q) {
                m(function () {
                    window.avsr.logException("Exception while checking localStorage support", "isLocalStorageSupported", q)
                })
            }
            return a
        }, isPostMessageSupported: function () {
            var a = !1;
            try {
                var k = window.postMessage, a = k ? !0 : !1;
                k || m(function () {
                    window.avsr.log("Post message is not available for this browser", "error", "isPostMessageSupported")
                })
            } catch (q) {
                e = !0, m(function () {
                    window.avsr.logException("Exception thrown while checking for postMessage support", "isPostMessageSupported",
                        q)
                })
            }
            return a
        }, isTranslated: function () {
            return 0 < _$("#goog-gt-tt").length
        }
    }
}();
window.avsr = window.avsr || {};
window.avsr.cookies = window.avsr.cookies || function () {
    function a(a) {
        var c = void 0;
        if (document.cookie && "" !== document.cookie) for (var e = document.cookie.split(";"), m = 0; m < e.length; m++) {
            var g = _$.trim(e[m]);
            g.substring(0, a.length + 1) === a + "=" && (c = decodeURIComponent(g.substring(a.length + 1)))
        }
        return c
    }

    var e = function (a) {
        a = window.avsr.stringHelper.format("{0}=; expires=Thu, 01 Jan 1970 00:00:01 GMT; path={1}; domain={2}", a, "/", m());
        document.cookie = a
    }, p = function (a, e, q) {
        document.cookie = window.avsr.stringHelper.format("{0}={1}; expires={2}; path={3}; domain={4}",
            a, q, e.toGMTString(), "/", m())
    }, m = function () {
        var a, e, q = document.location.hostname.split(".");
        for (a = q.length - 1; 0 <= a; a--) if (e = q.slice(a).join("."), document.cookie = "weird_get_top_level_domain=cookie;domain=." + e + ";", -1 < document.cookie.indexOf("weird_get_top_level_domain=cookie")) return document.cookie = "weird_get_top_level_domain=;domain=." + e + ";expires=Thu, 01 Jan 1970 00:00:01 GMT;", e
    };
    return {
        getKey: function (c, e) {
            var k = a(c);
            _$.isFunction(e) && e(k)
        }, getKeys: function (a, e) {
            var c = [];
            if (document.cookie && "" !==
                document.cookie) for (var k = document.cookie.split(";"), g = 0; g < k.length; g++) {
                var m = _$.trim(k[g]).split("="), p = a.indexOf(m[0].trim());
                -1 < p && (c[p] = m[1].trim())
            }
            for (g = 0; g < a.length; g++) c[g] || (c[g] = "");
            _$.isFunction(e) && e(c.join(","))
        }, getAllValues: function (a) {
            var c = {};
            if (document.cookie && "" !== document.cookie) for (var e = document.cookie.split(";"), m = 0; m < e.length; m++) {
                var g = _$.trim(e[m]).split("=");
                c[g[0].trim()] = (g[1] || "").trim()
            }
            _$.isFunction(a) && a(c)
        }, deleteKey: e, deleteKeys: function (a, k) {
            for (var c = 0; c < a.length; c++) e(a[c])
        },
        setKey: p, setKeys: function (a, e, q) {
            for (var c = 0; c < a.length; c++) p(a[c], e, q[c])
        }, getStorageType: function () {
            return "cookies"
        }, getSynchronousCookie: a
    }
}();
window.avsr = window.avsr || {};
window.avsr.storageAccess = window.avsr.storageAccess || function () {
    var a = window.avsr.cookies, e = window.avsr.xdmStorage, p = void 0, m = function (a) {
            var c = new Date;
            c.setHours(c.getHours() + a);
            return c
        }, c = function (a) {
            var c = new Date;
            c.setMinutes(c.getMinutes() + a);
            return c
        }, k = 0, q = function (a) {
            window.avsr && window.avsr.log && window.avsr.logException && window.avsr.logXhr ? a() : 5 >= k && (k++, setTimeout(function () {
                q(a)
            }, 50))
        }, u = function (a) {
            var c = !1, g = new Date((new Date).getTime() + 864E5), k = Math.random();
            try {
                e.setKey("av-third-party-enabled",
                    g, k), e.getKey("av-third-party-enabled", function (e) {
                    (c = e == k) || q(function () {
                        window.avsr.log("Getted Value different from Setted value", "warn", "checkThirdPartyAccess")
                    });
                    a(c)
                })
            } catch (M) {
                a(!1), q(function () {
                    window.avsr.logException("Error while checking third party access", "checkThirdPartyAccess", M)
                })
            }
        }, g = null, v = function (c) {
            if (avsr.utils.getSpecificsConf().isCrossDomain) if (!0 === p) c(e); else if (!1 === p) c(a); else if ("false" === a.getSynchronousCookie("av-third-party-enabled")) p = !1, c(a); else {
                var g = new Date((new Date).getTime() +
                    864E5);
                avsr.browserSupport.isPostMessageSupported() ? avsr.browserSupport.isLocalStorageSupported() ? u(function (k) {
                    p = k;
                    a.setKey("av-third-party-enabled", g, k);
                    !0 === k ? c(e) : (window.avsr.log("Third party cookies are not available, fallback to cookie storage.", "info", "storageAccess.loadIdentityStorage"), c(a))
                }) : (p = !1, a.setKey("av-third-party-enabled", g, p), q(function () {
                    window.avsr.log("Local storage is not supported, fallback to cookie storage", "info", "storageAccess.loadIdentityStorage")
                }), c(a)) : (p = !1, a.setKey("av-third-party-enabled",
                    g, p), q(function () {
                    window.avsr.log("Post message is not supported, fallback to cookie storage", "info", "storageAccess.loadIdentityStorage")
                }), c(a))
            } else p = !1, q(function () {
                window.avsr.log("Specifics forbids crossDomain, fallback to cookie storage.", "info", "storageAccess.loadIdentityStorage")
            }), c(a)
        }, z = function (a, c) {
            return window.avsr.stringHelper.format("social-reco-cached-{0}-{1}-{2}", avsr.utils.getSpecificsConf().project.Id, a, c)
        }, B = function (a) {
            return "av-sr-enabled-" + a
        }, t = function () {
            return "av-enabled-ads"
        },
        A = function (a) {
            return window.avsr.stringHelper.format("social-reco-{0}", a)
        }, F = function (a, c, e) {
            e ? (e = m(1), g.setKeys(["av-mid", "av-exp", "av-ctp"], c, [a, Date.parse(c), Date.parse(e)]), window.avsr.consoleLog("info", "Modified av-ctp to tomorow (" + e + ") to avoid syncing and expiring at the same time")) : g.setKeys(["av-mid", "av-exp"], c, [a, Date.parse(c)])
        };
    return {
        getCookieTpEnabledValue: function () {
            return a.getSynchronousCookie("av-third-party-enabled")
        }, getDeferredNotifications: function () {
            return a.getKey("deferedNotifications")
        },
        deleteDeferredNotifications: function () {
            return a.deleteKey("deferedNotifications")
        }, setDeferredNotifications: function (c) {
            a.setKey("deferedNotifications", c)
        }, setCachedRecommendations: function (c, e, g) {
            a.setKey(z(c, e), g)
        }, getCachedRecommendations: function (c, e) {
            return a.getKey(z(c, e))
        }, setRecoEnabledFlag: function (a, c, e) {
            g.setKey(B(a), c, e)
        }, getRecoEnabledFlag: function (a, c) {
            return g.getKey(B(a), c)
        }, deleteRecoEnabledFlag: function (a) {
            g.deleteKey(B(a))
        }, getMailData: function (c, e) {
            a.getKey("av-mailid-" + c, e)
        },
        deleteMailData: function (c) {
            a.deleteKey("av-mailid-" + c)
        }, getUniqueIdentity: function (a) {
            g.getKeys(["av-mid", "av-exp"], function (c) {
                c ? (c = c.split(","), 1 < c.length ? (c[0] && "" == c[1] && (c[1] = parseInt(Date.now() + 5184E6 + 28512E6 * Math.random()), F(c[0], new Date(c[1]))), a(c[0], c[1])) : a(null, null)) : a(null, null)
            })
        }, setUniqueIdentity: F, getIdentityKey: A, getIdentity: function (a, c) {
            g.getKey(A(a), c)
        }, setIdentity: function (a, c, e) {
            g.setKey(A(a), c, e)
        }, deleteMachineIdentity: function (a) {
            g.deleteKeys(["av-mid", "av-exp", "av-ctp"]);
            window.avsr.cookies.deleteKey("setavid")
        }, setCnilExpiration: function (a) {
            g.setKey("av-exp", a, Date.parse(a))
        }, getCnilExpiration: function (a) {
            g.getKey("av-exp", a)
        }, getAllValues: function (a) {
            g.getAllValues(a)
        }, deleteOldKeys: function (a) {
            g.deleteKeys(a)
        }, getLastSyncDate: function (a, c) {
            g.getKey(a, c)
        }, updateSyncDate: function (a, c) {
            g.setKey(a, m(24 * c), (new Date).getTime())
        }, getDataStorage: function () {
            return a
        }, getIdentityStorageType: function () {
            return g.getStorageType()
        }, initIdentityStorage: function (a) {
            v(function (c) {
                g =
                    c;
                a()
            })
        }, checkThirdPartyAccess: u, setThirdPartyEnabledCookie: function (c, e) {
            "false" == e ? p = !1 : "true" == e && (p = !0);
            a.setKey("av-third-party-enabled", c, e)
        }, shouldUpdateAvThirdParty: function (a, c) {
            !0 === p && g.getKey("av-ctp", function (e) {
                !0 === c || !e || 864E5 < (new Date).getTime() - parseInt(e, 10) ? (g.setKey("av-ctp", m(168), (new Date).getTime()), a(!0)) : a(!1)
            })
        }, getAllOwnerDisabled: function (a) {
            g.getAllValues(function (c) {
                var e = [], g;
                for (g in c) c.hasOwnProperty(g) && 0 == g.indexOf("av-sr-enabled") && 0 == c[g] && e.push(g.split("-").reverse()[0]);
                a(e)
            })
        }, getSessionId: function (a, e) {
            try {
                g.getKey("av-sess-id-" + a, function (k) {
                    try {
                        k || (k = avsr.guid.newGuid()), g.setKey("av-sess-id-" + a, c(30), k, !0), e(k)
                    } catch (O) {
                        e(null), q(function () {
                            window.avsr.logException("Cannot get sessionId", "getSessionId", O)
                        })
                    }
                }, !0)
            } catch (H) {
                e(null), q(function () {
                    window.avsr.logException("Cannot get sessionId", "getSessionId", H)
                })
            }
        }, cleanSessionCookies: function () {
            g.getAllValues(function (a) {
                if (a) {
                    for (var c = Object.keys(a), e = [], k = 0; k < c.length; k++) -1 < c[k].indexOf("av-sess-id") && 0 > c[k].indexOf("-exp") &&
                    a["av-sess-id-exp"] && parseInt(a["av-sess-id-exp"]) < Date.parse(newDate()) && (e.push("av-sess-id"), e.push("av-sess-id-exp"));
                    0 < e.length && g.deleteKeys(e)
                }
            })
        }, setAdsEnabledFlag: function (a, c) {
            g.setKey(t(), a, c)
        }, getAdsEnabledFlag: function (a) {
            return g.getKey(t(), a)
        }, deleteAdsEnabledFlag: function () {
            g.deleteKey(t())
        }, getDisabledDatas: function (a, c) {
            var e = [B(a), t()];
            return g.getKeys(e, function (a) {
                var e = {isEnabledAds: !0, isEnabledReco: !0};
                null != a && void 0 != a && 0 < a.length && (a = a.split(","), 2 == a.length && ("0" == a[0] &&
                (e.isEnabledReco = !1), "0" == a[1] && (e.isEnabledAds = !1)));
                c(e)
            })
        }
    }
}();
var JSLog = function () {
    var a = function () {
            var a = {
                "[object Boolean]": "boolean",
                "[object Number]": "number",
                "[object String]": "string",
                "[object Function]": "function",
                "[object Array]": "array",
                "[object Date]": "date",
                "[object RegExp]": "regExp",
                "[object Object]": "object"
            };
            return {
                isPlainObject: function (c) {
                    if (!c || "object" !== a[Object.prototype.toString.call(c)] || c.nodeType || c && "object" === typeof c && "setInterval" in c || c.constructor && !Object.prototype.hasOwnProperty.call(c, "constructor") && !Object.prototype.hasOwnProperty.call(c.constructor.prototype,
                        "isPrototypeOf")) return !1;
                    for (var e in c) ;
                    return void 0 === e || Object.prototype.hasOwnProperty.call(c, e)
                }, isArray: function (c) {
                    return "array" === (null == c ? String(c) : a[Object.prototype.toString.call(c)] || "object")
                }, isFunction: function (c) {
                    return "function" === (null == c ? String(c) : a[Object.prototype.toString.call(c)] || "object")
                }, extend: function () {
                    var a, c, e, g = arguments[0] || {}, k = 1, t = arguments.length;
                    for ("object" === typeof g || this.isFunction(g) || (g = {}); k < t; k++) if (null != (a = arguments[k])) for (c in a) e = a[c], g !== e && void 0 !==
                    e && (g[c] = e);
                    return g
                }
            }
        }(), e = this, p = window.console, m = 5, c = {}, k = ["error", "warn", "info", "debug", "log"],
        q = "assert clear count dir dirxml exception group groupCollapsed groupEnd profile profileEnd table time timeEnd trace".split(" "),
        u = {}, g = {}, v = {}, z = q.length;
    g.Logs = {};
    g.SetLevel = function (a) {
        m = "number" === typeof a ? a : 5
    };
    g.GetLevel = function () {
        return m
    };
    g.SetFilter = function (a) {
        if (a && "string" === typeof a) {
            a = a.split(" ");
            for (var e = a.length; 0 <= --e;) c[a] = !0;
            return c
        }
        return !1
    };
    g.UnsetFilter = function (a) {
        if (a && "string" ===
            typeof a) {
            a = a.split(" ");
            for (var e = a.length; 0 <= --e;) c[a] && delete c[a];
            return c
        }
        return !1
    };
    for (g.GetFilter = function () {
        return c
    }; 0 <= --z;) (function (a) {
        v[a] = function () {
            0 !== m && p && p[a] && p[a].apply(p, arguments)
        }
    })(q[z]);
    for (z = k.length; 0 <= --z;) (function (a, c) {
        v[c] = function () {
            var g = Array.prototype.slice.call(arguments);
            p && (0 < m ? m > a : k.length + m <= a) && (p.firebug || p.firebuglite ? p[c].apply(e, g) : p[c] ? p[c](g) : p.log(g))
        }
    })(z, k[z]);
    var B = function (a) {
        a = k.length;
        for (var q = {}; 0 <= --a;) (function (a, t) {
            q[t] = function () {
                var q =
                    Array.prototype.slice.call(arguments);
                g.Logs[this.module].push([t].concat(q));
                p && (0 < m ? m > a : k.length + m <= a) && !c[this.module] && (q.unshift("[" + this.module + "]"), p.firebug || p.firebuglite ? p[t].apply(e, q) : p[t] ? p[t](q) : p.log(q))
            }
        })(a, k[a]);
        return q
    };
    g.Register = function (c) {
        if (u[c]) return u[c];
        g.Logs[c] = [];
        u[c] = a.extend({}, v, B());
        u[c].module = c;
        return u[c]
    };
    g.GetModule = function (a) {
        return u[a] ? u[a] : !1
    };
    g.Dump = function (a) {
        if (a && u[a]) {
            var c = g.Logs[a];
            v.groupCollapsed(a);
            a = 0;
            for (var k = c.length; a < k; a++) v[c[a].slice(0,
                1)].apply(e, c[a].slice(1))
        } else for (c in v.groupCollapsed("Loggers Dump"), u) u.hasOwnProperty(c) && g.Dump(c);
        v.groupEnd()
    };
    a.extend(g, v);
    return g
}();
(function () {
    function a(a, c, e, g, m, z, B, t, A, F, y) {
        p(encodeURIComponent(a), c, encodeURIComponent(e), g, encodeURIComponent(m), z, encodeURIComponent(B), encodeURIComponent(t), encodeURIComponent(A), F, encodeURI(y))
    }

    function e(a, c) {
        return "Call Took  : " + (a - c) + " ms since last log"
    }

    function p(a, c, e, g, p, z, B, t, A, F, y) {
        var k = null;
        m(a, c, function () {
            if (F && 0 < F.length) for (k = "", i = 0; i < F.length; i++) k += encodeURIComponent(F[i]), i < F.length - 1 && (k += ",");
            window.avsr.main.platformReady(function () {
                var q = window.avsr.auth.getIdentity().mId,
                    m = window.avsr.utils.getSpecificsConf().project.Id, u = window.avsr.main.currentWindowGuid;
                m && q && (q = {
                    message: a,
                    level: c,
                    stackTrace: A,
                    parameters: k,
                    webSiteId: m,
                    pageId: u,
                    machineId: q,
                    ajaxOptions: g,
                    exceptionMessage: B,
                    exceptionName: t,
                    xhrResponseText: p,
                    xhrStatus: z,
                    functionName: e,
                    url: y
                }, avsr.ajax.post(avsr.main.getAbsoluteUrl("/Monitoring/LogApplicationMessage"), q))
            })
        })
    }

    function m(a, c, e) {
        if (!a || !c || "error" !== c && "warn" != c && "info" != c && "debug" != c || !(avsr.loggingConfiguration && avsr.loggingConfiguration.enabled && avsr.loggingConfiguration.sampleRate &&
            avsr.cookies)) return !1;
        if ("error" == avsr.loggingConfiguration.logLevel) {
            if ("error" != c) return !1
        } else if ("warn" == avsr.loggingConfiguration.logLevel) {
            if ("error" != c && "warn" != c) return !1
        } else if ("info" == avsr.loggingConfiguration.logLevel && "error" != c && "warn" != c && "info" != c) return !1;
        avsr.cookies.getKey("av-logging-sample-rate", function (a) {
            avsr.loggingConfiguration.sampleRate >= a && e();
            return !1
        })
    }

    var c = void 0;
    window.avsr = window.avsr || {};
    window.avsr.log = function (c, e, m) {
        var g = Array.prototype.slice.call(arguments,
            3);
        a(c, e, m, null, null, null, null, null, null, g, window.location.href)
    };
    window.avsr.logException = function (c, e, m) {
        var g = Array.prototype.slice.call(arguments, 3);
        m ? a(c, "error", e, null, null, null, m.message, m.name, m.stack, g, window.location.href) : a(c, "error", e, null, null, null, null, null, null, g)
    };
    window.avsr.logXhr = function (c, e, m, g, p, z) {
        var k = Array.prototype.slice.call(arguments, 6);
        a(c, e, m, p, g.responseText, g.status, JSON.stringify(z), null, null, k, window.location.href)
    };
    window.avsr.loggingConfiguration = window.avsr.loggingConfiguration ||
        {enabled: !1, sampleRate: 100, windowOnErrorEnabled: !1, logLevel: "error"};
    window.avsr.logDatalayerErrors = function (a, c) {
        var e = avsr.auth.completeParams({err: a, type: 0, href: document.location.href});
        avsr.ajax.post(avsr.main.getAbsoluteUrl("/Datalayer/Report"), e);
        c && console.log(a)
    };
    window.avsr.consoleLog = function (a, m) {
        if (avsr.utils.isDevelopment()) {
            var k = performance.now();
            c || (c = k);
            switch (a) {
                case "debug":
                    console.debug(m);
                    console.debug(e(k, c));
                    break;
                case "info":
                    console.info(m);
                    console.info(e(k, c));
                    break;
                case "warn":
                    console.warn(m);
                    console.warn(e(k, c));
                    break;
                case "error":
                    console.error(m), console.error(e(k, c))
            }
            c = k
        }
    }
})();
(function () {
    var a = function () {
        return window.avsr && window.avsr.specifics && window.avsr.utils.getSpecificsConf().availability ? window.avsr.utils.getSpecificsConf().availability.isTimeLoggingEnabled : !0
    }, e = function () {
        return window.avsr && window.avsr.specifics && window.avsr.utils.getSpecificsConf().availability ? window.avsr.utils.getSpecificsConf().availability.isCallLoggingEnabled : !0
    }, p = function () {
        return {
            getStartTime: function () {
                return (new Date).getTime()
            }, measureTime: function (e, c) {
                e && a() && ((new Date).getTime(),
                    avsr.main.getAbsoluteUrl("/Monitoring/LogTime"))
            }, logTimeOut: function (e) {
                a() && avsr.main.getAbsoluteUrl("/Monitoring/LogTimeOut")
            }, logClientCall: function (a) {
                e() && (website = window.avsr.utils.getSpecificsConf().project.Id, avsr.main.getAbsoluteUrl("/Monitoring/LogClientCall"))
            }, logCall: function (a) {
                if (e()) {
                    var c = avsr.main.getAbsoluteUrl("/Monitoring/LogCall");
                    avsr.ajax.post(c, {counter: a}, null, null)
                }
            }
        }
    }();
    window.avsr = window.avsr || {};
    window.avsr.monitoring = p
})();
var JSON;
JSON || (JSON = {});
(function () {
    function a(a) {
        return 10 > a ? "0" + a : a
    }

    function e(a) {
        c.lastIndex = 0;
        return c.test(a) ? '"' + a.replace(c, function (a) {
            var c = u[a];
            return "string" === typeof c ? c : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4)
        }) + '"' : '"' + a + '"'
    }

    function p(a, c) {
        var m, t, u, z, v = k, D, H = c[a];
        H && "object" === typeof H && "function" === typeof H.toJSON && (H = H.toJSON(a));
        "function" === typeof g && (H = g.call(c, a, H));
        switch (typeof H) {
            case "string":
                return e(H);
            case "number":
                return isFinite(H) ? String(H) : "null";
            case "boolean":
            case "null":
                return String(H);
            case "object":
                if (!H) return "null";
                k += q;
                D = [];
                if ("[object Array]" === Object.prototype.toString.apply(H)) {
                    z = H.length;
                    for (m = 0; m < z; m += 1) D[m] = p(m, H) || "null";
                    u = 0 === D.length ? "[]" : k ? "[\n" + k + D.join(",\n" + k) + "\n" + v + "]" : "[" + D.join(",") + "]";
                    k = v;
                    return u
                }
                if (g && "object" === typeof g) for (z = g.length, m = 0; m < z; m += 1) "string" === typeof g[m] && (t = g[m], (u = p(t, H)) && D.push(e(t) + (k ? ": " : ":") + u)); else for (t in H) Object.prototype.hasOwnProperty.call(H, t) && (u = p(t, H)) && D.push(e(t) + (k ? ": " : ":") + u);
                u = 0 === D.length ? "{}" : k ? "{\n" + k + D.join(",\n" + k) + "\n" + v + "}" : "{" + D.join(",") +
                    "}";
                k = v;
                return u
        }
    }

    "function" !== typeof Date.prototype.toJSON && (Date.prototype.toJSON = function (c) {
        return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + a(this.getUTCMonth() + 1) + "-" + a(this.getUTCDate()) + "T" + a(this.getUTCHours()) + ":" + a(this.getUTCMinutes()) + ":" + a(this.getUTCSeconds()) + "Z" : null
    }, String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function (a) {
        return this.valueOf()
    });
    var m = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        c = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        k, q, u = {"\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\"}, g;
    "function" !== typeof JSON.stringify && (JSON.stringify = function (a, c, e) {
        var m;
        q = k = "";
        if ("number" === typeof e) for (m = 0; m < e; m += 1) q += " "; else "string" === typeof e && (q = e);
        if ((g = c) && "function" !== typeof c && ("object" !== typeof c || "number" !== typeof c.length)) throw Error("JSON.stringify");
        return p("", {"": a})
    });
    "function" !== typeof JSON.parse && (JSON.parse = function (a, c) {
        function e(a, g) {
            var k, m, q = a[g];
            if (q && "object" === typeof q) for (k in q) Object.prototype.hasOwnProperty.call(q, k) && (m = e(q, k), void 0 !== m ? q[k] = m : delete q[k]);
            return c.call(a, g, q)
        }

        var g;
        a = String(a);
        m.lastIndex = 0;
        m.test(a) && (a = a.replace(m, function (a) {
            return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4)
        }));
        if (/^[\],:{}\s]*$/.test(a.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
            "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) return g = eval("(" + a + ")"), "function" === typeof c ? e({"": g}, "") : g;
        throw new SyntaxError("JSON.parse");
    })
})();
(function (a) {
    function e() {
    }

    for (var p = "assert count debug dir dirxml error exception group groupCollapsed groupEnd info log markTimeline profile profileEnd time timeEnd trace warn".split(" "), m; m = p.pop();) a[m] = a[m] || e
})(function () {
    try {
        return console.log(), window.console
    } catch (a) {
        return window.console = {}
    }
}());
window.avsr = window.avsr || {};
window.avsr.stringHelper = window.avsr.stringHelper || function () {
    return {
        format: function (a) {
            var e = arguments;
            return a.replace(/{(\d+)}/g, function (a, m) {
                m = parseInt(m) + 1;
                return "undefined" != typeof e[m] ? e[m] : a
            })
        }, appendObject: function (a, e) {
            var p = a;
            if ("null" == p || -1 == p.indexOf("{")) p = "";
            return p + "|" + JSON.stringify(e)
        }, av_hashFnv32a: function (a, e, p) {
            var m, c = void 0 === p ? 2166136261 : p;
            p = 0;
            for (m = a.length; p < m; p++) c ^= a.charCodeAt(p), c += (c << 1) + (c << 4) + (c << 7) + (c << 8) + (c << 24);
            return e ? ("0000000" + (c >>> 0).toString(16)).substr(-8) :
                c >>> 0
        }, htmlEncode: function (a) {
            return _$("<div/>").text(a).html()
        }, htmlDecode: function (a) {
            return _$("<div/>").html(a).text()
        }, startsWith: function (a, e, p) {
            p = p || 0;
            return a.indexOf(e, p) === p
        }
    }
}();
window.avsr = window.avsr || {};
window.avsr.guid = window.avsr.guid || function () {
    var a;
    (function () {
        var e = window.crypto || window.msCrypto;
        if (!a && e && e.getRandomValues) try {
            var c = new Uint8Array(16);
            a = function () {
                e.getRandomValues(c);
                return c
            };
            a()
        } catch (q) {
        }
        if (!a) {
            var k = Array(16);
            a = function () {
                for (var a = 0, c; 16 > a; a++) 0 === (a & 3) && (c = 4294967296 * Math.random()), k[a] = c >>> ((a & 3) << 3) & 255;
                return k
            };
            "undefined" !== typeof console && console.warn && console.warn("[SECURITY] node-uuid: crypto not usable, falling back to insecure Math.random()")
        }
    })();
    for (var e =
        [], p = 0; 256 > p; p++) e[p] = (p + 256).toString(16).substr(1);
    return {
        newGuid: function () {
            var m = a();
            m[6] = m[6] & 15 | 64;
            m[8] = m[8] & 63 | 128;
            var c = 0;
            return e[m[c++]] + e[m[c++]] + e[m[c++]] + e[m[c++]] + "-" + e[m[c++]] + e[m[c++]] + "-" + e[m[c++]] + e[m[c++]] + "-" + e[m[c++]] + e[m[c++]] + "-" + e[m[c++]] + e[m[c++]] + e[m[c++]] + e[m[c++]] + e[m[c++]] + e[m[c++]]
        }
    }
}();
window.avsr = window.avsr || {};
window.avsr.thirdParties = window.avsr.thirdParties || function () {
    var a = function (a, c, e, q) {
        var k = avsr.main.getStorageAccess();
        k.getLastSyncDate(a, function (g) {
            if (!0 === q || !g || (new Date).getTime() - parseInt(g, 10) > 864E5 * c) e(), k.updateSyncDate(a, c)
        })
    }, e = function (a) {
        _$("body").append("<img width='1' height='1' src='" + a + "'>")
    }, p = function (a) {
        window.__cmp ? window.__cmp("getConsentData", null, a) : a({})
    };
    return {
        initialize: function (m) {
            if (!0 === m || !1 !== avsr.utils.getSpecificsConf().availability.isThirdPartySyncEnabled && avsr.auth.isThirdPartyReady()) a("av-tp",
                7, function () {
                    var a = avsr.context.currentMember.mId;
                    e("https://cookie-matching.mediarithmics.com/v1/get_user_agent_id?dom_token=antv17");
                    var k = avsr.main.getAbsoluteUrl(avsr.stringHelper.format("/ThirdParty/SyncId?oId={0}&mId={1}&tp=1&tpId=$UID", avsr.utils.getSpecificsConf().project.Id, a), !0);
                    "https:" == window.location.protocol ? e(avsr.stringHelper.format("//secure.adnxs.com/getuid?{0}", k)) : e(avsr.stringHelper.format("//ib.adnxs.com/getuid?{0}", k));
                    e(avsr.stringHelper.format("//cm.g.doubleclick.net/pixel?google_nid=antvoice_dmp&google_cm&oId={0}&mId={1}",
                        avsr.utils.getSpecificsConf().project.Id, a));
                    p(function (c) {
                        c = _$.isEmptyObject(c) ? avsr.stringHelper.format("https://token.rubiconproject.com/token?pid=2655&puid={0}&p=1", a) : avsr.stringHelper.format("https://token.rubiconproject.com/token?pid=2655&puid={0}&p=1&gdpr={1}&gdpr_consent={2}", a, c.gdprApplies ? 1 : 0, c.consentData);
                        e(c)
                    });
                    k = encodeURIComponent(avsr.main.getAbsoluteUrl(avsr.stringHelper.format("/ThirdParty/SyncId?oId={0}&mId={1}&tp=5&tpId=", avsr.utils.getSpecificsConf().project.Id, a)), !0);
                    e(avsr.stringHelper.format("//sync.smartadserver.com/getuid?url={0}[sas_uid]",
                        k));
                    e(avsr.stringHelper.format("https://ads.stickyadstv.com/data-registering?dataProviderId=1137&redirectId=1569"))
                }, m), a("av-tp-bs", 2, function () {
                e(avsr.stringHelper.format("https://x.bidswitch.net/sync?dsp_id=352&user_id={0}&expires=2", avsr.context.currentMember.mId))
            }, m)
        }, callPixel: e
    }
}();
window.avsr = window.avsr || {};
window.avsr.utils = window.avsr.utils || function () {
    function a(a, c, k) {
        return function () {
            var m = "function" === typeof a, u = m ? a : c ? e : p;
            (m || k) && window.avsr.consoleLog("info", "Calling " + (m && a.name ? a.name : k));
            return u.apply(this, arguments)
        }
    }

    var e = function () {
        return !0
    }, p = function () {
    };
    return {
        createHooks: function (e, c, k, q, p) {
            return function () {
                1 != a(avsr.specifics[c], !0, c).apply(this, arguments) ? avsr.log("Call has benn cancelled cancelled by " + c, "info", "HooksManager") : (Array.prototype.push.call(arguments, a(avsr.specifics[k],
                    !0, k), a(avsr.specifics[q], !0, q), a(avsr.specifics[p], !1, p)), e.apply(this, arguments))
            }
        }, callFunction: function (e, c) {
            var k = e, m = c;
            Array.prototype.splice.call(arguments, 0, 2);
            return a(k, m).apply(this, arguments)
        }, callInternal: function (e, c, k) {
            var m = e, p = c, g = k;
            Array.prototype.splice.call(arguments, 0, 3);
            return a(m, p, g).apply(this, arguments)
        }, getSpecificsConf: function () {
            var a;
            void 0 !== avsr.specifics.clientSpecConfiguration ? a = avsr.specifics.clientSpecConfiguration : (a = {
                availability: avsr.specifics.availability,
                templateKey: avsr.specifics.templateKey,
                isCrossDomain: avsr.specifics.isCrossDomain,
                project: avsr.specifics.project,
                configurations: avsr.specifics.configurations
            }, avsr.specifics.configurations && void 0 !== avsr.specifics.configurations.trackByRedirect && (a.tracking = {
                useRedirect: avsr.specifics.configurations.trackByRedirect,
                parameters: avsr.specifics.configurations.trackingParameters
            }));
            return a
        }, isDevelopment: function () {
            return 1 < avsr.main.contentUrl.indexOf("social-reco")
        }
    }
}();
window.avsr = window.avsr || {};
window.avsr.sn = window.avsr.sn || {};
window.avsr.sn.facebook = window.avsr.sn.facebook || function () {
    return {
        initialize: function (a, e, p, m) {
        }, deletePublish: function (a) {
            var e = a.callback ? a.callback : null;
            FB.api(a.postId ? a.postId : null, "delete", function (a) {
                e && e(a)
            })
        }, publish: function (a) {
            var e = a.action, p = a.namespace, m = a.object, c = a.url;
            if ("watch" == e || "read" == e) p = null;
            var k = a.callback ? a.callback : null,
                q = "/me/" + (null != p && "" != p ? p + ":" + a.ogAction : a.ogAction);
            "watch" == a.ogAction ? (q = "/me/video.watches", FB.api(q, "post", {video: c}, function (a) {
                null != k && (avsr.log("OG publish " +
                    e + " " + c, "info"), k(a))
            })) : "read" == a.ogAction ? FB.api(q, "post", {article: c}, function (a) {
                null != k && (avsr.log("OG publish " + e + " " + c, "info"), k(a))
            }) : "favorite" == a.ogAction ? FB.api(q, "post", {other: c}, function (a) {
                null != k && (avsr.log("OG publish " + e + " " + c, "info"), k(a))
            }) : (a = {}, a[m] = c, FB.api(q, "post", a, function (a) {
                avsr.log("OG publish " + q + " " + c, "info");
                k && k(a)
            }))
        }, login: function (a, e) {
        }, logout: function (a) {
        }, checkCurrentMember: function (a, e) {
            return !0
        }, subscribeToStatusChange: function () {
        }, loadProfile: function (a) {
        }
    }
}();
(function (a) {
    avsr.scrollMonitor = a(_jQuery)
})(function (a) {
    function e() {
        k.viewportTop = q.scrollTop();
        k.viewportBottom = k.viewportTop + k.viewportHeight;
        k.documentHeight = u.height();
        if (k.documentHeight !== k.previousDocumentHeight) {
            for (t = g.length; t--;) g[t].recalculateLocation();
            k.previousDocumentHeight = k.documentHeight
        }
    }

    function p() {
        k.viewportHeight = window.innerHeight || document.documentElement.clientHeight;
        e();
        m()
    }

    function m() {
        for (F = g.length; F--;) g[F].update();
        for (F = g.length; F--;) g[F].triggerCallbacks()
    }

    function c(c,
               e) {
        function g(a) {
            if (0 !== a.length) for (u = a.length; u--;) A = a[u], A.callback.call(m, B), A.isOne && a.splice(u, 1)
        }

        var m = this;
        this.watchItem = c;
        this.offsets = e ? e === +e ? {top: e, bottom: e} : a.extend({}, z, e) : z;
        this.callbacks = {};
        for (var p = 0, q = v.length; p < q; p++) m.callbacks[v[p]] = [];
        this.locked = !1;
        var l, t, E, w, u, A;
        this.triggerCallbacks = function () {
            this.isInViewport && !l && g(this.callbacks.enterViewport);
            this.isFullyInViewport && !t && g(this.callbacks.fullyEnterViewport);
            this.isAboveViewport !== E && this.isBelowViewport !== w && (g(this.callbacks.visibilityChange),
            t || this.isFullyInViewport || (g(this.callbacks.fullyEnterViewport), g(this.callbacks.partiallyExitViewport)), l || this.isInViewport || (g(this.callbacks.enterViewport), g(this.callbacks.exitViewport)));
            !this.isFullyInViewport && t && g(this.callbacks.partiallyExitViewport);
            !this.isInViewport && l && g(this.callbacks.exitViewport);
            this.isInViewport !== l && g(this.callbacks.visibilityChange);
            switch (!0) {
                case l !== this.isInViewport:
                case t !== this.isFullyInViewport:
                case E !== this.isAboveViewport:
                case w !== this.isBelowViewport:
                    g(this.callbacks.stateChange)
            }
            l =
                this.isInViewport;
            t = this.isFullyInViewport;
            E = this.isAboveViewport;
            w = this.isBelowViewport
        };
        this.recalculateLocation = function () {
            if (!this.locked) {
                var d = this.top, c = this.bottom;
                if (this.watchItem.nodeName) {
                    var e = this.watchItem.style.display;
                    "none" === e && (this.watchItem.style.display = "");
                    var l = a(this.watchItem).offset();
                    this.top = l.top;
                    this.bottom = l.top + this.watchItem.offsetHeight;
                    "none" === e && (this.watchItem.style.display = e)
                } else this.watchItem === +this.watchItem ? this.top = 0 < this.watchItem ? this.bottom = this.watchItem :
                    this.bottom = k.documentHeight - this.watchItem : (this.top = this.watchItem.top, this.bottom = this.watchItem.bottom);
                this.top -= this.offsets.top;
                this.bottom += this.offsets.bottom;
                this.height = this.bottom - this.top;
                void 0 === d && void 0 === c || this.top === d && this.bottom === c || g(this.callbacks.locationChange)
            }
        };
        this.recalculateLocation();
        this.update();
        l = this.isInViewport;
        t = this.isFullyInViewport;
        E = this.isAboveViewport;
        w = this.isBelowViewport
    }

    var k = {}, q = a(window), u = a(document), g = [],
        v = "visibilityChange enterViewport fullyEnterViewport exitViewport partiallyExitViewport locationChange stateChange".split(" "),
        z = {top: 0, bottom: 0};
    k.viewportTop;
    k.viewportBottom;
    k.documentHeight;
    k.viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    k.previousDocumentHeight;
    var B, t, A, F;
    c.prototype = {
        on: function (a, c, e) {
            switch (!0) {
                case "visibilityChange" === a && !this.isInViewport && this.isAboveViewport:
                case "enterViewport" === a && this.isInViewport:
                case "fullyEnterViewport" === a && this.isFullyInViewport:
                case "exitViewport" === a && this.isAboveViewport && !this.isInViewport:
                case "partiallyExitViewport" === a && this.isAboveViewport:
                    if (c.call(this),
                        e) return
            }
            if (this.callbacks[a]) this.callbacks[a].push({
                callback: c,
                isOne: e
            }); else throw Error("Tried to add a scroll monitor listener of type " + a + ". Your options are: " + v.join(", "));
        }, off: function (a, c) {
            if (this.callbacks[a]) for (var e = 0, g; g = this.callbacks[a][e]; e++) {
                if (g.callback === c) {
                    this.callbacks[a].splice(e, 1);
                    break
                }
            } else throw Error("Tried to remove a scroll monitor listener of type " + a + ". Your options are: " + v.join(", "));
        }, one: function (a, c) {
            this.on(a, c, !0)
        }, recalculateSize: function () {
            this.height =
                this.watchItem.offsetHeight + this.offsets.top + this.offsets.bottom;
            this.bottom = this.top + this.height
        }, update: function () {
            this.isAboveViewport = this.top < k.viewportTop;
            this.isBelowViewport = this.bottom > k.viewportBottom;
            this.isInViewport = this.top <= k.viewportBottom && this.bottom >= k.viewportTop;
            this.isFullyInViewport = this.top >= k.viewportTop && this.bottom <= k.viewportBottom || this.isAboveViewport && this.isBelowViewport
        }, destroy: function () {
            var a = g.indexOf(this);
            g.splice(a, 1);
            for (var a = 0, c = v.length; a < c; a++) this.callbacks[v[a]].length =
                0
        }, lock: function () {
            this.locked = !0
        }, unlock: function () {
            this.locked = !1
        }
    };
    for (var y = function (a) {
        return function (c, e) {
            this.on.call(this, a, c, e)
        }
    }, D = 0, H = v.length; D < H; D++) {
        var O = v[D];
        c.prototype[O] = y(O)
    }
    try {
        e()
    } catch (M) {
        a(e)
    }
    q.on("scroll", function (a) {
        B = a;
        e();
        m()
    });
    q.on("resize", function () {
        clearTimeout(A);
        A = setTimeout(p, 100)
    });
    k.beget = k.create = function (e, k) {
        "string" === typeof e && (e = a(e)[0]);
        e instanceof a && (e = e[0]);
        var m = new c(e, k);
        g.push(m);
        m.update();
        return m
    };
    k.update = function () {
        B = null;
        e();
        m()
    };
    k.recalculateLocations =
        function () {
            k.previousDocumentHeight = 0;
            k.update()
        };
    return k
});
var popUpTimer;

function popUp(a, e, p) {
    popUpTimer = setTimeout(function () {
        popUpTwo(a, e, p)
    }, 5E3);
    window.open(e, a, p)
}

function popUpDone() {
    clearTimeout(popUpTimer);
    document.getElementById("popUpStatus").innerHTML = "Pop-up worked"
}

function popUpTwo(a, e, p) {
    clearTimeout(popUpTimer);
    document.getElementById("popUpStatus").innerHTML = "Pop-up didn't work. Time to create an absolute positioned iframe.";
    var m = document.createElement("iframe");
    m.src = e;
    m.name = a;
    m.style.position = "absolute";
    a = p.split(",");
    for (i = 0; i < a.length; i++) switch (e = a[i].split("="), e[0]) {
        case "width":
            m.width = e[1];
            break;
        case "height":
            m.height = e[1];
            break;
        case "left":
            m.style.left = e[1] + "px";
            break;
        case "top":
            m.style.top = e[1] + "px"
    }
    document.getElementById("iframeArea").appendChild(m)
}

function popUpFailed() {
    alert('Please disable your pop-up blocker and click the "Open Pop-up" button again.')
};(function (a) {
    function e(c, e, k, l) {
        l = {
            data: l || (e ? e.data : {}),
            _wrap: e ? e._wrap : null,
            tmpl: null,
            parent: e || null,
            nodes: [],
            calls: g,
            nest: v,
            wrap: z,
            html: B,
            update: t
        };
        c && a.extend(l, c, {nodes: [], parent: e});
        k && (l.tmpl = k, l._ctnt = l._ctnt || l.tmpl(a, l), l.key = ++M, (V.length ? D : y)[M] = l);
        return l
    }

    function p(c, e, g) {
        var l;
        g = g ? a.map(g, function (a) {
            return "string" === typeof a ? c.key ? a.replace(/(<\w+)(?=[\s>])(?![^>]*_tmplitem)([^>]*)/g, '$1 _tmplitem="' + c.key + '" $2') : a : p(a, c, a._ctnt)
        }) : c;
        if (e) return g;
        g = g.join("");
        g.replace(/^\s*([^<\s][^<]*)?(<[\w\W]+>)([^>]*[^>\s])?\s*$/,
            function (c, e, g, k) {
                l = a(g).get();
                u(l);
                e && (l = m(e).concat(l));
                k && (l = l.concat(m(k)))
            });
        return l ? l : m(g)
    }

    function m(c) {
        var e = document.createElement("div");
        e.innerHTML = c;
        return a.makeArray(e.childNodes)
    }

    function c(c) {
        return new Function("_jQuery", "_$item", "var _$=_jQuery,call,_=[],_$data=_$item.data;with(_$data){_.push('" + a.trim(c).replace(/([\\'])/g, "\\$1").replace(/[\r\t\n]/g, " ").replace(/\$\{([^\}]*)\}/g, "{{= $1}}").replace(/\{\{(\/?)(\w+|.)(?:\(((?:[^\}]|\}(?!\}))*?)?\))?(?:\s+(.*?)?)?(\(((?:[^\}]|\}(?!\}))*?)\))?\s*\}\}/g,
            function (c, e, l, g, k, m, p) {
                c = a.tmpl.tag[l];
                if (!c) throw"Template command not found: " + l;
                l = c._default || [];
                m && !/\w$/.test(k) && (k += m, m = "");
                k ? (k = q(k), p = p ? "," + q(p) + ")" : m ? ")" : "", p = m ? -1 < k.indexOf(".") ? k + m : "(" + k + ").call(_$item" + p : k, m = m ? p : "(typeof(" + k + ")==='function'?(" + k + ").call(_$item):(" + k + "))") : m = p = l.$1 || "null";
                g = q(g);
                return "');" + c[e ? "close" : "open"].split("_$notnull_1").join(k ? "typeof(" + k + ")!=='undefined' && (" + k + ")!=null" : "true").split("$1a").join(m).split("_$1").join(p).split("$2").join(g ? g.replace(/\s*([^\(]+)\s*(\((.*?)\))?/g,
                    function (a, d, c, e) {
                        return (e = e ? "," + e + ")" : c ? ")" : "") ? "(" + d + ").call(_$item" + e : a
                    }) : l.$2 || "") + "_.push('"
            }) + "');}return _;")
    }

    function k(c, e) {
        c._wrap = p(c, !0, a.isArray(e) ? e : [F.test(e) ? e : a(e).html()]).join("")
    }

    function q(a) {
        return a ? a.replace(/\\'/g, "'").replace(/\\\\/g, "\\") : null
    }

    function u(c) {
        function g(d) {
            function c(a) {
                a += k;
                r = p[a] = p[a] || e(r, y[r.parent.key + k] || r.parent, null, !0)
            }

            var l, g = d, r, m;
            if (m = d.getAttribute("_tmplitem")) {
                for (; g.parentNode && 1 === (g = g.parentNode).nodeType && !(l = g.getAttribute("_tmplitem"));) ;
                l !== m && (g = g.parentNode ? 11 === g.nodeType ? 0 : g.getAttribute("_tmplitem") || 0 : 0, (r = y[m]) || (r = D[m], r = e(r, y[g] || D[g], null, !0), r.key = ++M, y[M] = r), Q && c(m));
                d.removeAttribute("_tmplitem")
            } else Q && (r = a.data(d, "tmplItem")) && (c(r.key), y[r.key] = r, g = (g = a.data(d.parentNode, "tmplItem")) ? g.key : 0);
            if (r) {
                for (l = r; l && l.key != g;) l.nodes.push(d), l = l.parent;
                delete r._ctnt;
                delete r._wrap;
                a.data(d, "tmplItem", r)
            }
        }

        var k = "_" + Q, l, m, p = {}, q, t, z;
        q = 0;
        for (t = c.length; q < t; q++) if (1 === (l = c[q]).nodeType) {
            m = l.getElementsByTagName("*");
            for (z =
                     m.length - 1; 0 <= z; z--) g(m[z]);
            g(l)
        }
    }

    function g(a, c, e, l) {
        if (!a) return V.pop();
        V.push({_: a, tmpl: c, item: this, data: e, options: l})
    }

    function v(c, e, g) {
        return a.tmpl(a.template(c), e, g, this)
    }

    function z(c, e) {
        var g = c.options || {};
        g.wrapped = e;
        return a.tmpl(a.template(c.tmpl), c.data, g, c.item)
    }

    function B(c, e) {
        var g = this._wrap;
        return a.map(a(a.isArray(g) ? g.join("") : g).filter(c || "*"), function (a) {
            if (e) a = a.innerText || a.textContent; else {
                var c;
                (c = a.outerHTML) || (c = document.createElement("div"), c.appendChild(a.cloneNode(!0)),
                    c = c.innerHTML);
                a = c
            }
            return a
        })
    }

    function t() {
        var c = this.nodes;
        a.tmpl(null, null, null, this).insertBefore(c[0]);
        a(c).remove()
    }

    var A = a.fn.domManip, F = /^[^<]*(<[\w\W]+>)[^>]*$|\{\{\! /, y = {}, D = {}, H, O = {key: 0, data: {}}, M = 0,
        Q = 0, V = [];
    a.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function (c, e) {
        a.fn[c] = function (g) {
            var l = [];
            g = a(g);
            var k, m, p;
            k = 1 === this.length && this[0].parentNode;
            H = y || {};
            if (k && 11 === k.nodeType && 1 === k.childNodes.length && 1 === g.length) g[e](this[0]),
                l = this; else {
                m = 0;
                for (p = g.length; m < p; m++) Q = m, k = (0 < m ? this.clone(!0) : this).get(), a.fn[e].apply(a(g[m]), k), l = l.concat(k);
                Q = 0;
                l = this.pushStack(l, c, g.selector)
            }
            g = H;
            H = null;
            a.tmpl.complete(g);
            return l
        }
    });
    a.fn.extend({
        tmpl: function (c, e, g) {
            return a.tmpl(this[0], c, e, g)
        }, tmplItem: function () {
            return a.tmplItem(this[0])
        }, template: function (c) {
            return a.template(c, this[0])
        }, domManip: function (c, e, g) {
            if (c[0] && c[0].nodeType) {
                for (var l = a.makeArray(arguments), k = c.length, m = 0, p; m < k && !(p = a.data(c[m++], "tmplItem"));) ;
                1 < k && (l[0] =
                    [a.makeArray(c)]);
                p && Q && (l[2] = function (c) {
                    a.tmpl.afterManip(this, c, g)
                });
                A.apply(this, l)
            } else A.apply(this, arguments);
            Q = 0;
            !H && a.tmpl.complete(y);
            return this
        }
    });
    a.extend({
        tmpl: function (c, g, m, l) {
            var q = !l;
            if (q) l = O, c = a.template[c] || a.template(null, c), D = {}; else if (!c) return c = l.tmpl, y[l.key] = l, l.nodes = [], l.wrapped && k(l, l.wrapped), a(p(l, null, l.tmpl(a, l)));
            if (!c) return [];
            "function" === typeof g && (g = g.call(l || {}));
            m && m.wrapped && k(m, m.wrapped);
            g = a.isArray(g) ? a.map(g, function (a) {
                return a ? e(m, l, c, a) : null
            }) : [e(m,
                l, c, g)];
            return q ? a(p(l, null, g)) : g
        }, tmplItem: function (c) {
            var e;
            for (c instanceof a && (c = c[0]); c && 1 === c.nodeType && !(e = a.data(c, "tmplItem")) && (c = c.parentNode);) ;
            return e || O
        }, template: function (e, g) {
            return g ? ("string" === typeof g ? g = c(g) : g instanceof a && (g = g[0] || {}), g.nodeType && (g = a.data(g, "tmpl") || a.data(g, "tmpl", c(g.innerHTML))), "string" === typeof e ? a.template[e] = g : g) : e ? "string" !== typeof e ? a.template(null, e) : a.template[e] || a.template(null, F.test(e) ? e : a(e)) : null
        }, encode: function (a) {
            return ("" + a).split("<").join("&lt;").split(">").join("&gt;").split('"').join("&#34;").split("'").join("&#39;")
        }
    });
    a.extend(a.tmpl, {
        tag: {
            tmpl: {_default: {$2: "null"}, open: "if(_$notnull_1){_=_.concat(_$item.nest($1,$2));}"},
            wrap: {
                _default: {$2: "null"},
                open: "_$item.calls(_,$1,$2);_=[];",
                close: "call=_$item.calls();_=call._.concat(_$item.wrap(call,_));"
            },
            each: {
                _default: {$2: "_$index, _$value"},
                open: "if(_$notnull_1){_$.each($1a,function($2){with(this){",
                close: "}});}"
            },
            "if": {open: "if((_$notnull_1) && $1a){", close: "}"},
            "else": {_default: {$1: "true"}, open: "}else if((_$notnull_1) && $1a){"},
            html: {open: "if(_$notnull_1){_.push($1a);}"},
            "=": {_default: {$1: "_$data"}, open: "if(_$notnull_1){_.push(_$.encode($1a));}"},
            "!": {open: ""}
        }, complete: function () {
            y = {}
        }, afterManip: function (c, e, g) {
            var l = 11 === e.nodeType ? a.makeArray(e.childNodes) : 1 === e.nodeType ? [e] : [];
            g.call(c, e);
            u(l);
            Q++
        }
    })
})(_jQuery);
window.avsr = window.avsr || {};
window.avsr.activities = window.avsr.activities || function () {
    function a(a, e, m, p, g) {
        var c = function (c) {
            try {
                "success" != c.status && (avsr.log('Success function status != "success" : ' + c.status, "error", a, "Params : " + JSON.stringify(m), "Response : " + JSON.stringify(c)), "undefined" !== typeof failCallback && _$.isFunction(failCallback) && failCallback()), "undefined" !== typeof p && _$.isFunction(p) && p(c)
            } catch (t) {
                avsr.logException("Error in success function call", a, t, "Params : " + JSON.stringify(m), "Response : " + JSON.stringify(c)),
                "undefined" !== typeof m.exceptionCallback && _$.isFunction(m.exceptionCallback) && m.exceptionCallback(t)
            }
        }, k = function (c, e, g) {
            try {
                avsr.logXhr("Failure function call", "error", a, c, e, g, "Params : " + JSON.stringify(m), "xhr : " + JSON.stringify(c)), "timeout" === e ? "undefined" !== typeof m.callback && _$.isFunction(m.callback) && m.callback({
                    status: "error",
                    errorCode: 508
                }) : "undefined" !== typeof m.callback && _$.isFunction(m.callback) && (c.responseText ? m.callback({
                        status: "error",
                        errorCode: JSON.parse(c.responseText).errorCode
                    }) :
                    m.callback({status: "error"}))
            } catch (F) {
                avsr.logException("Error in failure function call", a, F, "Params : " + JSON.stringify(m), "xhr : " + JSON.stringify(c)), "undefined" !== typeof m.exceptionCallback && _$.isFunction(m.exceptionCallback) && m.exceptionCallback(F)
            }
        };
        g = avsr.utils.getSpecificsConf().project.Id;
        avsr.storageAccess.getSessionId(g, function (a) {
            m.sessId = a;
            avsr.ajax.post(e, m, c, k)
        })
    }

    var e = function (a, e) {
        var c = [], k = a.actionName || "" == a.actionName ? a.actionName : null;
        if (a.clientProductId) {
            var g = a.clientProductId;
            g && !g.push && (g += "", "[object Object]" != g && (g.trim && (g = g.trim()), 0 == g.indexOf("[") && (g = g.substr(1, g.length - 2)), a.clientProductId = g.split(",")));
            for (g = 0; g < a.clientProductId.length; g++) c.push({
                id: a.clientProductId[g],
                currency: a.currency,
                market: avsr.context.market,
                lang: avsr.context.lang
            }), a.price && a.price.length && a.price.length == a.clientProductId.length ? c[g].unit_sale_price = a.price[g] : a.price && 1 == a.clientProductId.length && (c[g].unit_sale_price = a.price), a.url && a.url.push && a.url.length == a.clientProductId.length ?
                c[g].url = a.url[g] : a.url && 1 == a.clientProductId.length && (c[g].url = a.url), c[g].isComplete = !1, c[g].action = k
        } else if (a.products && a.products.length) for (g = 0; g < a.products.length; g++) {
            var m = {
                id: a.products[g].id,
                catalog: a.products[g].catalog,
                url: a.products[g].url,
                unit_sale_price: a.products[g].price,
                currency: a.products[g].currency,
                action: a.products[g].action || k
            };
            m.market || (m.market = avsr.context.market);
            m.lang || (m.lang = avsr.context.lang);
            c.push(m)
        } else if (e) {
            e.product && e.product.name && (e.product.name = avsr.stringHelper.htmlDecode(e.product.name),
                e.product.description = avsr.stringHelper.htmlDecode(e.product.description));
            if (e.tags) for (g = 0; g < e.tags.length; g++) e.tags[g].name && (e.tags[g].name = avsr.stringHelper.htmlDecode(e.tags[g].name));
            if (e.basket && null != e.basket && e.basket.line_items) for (m = e.basket.line_items, g = 0; g < m.length; g++) for (var p = 0; p < m[g].quantity; p++) c.push(m[g].product); else c = [e.product];
            for (g = 0; g < c.length; g++) c[g].action = k, e.tags && (c[g].tags = e.tags), c[g].isComplete = e.nodeComplete, c[g].market || (c[g].market = avsr.context.market), c[g].lang ||
            (c[g].lang = avsr.context.lang)
        }
        return c
    }, p = function (a) {
        if (a && 0 < a.length) {
            var c = {};
            a.forEach(function (a) {
                a.cUrlView && !c[a.cUrlView] && (avsr.thirdParties.callPixel(a.cUrlView), c[a.cUrlView] = !0)
            })
        }
    }, m = function (a) {
        if (a && 0 < a.length) {
            var c = {};
            a.forEach(function (a) {
                c[a] || (avsr.thirdParties.callPixel(a), c[a] = !0)
            })
        }
    };
    return {
        notifyClick: function (c, e) {
            var k = c.callback ? c.callback : null, m = c.exceptionCallback ? c.exceptionCallback : null, g = {
                cpId: c.clientProductId ? c.clientProductId : null,
                recoId: c.recoId,
                recoGrpId: c.recoGrpId,
                tracker: c.tracker,
                subTracker: c.subTracker,
                date: c.date,
                sId: c.supportId,
                recommender: c.recommender,
                loc: c.location
            };
            c.recipeId && (g.r = c.recipeId);
            c.catalogId && (g.cId = c.catalogId);
            c.campaignId && (g.caId = c.campaignId);
            a("notifyClick", avsr.main.getAbsoluteUrl("/Activity/NotifyNodeClick", e), avsr.auth.completeParams(g), k, m)
        },
        notifyAction: avsr.utils.createHooks(function (c, k, m, p) {
            if (avsr.browserSupport.isTranslated()) avsr.log("Cannot notify action when a page is translated"); else {
                var g = null;
                window.antvoice_variable &&
                !c.clientProductId && (g = _$.extend({}, window.antvoice_variable), g.nodeComplete = !!avsr.datalayerStatus && avsr.datalayerStatus.nodeStatus != _sr.consts.NODE_INCOMPLETE);
                var q = c.actionName || "" == c.actionName ? c.actionName : null, z = c.callback ? c.callback : null,
                    u = c.exceptionCallback ? c.exceptionCallback : null,
                    t = c.webSiteId ? c.webSiteId : avsr.utils.getSpecificsConf().project.Id, A = c.transactionId;
                g && g.basket && g.basket.line_items && g.basket.transaction_id && "" != g.basket.transaction_id && (A = g.basket.transaction_id);
                var F = {
                    oId: t,
                    products: encodeURIComponent(avsr.main.stringify(e(c, g))),
                    action: q,
                    date: c.date,
                    trId: A,
                    multi: !!c.products,
                    group: c.group
                };
                c = function (a) {
                    m(F, g, a) && ("undefined" !== typeof z && _$.isFunction(z) && z(a), p(F, g))
                };
                !0 === k(F, g) && a("notifyAction", avsr.main.getAbsoluteUrl("/Activity/NotifyNodesAction"), avsr.auth.completeParams(F), c, u)
            }
        }, "startNotifyAction", "preNotifyAction", "postNotifyAction", "endNotifyAction"),
        notifyTagAction: avsr.utils.createHooks(function (c, e, m, p) {
            if (window.avsr.browserSupport.isTranslated()) avsr.log("Cannot notify action when a page is translated");
            else {
                var g = null;
                window.antvoice_variable && (g = _$.extend({}, window.antvoice_variable), g.nodeComplete = avsr.datalayerStatus.nodeStatus != _sr.consts.NODE_INCOMPLETE);
                var k = c.actionName || "" == c.actionName ? c.actionName : null, q = c.callback ? c.callback : null,
                    u = c.exceptionCallback ? c.exceptionCallback : null, t = [];
                if (c.tagLabel) t = [{
                    name: avsr.stringHelper.htmlDecode(c.tagLabel),
                    type: c.tagType,
                    action: k
                }]; else if (c.tags) for (k = 0; k < c.tags.length; k++) t.push(c.tags[k]); else {
                    for (k = 0; k < g.tags.length; k++) g.tags[k].name && (g.tags[k].name =
                        avsr.stringHelper.htmlDecode(g.tags[k].name));
                    t = g.tags
                }
                var A = {
                    date: c.date,
                    lang: avsr.context.lang,
                    market: avsr.context.market,
                    dlTags: encodeURIComponent(avsr.main.stringify(t))
                };
                c = function (a) {
                    m(A, g, a) && ("undefined" !== typeof q && _$.isFunction(q) && q(a), p(A, g))
                };
                !0 === e(A, g) && a("notifyTagAction", avsr.main.getAbsoluteUrl("/Activity/NotifyNodeTagsActions"), avsr.auth.completeParams(A), c, u)
            }
        }, "startNotifyTagAction", "preNotifyTagAction", "postNotifyTagAction", "endNotifyTagAction"),
        notifyProductDisplayed: function (a) {
            if (avsr.context.currentMember) {
                var c =
                    {
                        p: avsr.main.stringify(a.products),
                        recoId: a.recoId,
                        tracker: a.tracker,
                        subTracker: a.subTracker,
                        recommender: a.recommender,
                        loc: a.location,
                        recoGrpId: a.recoGrpId,
                        sId: a.supportId
                    };
                a.recipeId && (c.r = a.recipeId);
                var e = avsr.monitoring.getStartTime();
                avsr.ajax.post(avsr.main.getAbsoluteUrl("/Social/NotifyNodesDisplayed", a.isUseAvadsUrl), avsr.auth.completeParams(c), function (c) {
                    avsr.monitoring.measureTime(e, "NotifyProductDisplayed");
                    "success" != c.status && (avsr.log('Success function status != "success" : ' + c.status,
                        "error", "notifyProductDisplayed", "Params : " + JSON.stringify(a), "Response : " + JSON.stringify(c)), "undefined" !== typeof failCallback && _$.isFunction(failCallback) && failCallback())
                }, function (c, e, k) {
                    var g = JSON.stringify(avsr.auth.completeParams(a));
                    avsr.logXhr("Failure function call", "error", "notifyProductDisplayed", c, e, k, "Params : " + g, "xhr : " + JSON.stringify(c));
                    "timeout" === e && avsr.monitoring.logTimeOut("NotifyProductDisplayed")
                });
                p(a.products)
            }
        },
        notifyWidgetDisplayed: function (a) {
            if (avsr.context.currentMember) {
                var c =
                    {
                        recoId: a.recoId,
                        tracker: a.tracker,
                        subTracker: a.subTracker,
                        recommender: a.recommender,
                        loc: a.location,
                        cIds: JSON.stringify(a.cIds),
                        caIds: JSON.stringify(a.caIds),
                        recoGrpId: a.recoGrpId,
                        sId: a.supportId
                    };
                a.recipeId && (c.r = a.recipeId);
                var e = avsr.monitoring.getStartTime();
                avsr.ajax.post(avsr.main.getAbsoluteUrl("/Social/NotifyRecoDisplayed", a.isUseAvadsUrl), avsr.auth.completeParams(c), function (c) {
                    avsr.monitoring.measureTime(e, "NotifyWidgetDisplayed");
                    "success" != c.status && (avsr.log('Success function status != "success" : ' +
                        c.status, "error", "notifyWidgetDisplayed", "Params : " + JSON.stringify(a), "Response : " + JSON.stringify(c)), "undefined" !== typeof failCallback && _$.isFunction(failCallback) && failCallback())
                }, function (c, e, k) {
                    var g = JSON.stringify(avsr.auth.completeParams(a));
                    avsr.logXhr("Failure function call", "error", "notifyWidgetDisplayed", c, e, k, "Params : " + g, "xhr : " + JSON.stringify(c));
                    "timeout" === e && avsr.monitoring.logTimeOut("NotifyWidgetDisplayed")
                });
                m(a.cUrlImpressions)
            }
        }
    }
}();
window.avsr = window.avsr || {};
window.avsr.auth = window.avsr.auth || function () {
    var a = null, e = function (a) {
        window.avsr && window.avsr.log && window.avsr.logException && window.avsr.logXhr ? a() : 5 >= logCheckAttempts && (logCheckAttempts++, setTimeout(function () {
            e(a)
        }, 50))
    }, p = function (a) {
        var c = new Date;
        c.setDate(c.getDate() + a);
        return c
    }, m = function (a) {
        var c = new Date;
        c.setHours(c.getHours() + a);
        return c
    }, c = function () {
        var a = new Date;
        a.setFullYear(a.getFullYear() + 1);
        a.setMonth(a.getMonth() + 1);
        return a
    }, k = function (c, e, g, k, m) {
        a = {mId: c, amId: 0, tpReady: !1};
        m || (e = /(msie) ([\w.]+)/.exec(navigator.userAgent.toLowerCase()) || [], "true" != avsr.storageAccess.getCookieTpEnabledValue() || "msie" === e[1] && "10.0" !== e[2] || avsr.storageAccess.shouldUpdateAvThirdParty(function (e) {
            a.tpReady = !0;
            e && k && !1 !== avsr.utils.getSpecificsConf().availability.isThirdPartySyncEnabled && (a.tpReady = !1, avsr.thirdParties.callPixel(avsr.main.getAbsoluteUrl("/v1/identity?oId=" + avsr.utils.getSpecificsConf().project.Id + "&mId=" + c, !0)));
            g && _$.isFunction(g) && g()
        }))
    }, q = function (c, e, g, k) {
        a && (a.cId =
            c, a.amId = e, 2 == e ? a.fTo = g : a.sTo = g, a.mTo = k)
    }, u = function (a, c, e, g) {
        k(avsr.guid.newGuid(), a, c, e, g)
    }, g = function (a) {
        avsr.cookies.getKey("setavid", function (c) {
            var g = avsr.main.getStorageAccess().getCookieTpEnabledValue();
            c && "1" == c && "true" == g ? (avsr.monitoring.logCall("ShortlivedIdentity"), avsr.storageAccess.checkThirdPartyAccess(function (a) {
                e(function () {
                    avsr.log("Short lived identity", "warn", "createIdentity", "Identity storage type : " + avsr.main.getStorageAccess().getIdentityStorageType(), "Could write / read a second time to xdm storage : " +
                        a)
                })
            }), avsr.storageAccess.setThirdPartyEnabledCookie(p(30), "false"), avsr.storageAccess.initIdentityStorage(a)) : (avsr.cookies.setKey("setavid", m(72), "1"), a())
        })
    }, v = function (c) {
        avsr.context.currentMember = _$.extend({}, a);
        window.srReady = avsr.context.currentMember && !!avsr.context.currentMember.mId;
        c()
    }, z = function (c, e) {
        var g = document.location.hash,
            k = window.avsr.browserSupport.splitQueryString(document.location.search.substring(1)),
            g = window.avsr.browserSupport.splitQueryString(g.substring(1));
        (k = _$.extend(k,
            g)) && k.srGroup && (a.group = k.srGroup);
        c ? (q(c, 1), v(e)) : k && k.srAuthUserId ? (q(k.srAuthUserId, 1, void 0, k.srUserToken), v(e)) : (k = avsr.utils.getSpecificsConf().project.Id, avsr.main.getStorageAccess().getMailData(k, function (a) {
            a && (a = a.split("|"), 2 == a.length && q(a[0], 1, void 0, a[1]));
            v(e)
        }))
    }, B = function (c) {
        c.oId = avsr.utils.getSpecificsConf().project.Id;
        c.mId = a.mId;
        c.cliId = a.cId;
        c.amId = a.amId;
        c.group = a.group;
        c.lang = avsr.context.lang;
        c.market = avsr.context.market;
        c.siteToken = a.sTo;
        c.fbToken = a.fTo;
        c.mailToken = a.mTo;
        return c
    };
    return {
        loadIdentity: function (m, p, q) {
            if (!0 !== avsr.main.enforceDnt || 1 != navigator.doNotTrack && "1" != navigator.doNotTrack && "yes" != navigator.doNotTrack && "1" != window.doNotTrack) {
                var t = function () {
                    z(m, p)
                };
                avsr.main.getStorageAccess().getUniqueIdentity(function (v, A) {
                    if (!v || "" == v || 30 > v.length) avsr.monitoring.logCall("LocalStorageEmpty"), e(function () {
                        avsr.log("Local storage empty", "info", "loadIdentity", "Identity storage type : " + avsr.main.getStorageAccess().getIdentityStorageType())
                    }), "xdm-storage" ==
                    avsr.main.getStorageAccess().getIdentityStorageType() ? g(function () {
                        avsr.main.getStorageAccess().getUniqueIdentity(function (e, g) {
                            !e || "" == e || 30 > e.length ? (u(null, t, q), avsr.main.getStorageAccess().setUniqueIdentity(a.mId, c())) : k(e, null, t, q)
                        })
                    }) : (u(!1, null, q), avsr.main.getStorageAccess().setUniqueIdentity(a.mId, c()), z(m, p)); else if (5184E6 > A - Date.now()) {
                        u(!0, null, q, !0);
                        avsr.main.getStorageAccess().setUniqueIdentity(a.mId, c(), !0);
                        e(function () {
                            avsr.log("Expiring cnil", "info", "loadIdentity", "Identity storage type : " +
                                avsr.main.getStorageAccess().getIdentityStorageType(), "Old machineId : " + v, "new machine id : " + a.mId)
                        });
                        var y = B({oldMId: v});
                        avsr.ajax.post(avsr.main.getAbsoluteUrl("/Identity/Expires", !0), y, function (g) {
                            try {
                                "success" === g.status ? "alreadyExpired" == g.message ? (avsr.main.getStorageAccess().setUniqueIdentity(g.data.machineId, c()), k(g.data.machineId, null, t)) : (e(function () {
                                    avsr.log("Setting new cnil", "info", "loadIdentity", "Identity storage type : " + avsr.main.getStorageAccess().getIdentityStorageType(), "Old machineId : " +
                                        v, "new machine id : " + a.mId)
                                }), avsr.main.getStorageAccess().getCnilExpiration(function (c) {
                                    e(function () {
                                        avsr.log("new cnil date", "info", "loadIdentity", "Identity storage type : " + avsr.main.getStorageAccess().getIdentityStorageType(), "Old machineId : " + v, "new machine id : " + a.mId, "Cnil date : " + c)
                                    })
                                }), z(m, p), avsr.thirdParties.initialize(!0)) : (e(function () {
                                    avsr.log('Cnil status != "success"', "error", "loadIdentity", "Identity storage type : " + avsr.main.getStorageAccess().getIdentityStorageType(), "Old machineId : " +
                                        v, "new machine id : " + a.mId, "Response : " + JSON.stringify(g))
                                }), a.mId = v, z(m, p))
                            } catch (Q) {
                                e(function () {
                                    avsr.log("Setting new cnil", "error", "loadIdentity", "Following exception on return : " + Q)
                                })
                            }
                        }, function (c, e, g) {
                            a.mId = v;
                            z(m, p);
                            var k = JSON.stringify(k(y));
                            avsr.logXhr("Error while calling /Migration/HandleIdentities", "error", "initUser", c, e, g, "Params : " + k, "xhr : " + JSON.stringify(c))
                        })
                    } else k(v, null, t, q)
                })
            } else p()
        }, initUser: function (a, c) {
            _sr.isEnabled(function () {
                a && (a.authUserId && a.authModeId && (1 != a.authModeId ||
                    "true" != a.authUserId.toString()) ? (q(a.authUserId, a.authModeId, a.signedRequest), a && "undefined" !== typeof a.callback && _$.isFunction(a.callback) && a.callback(), v(c)) : avsr.utils.callFunction(a.callback))
            }, function () {
                c();
                avsr.log("Recommendation disabled !");
                a && !a.type && a.callback && a.callback({status: "error", errorCode: 900})
            })
        }, completeParams: B, getIdentity: function () {
            return _$.extend({}, a)
        }, logOut: function (c) {
            k(a.mId);
            avsr.context.currentMember = _$.extend({}, a);
            c()
        }, cleanTmpCookie: function () {
            var a = avsr.utils.getSpecificsConf().project.Id;
            avsr.main.getStorageAccess().getMailData(a, function (c) {
                c && avsr.main.getStorageAccess().deleteMailData(a)
            })
        }, isThirdPartyReady: function () {
            return a.tpReady
        }
    }
}();
window.avsr = window.avsr || {};
window.avsr.recoDatalayer = window.avsr.recoDatalayer || function () {
    return {
        getMode: function (a) {
            var e = "none";
            a.areaId ? e = "simple" : a.strategies && a.support && a.rendering && a.rendering.mode && (e = "advanced");
            return e
        }, updateRecoDatalayer: function (a) {
            for (var e = {}, p = 0; p < window.avsr.specifics.areaMapping.length; p++) if (conf = window.avsr.specifics.areaMapping[p], conf.areaId && a.areaId && conf.areaId == a.areaId) {
                e = conf.recoDatalayer;
                break
            }
            return e
        }
    }
}();
window.avsr = window.avsr || {};
window.avsr.recommendation = window.avsr.recommendation || function () {
    function a(a, c, g) {
        var l = g[0];
        (new IntersectionObserver(function (g, k) {
            var d = !1;
            g.forEach(function (a) {
                d = d || a.intersectionRatio >= M.threshold
            });
            d && (k.unobserve(l), window.setTimeout(e(k, l, a, c), 1E3))
        }, M)).observe(l)
    }

    function e(a, c, e, g) {
        return function () {
            (new IntersectionObserver(function (l, k) {
                k.unobserve(c);
                var d = !1;
                l.forEach(function (a) {
                    d = d || a.intersectionRatio >= M.threshold
                });
                d ? avsr.thirdParties.callPixel(avsr.main.getAbsoluteUrl("/public/v1/view?rId=" + e,
                    g)) : a.observe(c)
            }, M)).observe(c)
        }
    }

    function p() {
        var a = navigator.userAgent || navigator.vendor || window.opera;
        a.match(/iPhone|iPad|iPod/i);
        a.match(/Android/i);
        a.match(/BB10|Tablet|Mobile/i);
        a.match(/IEMobile/i);
        var c = 384 >= window.screen.width && 900 >= window.screen.height,
            e = a.match(/Tablet|iPad|iPod/i) && 1280 >= window.screen.width && 1024 >= window.screen.height;
        a.match(/Android|BlackBerry|Tablet|Mobile|iPhone|iPad|iPod|Opera Mini|IEMobile/i);
        return c ? 3 : e ? 2 : 480 <= window.screen.width && 800 <= window.screen.height ? 1 :
            0
    }

    var m, c, k, q = {}, u = {}, g = {}, v, z = function (a, e) {
        if (m === a.templateLayout && k === a.productTemplate) e(); else {
            var g = _$(a.selector), l = a.isUseAvadsUrl ? avsr.main.contentUrlAvads : avsr.main.contentUrl;
            avsr.utils.getSpecificsConf().isUseAvadsUrl && (l = avsr.main.contentUrlAvads);
            avsr.ajax.getHtml(l + "templates/" + avsr.utils.getSpecificsConf().templateKey + ".htm", function (p) {
                p = p.replace(/\[CDN\]/g, l);
                m = a.templateLayout;
                p = _$("<script>", {html: p});
                c = p.find("#container-" + a.templateLayout).html();
                k = p.find("#product-template");
                g.show();
                e()
            }, function (c) {
                avsr.logXhr("Failure function call", "error", "templatesReady", c, null, c, "Params : " + JSON.stringify(a), "xhr : " + JSON.stringify(c));
                g.hide();
                null != a.interactionsCallbacks && "undefined" !== typeof a.interactionsCallbacks.fail && _$.isFunction(a.interactionsCallbacks.fail) && a.interactionsCallbacks.fail()
            }, !0)
        }
    }, B = function (e, g, p, q, z, u) {
        var d = avsr.utils.getSpecificsConf().tracking || {}, l = "";
        g.containerId ? l = window.avsr.stringHelper.startsWith(g.containerId, "#") || window.avsr.stringHelper.startsWith(g.containerId,
            ".") ? g.containerId : "#" + g.containerId : g.selector && (l = g.selector);
        window.avsr.containerSelector = l;
        q && q.rendering && (q.rendering.containerId = l);
        if ((!e || !e.errorCode || 2302 != e.errorCode) && e.r && 2 * e.totalItems >= p.limit) {
            var w = {
                RecommendedItems: [],
                Template: m,
                TrackerLabel: p.tracker,
                SubTrackerLabel: p.subTracker,
                CatalogId: p.cId
            };
            if (avsr.utils.callInternal(avsr.specifics.startTemplating, !0, "startTemplating", q, e)) {
                var C = _$(l), r = c;
                if (e.req && e.req.areaId) {
                    var L = "av";
                    e.req.areaId.split("_").forEach(function (a) {
                        L +=
                            a[0].toUpperCase() + a.slice(1).toLowerCase()
                    });
                    r = '<div id="' + L + '">' + c + "</div>"
                }
                var E = !1, v;
                !l || g.filling && "Overwrite" != g.filling ? l && "InsertAfter" == g.filling && (E = !0, _$(l).after(r), C = _$(l).next(), v = C.find("#" + g.template + "-RecommendedItemsContainer")) : (E = !0, _$(l).empty(), _$(l).append(window.avsr.stringHelper.startsWith(l.split(" ").slice(-1)[0], "#") ? c : r), v = _$(l + " #" + g.template + "-RecommendedItemsContainer"));
                for (l = 0; l < e.r.length; l++) {
                    var I = e.r[l];
                    if (I.items) for (t(I.items), g = 0; g < I.items.length; g++) {
                        var B =
                            I.items[g];
                        w.RecommendedItems.push(B);
                        B.method = u && u.action ? u.action : "";
                        B.addToBasket = u && u.addToBasket ? u.addToBasket : "";
                        if (B.pictures) {
                            var A = 0;
                            _$.each(B.pictures, function (a, d) {
                                a > A && (B.adsPicture = d, A = a)
                            })
                        }
                        !0 === d.useRedirect && (p.r = I.r, B.url = avsr.main.getAbsoluteUrl("/Activity/RecordClick", I.isUseAvadsUrl) + y(e.gId, I.recoGuid, B.clientProductId, B.url, p, B.catalogId, "ANTVOICE", B.campaignId))
                    }
                }
                u = _$.tmpl(k, w);
                v.html(u);
                for (g = 0; g < e.r.length; g++) I = e.r[g], !0 !== d.useRedirect && N(I.recoGuid, e.r[g].isUseAvadsUrl);
                avsr.utils.callInternal(avsr.specifics.endTemplating, !1, "endTemplating", q, e, v);
                E && avsr.main.ensureCssLoaded(function () {
                    C.show()
                });
                for (g = 0; g < e.r.length; g++) if (I = e.r[g], E) 0 < I.items.length && (O(p, I, !1, I.isUseAvadsUrl), a(I.recoGuid, I.isUseAvadsUrl, v)), z && z(I.items, I.recoGuid, I.log, I.isAbTesting, I.isActive); else for (g = 0; g < e.r.length; g++) {
                    var I = e.r[g], S = I.recoGuid;
                    q = function () {
                        !0 !== d.useRedirect && N(S, I.isUseAvadsUrl);
                        0 < I.items.length && (O(p, I, !1, I.isUseAvadsUrl), a(I.recoGuid, I.isUseAvadsUrl, v))
                    };
                    z && z({
                        html: u.html(),
                        items: I.items, callback: q
                    }, I.recoGuid, I.log, I.isAbTesting)
                }
                return !0
            }
        } else return _$(l).hide(), !1
    }, t = function (a) {
        a && a.length && a.forEach(function (a) {
            u[a.catalogId] || (u[a.catalogId] = {});
            u[a.catalogId][a.clientProductId] = {
                campaignId: a.campaignId,
                catalogId: a.catalogId,
                nodeId: a.id,
                cUrlView: a.cUrlView
            }
        })
    }, A = function (a, c) {
        if (c) {
            if (u[c]) return u[c][a]
        } else {
            var e = Object.keys(u)[0];
            if (u[e]) return u[e][a]
        }
    }, F = function (a, c, e, g) {
        for (var l = avsr.utils.getSpecificsConf().tracking || {}, k = 0; k < a.r.length; k++) {
            t(a.r[k].items);
            for (var d = 0; d < a.r[k].items.length; d++) !0 === l.useRedirect && (c.r = a.r[k].r, a.r[k].items[d].url = avsr.main.getAbsoluteUrl("/Activity/RecordClick", g.isUseAvadsUrl) + y(a.gId, a.r[k].recoGuid, a.r[k].items[d].clientProductId, a.r[k].items[d].url, c, a.r[k].items[d].catalogId, "ANTVOICE", a.r[k].items[d].campaignId));
            !0 !== l.useRedirect && N(a.r[k].recoGuid, a.r[k].isUseAvadsUrl);
            !g.disableWidgetDisplayed && 0 < a.r[k].items.length && O(c, a.r[k], !0, a.r[k].isUseAvadsUrl);
            e && e(a.r[k].items, a.r[k].recoGuid, a.r[k].log, a.r[k].isAbTesting,
                a.r[k].isActive, a.r[k].owners)
        }
    }, y = function (a, c, e, g, k, m, d, p) {
        a = {
            cpId: e,
            recoId: c,
            recoGrpId: a,
            tracker: k.tracker,
            subTracker: k.subTracker,
            recommender: d,
            loc: k.loc,
            domain: document.location.hostname,
            sId: k.support
        };
        k.r && (a.r = k.r);
        m && (a.cId = m);
        p && (a.caId = p);
        var l = avsr.auth.completeParams(a);
        Object.keys(l).forEach(function (a) {
            void 0 === l[a] && delete l[a]
        });
        return "?" + _$.param(l) + "&target=" + encodeURIComponent(g)
    }, D = function (a, c, e) {
        if (avsr.specifics.getRecoTriggeringDistance && _$.isFunction(avsr.specifics.getRecoTriggeringDistance)) {
            var g =
                avsr.specifics.getRecoTriggeringDistance(a);
            _$.isNumeric(g) && -1 < g && (!c && _$.isArray(a) ? a.forEach(function (a) {
                c || a && a.rendering && (a.rendering.containerId || a.rendering.selector) && (c = a.rendering.containerId || a.rendering.selector)
            }) : !c || window.avsr.stringHelper.startsWith(c, "#") || window.avsr.stringHelper.startsWith(c, ".") || (c = "#" + c), g = {
                selector: c,
                distance: g
            });
            if (_$.isPlainObject(g) && g.selector && _$.isNumeric(g.distance) && -1 < g.distance) {
                if (0 < _$(g.selector).length) {
                    avsr.monitoring.logCall("DelayedRecommendationPrepared");
                    avsr.scrollMonitor.create(_$(g.selector), g.distance).one("enterViewport", function () {
                        e()
                    });
                    return
                }
                window.avsr.monitoring.logCall("ContainerNonExistent")
            }
        }
        e()
    }, H = function (a, c, e, k) {
        if (null == a.recoGuid) {
            for (var l = {}, m = 0; m < c.items.length; m++) c.items[m].campaignId && (l[c.items[m].campaignId] = !0);
            k = {
                recoId: c.recoGuid,
                tracker: a.tracker,
                subTracker: a.subTracker,
                recommender: e,
                location: a.loc,
                recipeId: c.r,
                cIds: c.cIds,
                caIds: Object.keys(l),
                recoGrpId: g[c.recoGuid],
                supportId: a.support,
                isUseAvadsUrl: k,
                cUrlImpressions: c.cUrlsImpression
            };
            q[c.recoGuid] = {
                tracker: a.tracker,
                subTracker: a.subTracker,
                recommender: e,
                location: a.loc,
                recipeId: c.r,
                catalogIds: c.cIds,
                supportId: a.support
            };
            avsr.activities.notifyWidgetDisplayed(k)
        }
    }, O = function (a, c, e, k) {
        var l = [], m = [], d = function () {
            var a = {};
            _$("*[data-sr-recoGuid=" + c.recoGuid + "][data-sr-id][data-sr-nodisplay!=true][data-sr-attached!=true]").each(function (d, c) {
                var e = _$(c), g = avsr.scrollMonitor.create(_$(c));
                0 > m.indexOf(e.attr("data-sr-id")) && (m.push(e.attr("data-sr-id")), g.one("enterViewport", function () {
                    if (0 !=
                        this.top || 0 != this.bottom) {
                        var d = _$(this.watchItem).attr("data-sr-id"), c = _$(this.watchItem).attr("data-sr-catalog"),
                            c = A(d, c);
                        c.cUrlView && !a[c.cUrlView] ? (l.push({
                            cpId: d,
                            cId: c.catalogId,
                            caId: c.campaignId,
                            cUrlView: c.cUrlView
                        }), a[c.cUrlView] = !0) : l.push({cpId: d, cId: c.catalogId, caId: c.campaignId})
                    }
                }));
                e.attr("data-sr-attached", "true")
            })
        };
        if (e) {
            var p = a.limit, q = setInterval(function () {
                d()
            }, 100);
            setInterval(function () {
                q && _$("*[data-sr-attached]").length == p && (clearInterval(q), q = null)
            }, 1E3)
        } else d();
        setInterval(function () {
            0 <
            l.length && (avsr.activities.notifyProductDisplayed({
                recoId: c.recoGuid,
                products: l,
                tracker: a.tracker,
                subTracker: a.subTracker,
                recommender: a.recommender,
                location: a.loc,
                recipeId: c.r,
                recoGrpId: g[c.recoGuid],
                supportId: a.support,
                isUseAvadsUrl: k
            }), l = [])
        }, 1E3);
        g[c.recoGuid] = a.recoGrpId;
        H(a, c, "ANTVOICE", k)
    }, M = {root: null, rootMargin: "0px", threshold: .5}, Q = function (a, c, e) {
        var l = _$(a).attr("data-sr-recoGuid"), k = q[l] || {}, m = _$(a).attr("data-sr-id");
        a = _$(a).attr("data-sr-catalog");
        a = A(m, a);
        c = {
            clientProductId: m,
            tracker: k.tracker,
            subTracker: k.subTracker,
            recoId: l,
            callback: c,
            exceptionCallback: e,
            recommender: k.recommender,
            location: k.location,
            recoGrpId: g[l],
            supportId: k.supportId
        };
        k.recipeId && (c.recipeId = k.recipeId);
        a.catalogId && (c.catalogId = a.catalogId);
        a.campaignId && (c.campaignId = a.campaignId);
        return c
    }, V = function (a, c, e, g) {
        try {
            avsr.activities.notifyClick(Q(a, c, e), g)
        } catch (R) {
            avsr.logException("Error while calling notifyClick", "notifyClick", R), avrs.main.isFunction(e) && e(R)
        }
    }, G = function (a, c) {
        a = _$(a);
        var e, g = null, l = "a";
        a[0].nodeName.toLowerCase() ==
        l ? e = a : _$(c)[0].nodeName.toLowerCase() == l ? e = _$(c) : (e = a.parentsUntil(_$(c), l), 0 == e.length && (l = "form", e = a.parentsUntil(_$(c), l)));
        0 < e.length && (g = {
            el: _$(e[0]),
            isForm: "form" == l,
            shouldRedirect: "false" != e.attr("data-sr-redirect") && "false" != a.attr("data-sr-redirect"),
            shouldNotify: "false" != e.attr("data-sr-notify") && "false" != a.attr("data-sr-notify"),
            shouldTrigger: "false" != e.attr("data-sr-trigger") && "false" != a.attr("data-sr-trigger")
        });
        return g
    }, N = function (a, c) {
        var e = {}, g = function (a, d) {
            var c = _$(a).attr("data-sr-id");
            0 == e[c] ? window.setTimeout(function () {
                g(a, d)
            }, 50) : l(d)
        }, l = function (a) {
            a.shouldRedirect && !a.isForm ? window.location = a.el[0].href : a.isForm ? a.el.submit() : a.shouldTrigger && a.el.attr("data-sr-onclick") && _$.globalEval(a.el.attr("data-sr-onclick"))
        };
        _$(document.body).off("click.avsr", "*[data-sr-recoGuid=" + a + "]");
        _$(document.body).on("click.avsr", "*[data-sr-recoGuid=" + a + "]", function (a) {
            var d = _$(this).attr("data-sr-id"), c = G(a.target, this);
            !0 === e[d] || null == c || 2 == a.which || 3 == a.which || a.ctrlKey || "_blank" == c.el.attr("target") ||
            a.preventDefault()
        });
        _$(document.body).off("mouseup.avsr", "*[data-sr-recoGuid=" + a + "]");
        _$(document.body).on("mouseup.avsr", "*[data-sr-recoGuid=" + a + "]", function (a) {
            var d = _$(this).attr("data-sr-id");
            if (void 0 === e[d]) {
                e[d] = !1;
                try {
                    var k = G(a.target, this);
                    k.shouldNotify ? V(this, function () {
                        e[d] = !0
                    }, function (a) {
                        avsr.monitoring.logClientCall("RecordingClickError");
                        l(k)
                    }, c) : delete e[d];
                    var m = !1;
                    "mouseup" != a.type || null == k || 2 != a.which && 3 != a.which && !a.ctrlKey && "_blank" != k.el.attr("target") || (m = !0);
                    !k || m && !k.isForm ||
                    g(this, k);
                    k && m && k.el.attr("data-sr-ontab") && _$.globalEval(k.el.attr("data-sr-ontab"))
                } catch (Y) {
                    avsr.logException("Error while binding event mouseup.avsr", "mouseup.avsr", Y), delete e[d]
                }
            }
        })
    }, J = function (a, c) {
        var e = null;
        c.forEach(function (c) {
            c.location && null == e && "ProductPage" == c.location && (a.product ? a.product.id || (e = "Product id is not defined") : e = "Currently on ProductPage but no product defined")
        });
        return e
    };
    return {
        getReco: avsr.utils.createHooks(function (a, c, e, g, k, m) {
            try {
                var d = avsr.auth.completeParams({});
                d.r = JSON.stringify(a);
                var l = {
                    page: window.antvoice_variable.page,
                    product: window.antvoice_variable.product,
                    project: window.antvoice_variable.project,
                    user: window.antvoice_variable.user,
                    recommendations_debug: window.antvoice_variable.recommendations_debug
                }, q = window.avsr.browserSupport.splitQueryString(window.location.search.substr(1));
                q && q.srRuleId && (l.recommendations_debug || (l.recommendations_debug = {}), l.recommendations_debug.ruleId = q.srRuleId);
                d.d = JSON.stringify(l);
                var t;
                window.window.antvoice_variable.recommendations_debug &&
                (t = window.antvoice_variable.recommendations_debug.url);
                d.url = t || window.location.href;
                d.dv = p();
                var r, L = new Date;
                r = window.window.antvoice_variable.recommendations_debug && window.window.antvoice_variable.recommendations_debug.userTimestamp ? window.window.antvoice_variable.recommendations_debug.userTimestamp : parseInt((new Date).getTime() / 1E3);
                tzO = window.window.antvoice_variable.recommendations_debug && window.window.antvoice_variable.recommendations_debug.userTimezoneOffset ? window.window.antvoice_variable.recommendations_debug.userTimezoneOffset :
                    60 * L.getTimezoneOffset();
                d.uTs = r;
                d.tzO = tzO;
                q = null;
                if (null != (q = J(l, a))) avsr.log("Recommendation was stopped before calling the server : " + q, "error", "getReco", "Params:" + JSON.stringify(d)), avsr.utils.callFunction(e); else {
                    var u = function (g) {
                        if (!g.data || !g.data.g || g.data.g.length != a.length) return avsr.log("Response does not have data", "error", "getReco", "Params : " + JSON.stringify(d), "Response : " + JSON.stringify(g)), e && e(), !1;
                        v = g.data;
                        if ("success" !== g.status) return avsr.log('Response status != "success" : ' +
                            g.status, "error", "getReco", "Params : " + JSON.stringify(d), "Response : " + JSON.stringify(g)), g.data && g.data.g && 0 < g.data.g.length && g.data.g.forEach(function (a) {
                            a.r && 0 < a.r.length && a.r.forEach(function (a) {
                                2002 === a.errorCode && avsr.logDatalayerErrors("Filters error. E : " + a.error)
                            })
                        }), e && e(), !1;
                        var r = !1;
                        g.data && g.data.g && 0 < g.data.g.length && g.data.g.forEach(function (c, e) {
                            if (2302 === c.errorCode) {
                                avsr.log("Recommendation is not suitable", "info", "getReco", "Params : " + JSON.stringify(d), "Response : " + JSON.stringify(g));
                                var l = a[e];
                                if (l.rendering && l.rendering.onError && _$.isFunction(l.rendering.onError)) l.rendering.onError({
                                    requestIndex: e,
                                    message: "Recommendation is not suitable",
                                    errorCode: 2302,
                                    group: c
                                });
                                r = !0
                            }
                        });
                        if (r) return !1;
                        if (g.data && g.data.g && 0 < g.data.g.length && "success" === g.status) {
                            var p = 0;
                            g.data.g.forEach(function (d) {
                                var c = {total: 0}, e = a[p].areaId;
                                e && (window.avsr.recoState || (window.avsr.recoState = {}), d.r && 0 < d.r.length && d.r.forEach(function (a) {
                                    c[a.recoGuid] = [];
                                    c.items && a.items.forEach(function (d) {
                                        c[a.recoGuid].push(d)
                                    });
                                    c.total += c[a.recoGuid].length
                                }), window.avsr.recoState[e] = c);
                                p++
                            })
                        }
                        if (!k(d, g)) return avsr.log("Recommendation was stopped after getting the recommendation result", "info", "getReco", "Params : " + JSON.stringify(d), "Response : " + JSON.stringify(g)), !1;
                        0 < a.length ? avsr.main.loadCss(a[0].isUseAvadsUrl) : avsr.main.loadCss();
                        g.data.g.forEach(function (c, e) {
                            var k = a[e];
                            c.req && (k = c.req, a[e].rendering && (a[e].rendering.onSuccess && (k.rendering.onSuccess = a[e].rendering.onSuccess), a[e].rendering.onError && (k.rendering.onError =
                                a[e].rendering.onError)));
                            for (var r = 0, p = 0; p < k.strategies.length; p++) r += k.strategies[p].qty;
                            var q = {
                                isDatalayer: !0,
                                recommender: "ANTVOICE",
                                loc: k.location || l.page.type,
                                limit: r,
                                support: k.support,
                                recoGrpId: c.gId
                            };
                            null != k.tracking && (q.tracker = null != k.tracking.tracker ? k.tracking.tracker : "", q.subTracker = null != k.tracking.subTracker ? k.tracking.subTracker : "");
                            if ("html" === k.rendering.mode) try {
                                z({
                                        templateLayout: k.rendering.template,
                                        selector: k.rendering.containerId || k.rendering.selector,
                                        isUseAvadsUrl: k.isUseAvadsUrl
                                    },
                                    function () {
                                        if (!0 === B(c, k.rendering, q, k)) {
                                            if (k.rendering.onSuccess) k.rendering.onSuccess({
                                                requestIndex: e,
                                                group: c
                                            })
                                        } else if (avsr.log("Error trying to get a recommendation with these parameters", "error", "recommendationSet", "Request : " + JSON.stringify(k), "Recommendation group : " + JSON.stringify(c)), k.rendering.onError) k.rendering.onError({
                                            requestIndex: e,
                                            message: "Error trying to get a recommendation with these parameters",
                                            group: c
                                        });
                                        g.data.g.length == e + 1 && m(d)
                                    })
                            } catch (ca) {
                                if (avsr.logException("Could not templatize a group of recommendations",
                                    "social.reco.recommendations.getReco", ca, "recommendation group : " + JSON.stringify(c), "recommendation request : " + JSON.stringify(k)), k.rendering.onError) k.rendering.onError({
                                    requestIndex: e,
                                    message: "template error",
                                    group: c
                                })
                            } else try {
                                F(c, q, void 0, k);
                                if (k.rendering.callback) {
                                    var t = eval(k.rendering.callback);
                                    t ? t.apply(this, [{
                                        requestIndex: e,
                                        group: c
                                    }]) : avsr.log("No callback with name " + k.rendering.callback, "error", "recommendationSet")
                                }
                                if (k.rendering.onSuccess) k.rendering.onSuccess({requestIndex: e, group: c});
                                g.data.g.length == e + 1 && m(d)
                            } catch (ca) {
                                if (avsr.logException("Error calling the recommendation callback with these parameters : " + ca, "social.reco.recommendations.getReco", ca, "recommendation group : " + JSON.stringify(c), "recommendation callback : " + k.rendering.callback), window.avsr.consoleLog("error", ca), k.rendering.onError) k.rendering.onError({
                                    requestIndex: e,
                                    message: "Error trying to get a recommendation with these parameters",
                                    group: c
                                })
                            }
                        });
                        c && c()
                    }, w = function (a, c, g) {
                        avsr.logXhr("Error while calling /Recommendation/Recommend",
                            "error", "getReco", a, c, g, "Params : " + JSON.stringify(d), "xhr : " + JSON.stringify(a));
                        e && e()
                    };
                    avsr.storageAccess.getAllOwnerDisabled(function (c) {
                        d.excludedOwners = c;
                        g(d) ? D(a, null, function () {
                            "true" === a[0].isUseAvadsUrl && (a[0].isUseAvadsUrl = !0);
                            avsr.ajax.post(avsr.main.getAbsoluteUrl("/Recommendation/Recommend", a[0].isUseAvadsUrl), d, u, w)
                        }) : avsr.log("Recommendation was stopped before calling the server", "info", "getReco", "Params : " + JSON.stringify(d))
                    })
                }
            } catch (I) {
                avsr.logException("Exception while calling /Recommendation/Recommend",
                    "social.reco.recommendations.getReco", I), e && e()
            }
        }, "startGetReco", "preGetReco", "postGetReco", "endGetReco"), enableRecommendation: function (a, c, e) {
            var g = new Date;
            g.setFullYear(g.getFullYear() + 10);
            avsr.main.getStorageAccess().deleteRecoEnabledFlag(avsr.utils.getSpecificsConf().project.Id);
            avsr.main.getStorageAccess().setRecoEnabledFlag(avsr.utils.getSpecificsConf().project.Id, g, a ? "1" : "0");
            a ? (_sr.init({callback: e}), c && _$("#" + c).show()) : (c && _$("#" + c).hide(), "undefined" != typeof e && _$.isFunction(e) && e({enable: "false"}))
        },
        isRecommendationEnabled: function (a, c) {
            !0 !== avsr.main.enforceDnt || 1 != navigator.doNotTrack && "1" != navigator.doNotTrack && "yes" != navigator.doNotTrack && "1" != window.doNotTrack || !_$.isFunction(c) ? avsr.main.getStorageAccess().getRecoEnabledFlag(avsr.utils.getSpecificsConf().project.Id, function (e) {
                null != e ? "1" == e ? a && _$.isFunction(a) && a() : c && _$.isFunction(c) && c() : a && _$.isFunction(a) && a()
            }) : c()
        }, enabledAds: function (a, c) {
            var e = new Date;
            e.setFullYear(e.getFullYear() + 1);
            avsr.main.getStorageAccess().deleteAdsEnabledFlag();
            avsr.main.getStorageAccess().setAdsEnabledFlag(e, a ? "1" : "0");
            a || (e = avsr.auth.completeParams([]), avsr.ajax.getHtml(avsr.main.getAbsoluteUrl("/v1/unsubscribe?oId=" + avsr.utils.getSpecificsConf().project.Id + "&mId=" + e.mId, !0)))
        }, isAdsEnabled: function (a, c) {
            !0 !== avsr.main.enforceDnt || 1 != navigator.doNotTrack && "1" != navigator.doNotTrack && "yes" != navigator.doNotTrack && "1" != window.doNotTrack || !_$.isFunction(c) ? avsr.main.getStorageAccess().getAdsEnabledFlag(function (e) {
                null != e ? "1" == e ? a && _$.isFunction(a) && a() : c &&
                    _$.isFunction(c) && c() : a && _$.isFunction(a) && a()
            }) : c()
        }, getDisabledDatas: function (a) {
            !0 !== avsr.main.enforceDnt || 1 != navigator.doNotTrack && "1" != navigator.doNotTrack && "yes" != navigator.doNotTrack && "1" != window.doNotTrack || !_$.isFunction(a) ? avsr.main.getStorageAccess().getDisabledDatas(avsr.utils.getSpecificsConf().project.Id, function (c) {
                a(c)
            }) : a({isEnabledAds: !1, isEnabledReco: !1})
        }, dataResponseRecoForAutomation: function () {
            return v
        }
    }
}();
window.avsr = window.avsr || {};
window.avsr.preview = window.avsr.preview || function () {
    function a() {
        var a = [];
        _$("*").filter(function () {
            return "fixed" === _$(this).css("position")
        }).each(function () {
            var c = _$(this);
            0 === c.offset().top && c.width() === document.documentElement.clientWidth && 0 < c.height() && 500 > c.height() && "none" !== c.css("display") && a.push(c)
        });
        return a
    }

    function e(a, c, g, k, m) {
        a ? 0 < _$("body").find("[data-sr-recoguid='" + a + "']").length ? setTimeout(function () {
            k()
        }, 300) : c < g ? (c++, setTimeout(function () {
            e(a, c, g, k, m)
        }, 50)) : m() : m()
    }

    function p(a,
               c, e, g, k) {
        setTimeout(function () {
            c++;
            c < e && window.avsr && window.avsr.recoState && window.avsr.recoState[a] ? g(window.avsr.recoState[a]) : c >= e ? k() : p(a, c, e, g, k)
        }, 50)
    }

    function m() {
        var c = a();
        if (c.length) {
            var e = 0;
            c.forEach(function (a) {
                a.height() > e && (e = a.height())
            });
            return e + 20
        }
        return 20
    }

    function c(a) {
        var c = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
        a = '<div id="ant-bg-popup"> <style> .ant-preview-ng { position: absolute; background: rgba(0,0,0,0.5); \t  z-index: 9999999998; } \t.ant-preview-popup{ position:fixed;\t z-index: 9999999999; width:500px;\t height:150px;background:#fff;\t} \t.ant-preview-text-container { position:relative;\t padding-left:10%;padding-right:10%;background:#fff;height:100%;width: 100%;text-align:center;display:table;\t}\t.ant-preview-text{display:table-cell;text-align:middle;font-style: italic;color:grey;vertical-align:middle;user-select: none;\t}  </style> \x3c!--EVERYWHERE--\x3e <div class="ant-preview-ng" style="height:' +
            _$(document).height() + "px;width:" + _$(document).width() + 'px;"></div> <div class="ant-preview-popup" style="top:' + (c / 2 - 75).toString() + "px;left:" + (c / 2 - 250).toString() + 'px;"><div class="ant-preview-text-container"><div class="ant-preview-text">' + a + "</div></div></div > \t</div>";
        _$("body").prepend(a)
    }

    function k(a) {
        var c = _$("body"), e = m(), g = a.offset().top - e, k = a.offset().top + a.height() + e,
            p = a.offset().left - 20, q = a.offset().left + a.width() + 20;
        a = '<div id="ant-bg"> <style> .ant-preview-ng { position: absolute; background: rgba(0,0,0,0.5);z-index: 9999999998; } </style>\x3c!--TOP--\x3e<div class="ant-preview-ng" style="height:' +
            g + "px;width:" + _$(document).width() + 'px;"></div>\x3c!--BOTTOM--\x3e<div class="ant-preview-ng" style="top:' + k + "px;height:" + (c.height() - k) + "px; width:" + _$(document).width() + 'px;"></div> \x3c!--LEFT--\x3e <div class="ant-preview-ng" style="top:' + g + "px;height:" + (a.height() + 2 * e) + "px;width:" + p + 'px;"></div>\x3c!--RIGHT--\x3e <div class="ant-preview-ng" style="top:' + g + "px;left:" + q + "px;height:" + (a.height() + 2 * e) + "px;width:" + (_$(document).width() - q) + 'px;"></div><div>';
        _$("body").prepend(a);
        _$("html, body").animate({
            scrollTop: g -
                100
        }, "slow")
    }

    function q(a) {
        if (a) {
            var c = _$(a);
            for (a = 0 < c.height(); !a && c;) c = c.parent(), a = 0 < c.height();
            return c
        }
    }

    function u(a, g) {
        a ? p(a, -1, 15, function (m) {
            var p, t, u = 0, z;
            for (z in m) if (m.hasOwnProperty(z) && m[z].constructor === Array) {
                if (0 === u) p = z; else if (1 == u) t = z; else break;
                u++
            }
            t || (t = p);
            e(p, 0, 100, function () {
                var a;
                try {
                    if (p === t) {
                        var c, e;
                        _$("body").find("[data-sr-recoguid='" + p + "']").each(function (a) {
                            0 == a ? c = _$(this) : 1 == a && (e = _$(this))
                        })
                    } else c = _$("body").find("[data-sr-recoguid='" + p + "']"), e = _$("body").find("[data-sr-recoguid='" +
                        t + "']");
                    a = v(c, e)
                } catch (Q) {
                    a = void 0
                }
                a && (a = q(a)) && _$(a) && (k(a), g())
            }, function () {
                c("There is no widget by the name of " + a + " on this page.")
            })
        }, function () {
            window.avsr && window.avsr.recoState && window.avsr && window.avsr[a] && !window.avsr[a].total ? c("Sorry, your campaign is too restrictive. Please change some filters to get more elements.") : window.avsr && window.avsr.recoState && window.avsr && !window.avsr[a] && c("There is no widget by the name of " + a + " on this page.")
        }) : g()
    }

    function g() {
        var a = {};
        if (1 < window.location.search.length) for (var c,
                                                        e = 0, g = window.location.search.substr(1).split("&"); e < g.length; e++) c = g[e].split("="), a[unescape(c[0])] = 1 < c.length ? unescape(c[1]) : "";
        for (var k in a) a.hasOwnProperty(k) && "null" === a[k] && delete a[k];
        return a
    }

    function v(a, c) {
        _$parentsa = a.parents();
        _$parentsb = c.parents();
        var e = null;
        _$parentsa.each(function () {
            var a = this;
            _$parentsb.each(function () {
                if (a == this) return e = this, !1
            });
            if (e) return !1
        });
        return e
    }

    _$(function () {
        var a = g();
        a.srPreview && a.srAreaId && (u(a.srAreaId, function () {
        }), _$(window).resize(function () {
            window.window.avsr.preview.resizing ||
            (window.avsr.preview.resizing = !0, _$("#ant-bg").remove(), u(a.srAreaId, function () {
                window.avsr.preview.resizing = !1
            }))
        }))
    });
    return {}
}();
window.avsr = window.avsr || {};
window.avsr.main = window.avsr.main || function () {
    function a() {
        if (window.antvoice_variable && avsr.specifics.fillDatalayer) {
            var a = null, c = window.antvoice_variable;
            c.page && c.page.type || (a = "page does not exists or contains an error");
            c.project || (a = "project must be defined");
            null == a && "ProductPage" == c.page.type && (c.product ? c.product.id || c.product.url || (a = "At least product id or url must be defined defined") : a = "Currently on ProductPage but no product defined");
            if (null == a && "PaiementConfirmationPage" == c.page.type) if (!c.basket) a =
                "Currently on PaiementConfirmationPage but no basket defined"; else if (!c.basket.transaction_id) a = "Transaction Id is not defined"; else if (!c.basket.line_items || 0 < !c.basket.line_items.length) a = "No products in basket";
            c.tags && c.tags.forEach(function (c) {
                c.type && c.name && c.action || (a = "A least one tag is incomplete")
            });
            if (null !== a) return c = {
                err: a,
                type: 0,
                href: document.location.href,
                oId: avsr.utils.getSpecificsConf().project.Id
            }, avsr.ajax.post(avsr.main.getAbsoluteUrl("/Datalayer/Report"), c), !1
        }
        return !0
    }

    function e(a,
               c, e) {
        J(a) && N(function () {
            m(function () {
                var e = avsr.context.currentMember;
                R(a.actionName) ? y(function (g) {
                    g.isEnabledReco && !avsr.utils.getSpecificsConf().isUseAvadsUrl || g.isEnabledAds && avsr.utils.getSpecificsConf().isUseAvadsUrl ? e ? c(a) : (g = avsr.cookies.getKey(avsr.cookies.getRecoCookieName()), avsr.log("(" + c + ") : Member null : " + g, "error", "notify")) : a && a.callback && d(a.callback, 900)
                }) : d(a.callback, 5001)
            })
        })
    }

    function p() {
        for (var a = 0; a < v.length; a++) v[a]();
        v = []
    }

    function m(a) {
        g ? a() : v.push(a)
    }

    function c() {
        J() &&
        N(function () {
            try {
                var a = Y().getDeferredNotifications();
                if (a && -1 != a.indexOf("{")) for (var c = a.substring(1).split("|"), a = 0; a < c.length; a++) try {
                    var d = _$.parseJSON(c[a]);
                    e(d, avsr.activities.notifyClick)
                } catch (ka) {
                    avsr.logException("Cannot parse the defered parameters", "handleDeferredActivities", ka)
                }
                Y().deleteDeferredNotifications();
                g = !0;
                p()
            } catch (ka) {
                avsr.logException("Cannot read the storage deferedNotifications", "handleDeferredActivities", ka)
            }
            g = !0;
            p()
        })
    }

    function k() {
        J() && N(function () {
            try {
                avsr.thirdParties.initialize()
            } catch (r) {
                avsr.logException("Cannot synchronize third party identites",
                    "handleThirdPartiesIndentities", r)
            }
        })
    }

    function q(a) {
        J() && N(function () {
            try {
                window.antvoice_variable && window.antvoice_variable.recommendations && a && avsr.main.getReco(window.antvoice_variable.recommendations)
            } catch (L) {
                console.error(L), avsr.logException("Couldn't get data layered recommendation to work", "handleDatalayeredRecommendation", L)
            }
        })
    }

    function u() {
        J() && N(function () {
            try {
                Y().cleanSessionCookies()
            } catch (r) {
                avsr.logException("Couldn't clean session cookies", "cleanSessionCookies", r)
            }
        })
    }

    var g = !1, v = [],
        z = "//social-reco.antvoice.com/".replace("http:", document.location.protocol),
        B = document.location.protocol + "//ads.avads.net/",
        t = "//img.antvoice.com/".replace("http:", document.location.protocol), A = null,
        F = {currentMember: {}, lang: "N/A", market: "N/A"}, y = function (a) {
            S() && avsr.main.getOptOutDatas(function (c) {
                a(c)
            }, function (c) {
                a(c)
            })
        }, D = function () {
            !window.antvoice_variable && window.webSiteName && (window.antvoice_variable = {
                project: window.webSiteName,
                page: {type: "HomePage"}
            });
            var a = avsr.specifics.fillDatalayer;
            !a &&
            avsr.specifics.completeDatalayer && _$.isFunction(avsr.specifics.completeDatalayer) && (a = avsr.specifics.completeDatalayer);
            try {
                window.avsr.datalayerStatus = avsr.utils.callInternal(a, !1, "fillDatalayer", null, {})
            } catch (T) {
                var c = !1;
                ["M\u00e9moire insuffisante", "Out of memory"].forEach(function (a) {
                    c = c || 0 < T.message.indexOf(a)
                });
                c || (a = {
                    err: "An exception occured. " + T,
                    type: 0,
                    href: document.location.href,
                    oId: avsr.utils.getSpecificsConf().project.Id
                }, avsr.ajax.post(avsr.main.getAbsoluteUrl("/Datalayer/Report"), a))
            }
        },
        H = function () {
            avsr.cookies && avsr.loggingConfiguration && avsr.loggingConfiguration.enabled && avsr.loggingConfiguration.sampleRate && avsr.cookies.getKey("av-logging-sample-rate", function (a) {
                if (!a) {
                    a = Math.floor(100 * Math.random());
                    var c = new Date;
                    c.setHours(c.getHours() + 1);
                    window.avsr.cookies.setKey("av-logging-sample-rate", c, a)
                }
            });
            if (avsr.loggingConfiguration && avsr.loggingConfiguration.enabled && avsr.loggingConfiguration.windowOnErrorEnabled) {
                var a = window.onerror;
                window.onerror = function (c, d, e, g, k) {
                    try {
                        k ? avsr.logException("window.onerror exception : " +
                            c, "window.onerror", k) : avsr.log("window.onerror exception : " + c, "error", "window.onerror")
                    } catch (ra) {
                    }
                    a && a(c, d, e, g, k)
                }
            }
            window.avsr.main.currentWindowGuid = window.avsr.guid.newGuid();
            var c = window.onload;
            window.onload = function () {
                window.avsr.main.currentWindowGuid = window.avsr.guid.newGuid();
                c && c()
            }
        }, O = {}, M = [], Q = function (a) {
            if (O[a]) for (var c; c = O[a].pop();) c();
            c = M.indexOf(a);
            -1 < c && (M.splice(c, 1), O[a] && delete O[a])
        }, V = function (a, c) {
            0 > M.indexOf(a) && (M.push(a), c())
        }, G = function (a, c) {
            0 > M.indexOf(a) ? c() : (O[a] ||
            (O[a] = []), O[a].push(c))
        }, N = function (a) {
            G("identityLoaded", a)
        }, J = function (a) {
            null === A && (A = avsr.browserSupport.isSupported(), A || (avsr.log("Browser is not supported.", "error", "ensureBrowserSupport"), window.avsr.monitoring.logCall("BrowserNotSupported")));
            if (A) return !0;
            d(a, 600);
            return !1
        }, l = function (a) {
            e(a, avsr.activities.notifyAction, _sr.consts.NOTIFY_ACTION)
        }, C = function (c) {
            D();
            if (avsr.utils.callInternal(a, !1, "isDatalerLayerValid")) if (null == avsr.datalayerStatus && (avsr.datalayerStatus = {
                dlStatus: _sr.consts.DL_NOTUSED,
                nodeStatus: _sr.consts.NODE_EMPTY, error: ""
            }), avsr.datalayerStatus.dlStatus == _sr.consts.DL_ERR || avsr.datalayerStatus.nodeStatus == _sr.consts.NODE_ERR) c = {
                err: avsr.datalayerStatus.error,
                type: avsr.datalayerStatus.dlStatus == _sr.consts.DL_ERR ? 0 : 1,
                href: document.location.href,
                oId: avsr.utils.getSpecificsConf().project.Id
            }, avsr.ajax.post(avsr.main.getAbsoluteUrl("/Datalayer/Report"), c); else c.onDatalayerValid(); else c.onDatalayerInvalid()
        }, E = !1, w = function (a) {
            avsr.specifics.noCss || E || -1 < navigator.appVersion.indexOf("Safari/534.57.2") &&
            -1 == navigator.appVersion.indexOf("Chrome") ? (window.avsr.consoleLog("debug", "ensureCssLoaded - Css Loaded"), a()) : window.setTimeout(function () {
                w(a)
            }, 50)
        }, R = function (a) {
            if (window.avsr && window.avsr.specifics && window.avsr.utils.getSpecificsConf().availability) {
                if (window.avsr.utils.getSpecificsConf().availability.isUserActionsEnabled) {
                    if (a) for (var c = 0; c < window.avsr.utils.getSpecificsConf().availability.disabledActionsList.length; c++) if (window.avsr.utils.getSpecificsConf().availability.disabledActionsList[c] ==
                        a) return !1;
                    return !0
                }
                return !1
            }
            return !0
        }, S = function () {
            return window.avsr && window.avsr.specifics && window.avsr.utils.getSpecificsConf().availability ? window.avsr.utils.getSpecificsConf().availability.isRecoEnabled : !0
        }, d = function (a, c) {
            "undefined" !== typeof a && _$.isFunction(a) && a({status: "error", errorCode: c})
        }, U = function (a, c, d) {
            return function () {
                avsr.log("The function " + (d ? d : "") + " has been deprecated" + (a ? " in version " + a : ""), "warn", "deprecate");
                return c.apply(window, arguments)
            }
        }, X = function () {
            var a = document.location.hash,
                c = window.avsr.browserSupport.splitQueryString(document.location.search.substring(1)),
                a = window.avsr.browserSupport.splitQueryString(a.substring(1)), d = _$.extend(c, a);
            if (d && J() && (_$.isFunction(avsr.specifics.preHandleQueryString) && avsr.specifics.preHandleQueryString(d), d.srProductId || d.srClientProductId && d.srTrackerLabel && d.srSubTrackerLabel || d.srBatchId)) {
                var e;
                d.hasOwnProperty("sandbox") && (e = !0);
                d.srProductId ? avsr.main.platformReady(function () {
                    var a = avsr.auth.completeParams({
                        cliId: d.srAuthUserId, cpId: d.srProductId,
                        cat: d.srCatalog, batchId: d.srBatchId, group: d.srGroup, sandbox: e
                    });
                    avsr.ajax.post(avsr.main.getAbsoluteUrl("/Crm/NodeClick"), a, function () {
                    }, function (c, d, e) {
                        avsr.logXhr("Error while posting to /Crm/NodeClick", "error", "handleQueryString", c, d, e, "Params : " + JSON.stringify(a), "xhr : " + JSON.stringify(c))
                    })
                }) : d.srClientProductId && d.srTrackerLabel && d.srSubTrackerLabel ? avsr.main.platformReady(function () {
                    l({
                        actionName: "ANTVOICE_Clic",
                        clientProductId: d.srClientProductId,
                        trackerLabel: d.srTrackerLabel,
                        subTrackerLabel: d.srSubTrackerLabel,
                        source: 3,
                        withInteract: !0
                    })
                }) : d.srBatchId && avsr.main.platformReady(function () {
                    avsr.auth.completeParams({cliId: d.srAuthUserId, batchId: d.srBatchId, group: d.srGroup})
                })
            }
        }, Y = function () {
            return avsr.storageAccess
        };
    return {
        startApi: function (a, d, e) {
            function g(e) {
                window.avsr.context = F;
                avsr.ajaxTimeout = 3E4;
                avsr.version = "2.3.0";
                avsr.release = "10.47.0";
                !a && window.antvoice_variable && window.antvoice_variable.page && window.antvoice_variable.page.market && 2 == window.antvoice_variable.page.market.length && window.antvoice_variable.page.market[0] &&
                window.antvoice_variable.page.market[1] && (a = window.antvoice_variable.page.market[0], d = window.antvoice_variable.page.market[1]);
                void 0 != a && "" != a && (avsr.context.lang = a);
                void 0 != d && "" != d && (avsr.context.market = d);
                J() || (window.srReady = !0);
                window.avsr && window.avsr.loggingConfiguration && window.avsr.loggingConfiguration.enabled && window.avsr.loggingConfiguration.sampleRate && H();
                navigator.cookieEnabled ? "cookie" in document && (0 < document.cookie.length || -1 < (document.cookie = "av-test").indexOf.call(document.cookie,
                    "av-test")) || (window.avsr.log && avsr.log("Could not write to cookies but navigator.cookieEnabled is true", "warn", "startApi"), l = !0) : (l = !0, window.avsr.log && avsr.log("CookieDisabled", "warn", "startApi"));
                l ? window.avsr.monitoring.logCall("CookieDisabled") : J() ? avsr.storageAccess.initIdentityStorage(function () {
                    var a = null;
                    window.antvoice_variable && window.antvoice_variable.user && window.antvoice_variable.user.user_id && (a = window.antvoice_variable.user.user_id);
                    var d = {};
                    V("enableLoadLock", function () {
                        y(function (a) {
                            d =
                                a;
                            Q("enableLoadLock")
                        })
                    });
                    G("enableLoadLock", function () {
                        avsr.auth.loadIdentity(a, e, d.isEnabledReco && d.isEnabledAds);
                        X();
                        c();
                        q(d.isEnabledReco);
                        u();
                        d.isEnabledReco && d.isEnabledAds && k()
                    })
                }) : e()
            }

            var l = !1;
            V("apiLoaded", function () {
                window._sr = window._sr || {};
                window._sr.init = avsr.main.initIdentity;
                window._sr.logout = avsr.main.logout;
                window._sr.isBrowserSupported = avsr.main.isBrowserSupported;
                window._sr.enable = avsr.main.enable;
                window._sr.disable = avsr.main.disable;
                window._sr.isEnabled = avsr.main.isEnabled;
                window._sr.getReco =
                    avsr.main.getReco;
                window._sr.notifyAction = avsr.main.notifyAction;
                window._sr.notifyTagAction = avsr.main.notifyTagAction;
                window._sr.isUserInTestGroup = avsr.main.isUserInTestGroup;
                window._sr.updateDatalayer = avsr.main.updateDatalayer;
                window._sr.notifyWidgetDisplayed = U("2.13.0", avsr.main.notifyWidgetDisplayed, "_sr.notifyWidgetDisplayed");
                window._sr.notifyProductDisplayed = U("2.13.0", avsr.main.notifyProductDisplayed, "_sr.notifyProductDisplayed");
                window.social = window.social || {};
                window.social.reco = window.social.reco ||
                    {};
                window.social.reco.init = avsr.main.initIdentity;
                window.social.reco.logout = avsr.main.logout;
                window.social.reco.enable = avsr.main.enable;
                window.social.reco.disable = avsr.main.disable;
                window.social.reco.isEnabled = avsr.main.isEnabled;
                window.social.reco.getReco = avsr.main.getReco;
                window.social.reco.notifyAction = avsr.main.notifyAction;
                window.social.reco.notifyWidgetDisplayed = avsr.main.notifyWidgetDisplayed;
                window.social.reco.notifyProductDisplayed = avsr.main.notifyProductDisplayed;
                window.social.reco.updateDatalayer =
                    avsr.main.updateDatalayer;
                V("identityLoaded", function () {
                });
                avsr.utils.callInternal(avsr.specifics.preStart, !0, "presStart") ? C({
                    onDatalayerValid: function () {
                        g(function () {
                            Q("apiLoaded");
                            !0 !== e && Q("identityLoaded");
                            avsr.utils.callInternal(avsr.specifics.postStart, !1, "postStart")
                        })
                    }, onDatalayerInvalid: function () {
                        avsr.log("AntVoice library initialization cancelled by datalayer checking", "info", "startApi")
                    }
                }) : avsr.log("AntVoice library initialization cancelled by preStart", "info", "startApi")
            })
        },
        platformReady: N,
        getAbsoluteUrl: function (a, c) {
            avsr.utils.getSpecificsConf().isUseAvadsUrl && (c = !0);
            var d = !0 === c ? B : z;
            "/" == d[d.length - 1] && "/" == a[0] && (a = a.substr(1));
            return window.avsr.stringHelper.format("{0}{1}", d, a)
        },
        onload: [],
        initIdentity: function (a) {
            J() && G("apiLoaded", function () {
                avsr.auth.initUser(a, function () {
                    Q("identityLoaded")
                })
            })
        },
        notifyAction: l,
        notifyTagAction: function (a) {
            e(a, avsr.activities.notifyTagAction, _sr.consts.NOTIFY_TAG_ACTION)
        },
        isBrowserSupported: function () {
            null === A && ((A = avsr.browserSupport.isSupported()) ||
                avsr.browserSupport.isDisabledFunctionalities() || window.avsr.monitoring.logCall("BrowserNotSupported"));
            return A
        },
        enable: function (a, c) {
            J({callback: c}) && N(function () {
                avsr.recommendation.enableRecommendation(!0, a, c, !1)
            })
        },
        disable: function (a, c) {
            J({callback: c}) && N(function () {
                avsr.recommendation.enableRecommendation(!1, a, c)
            })
        },
        isEnabled: function (a, c) {
            J() ? avsr.recommendation.isRecommendationEnabled(a, c) : c && _$.isFunction(c) && c()
        },
        isEnabledRecoAds: function (a, c) {
            J() ? avsr.recommendation.isAdsEnabled(a, c) : c &&
                _$.isFunction(c) && c()
        },
        getOptOutDatas: function (a, c) {
            J() ? avsr.recommendation.getDisabledDatas(a) : c && _$.isFunction(c) && c({
                isEnabledAds: !0,
                isEnabledReco: !0
            })
        },
        getReco: function (a, c, d) {
            J() && N(function () {
                var e = !1;
                avsr.utils.getSpecificsConf().isUseAvadsUrl ? e = !0 : 0 < a.length && (e = a[0].isUseAvadsUrl ? !0 : !1);
                y(function (g) {
                    if (g.isEnabledReco && !e || g.isEnabledAds && e) if (window.antvoice_variable) if (a) {
                        for (g = 0; g < a.length; g++) {
                            var k = avsr.recoDatalayer.getMode(a[g]);
                            "simple" === k && void 0 !== window.avsr.specifics.areaMapping &&
                            (a[g] = avsr.recoDatalayer.updateRecoDatalayer(a[g]), a[g].strategies && a[g].support && a[g].rendering && a[g].rendering.mode || avsr.logDatalayerErrors("getReco: E: recoDatalayer.strategies, recoDatalayer.support, recoDatalayer.rendering or recoDatalayer.rendering.mode is undefined.", !0));
                            "simple" !== k && "advanced" != k && avsr.logDatalayerErrors("getReco: E: The datalayer mode is neither advanced nor simple.", !0)
                        }
                        avsr.recommendation.getReco(a, c, d)
                    } else avsr.logDatalayerErrors("request: E: No recommendation requests",
                        !0), d && d(); else avsr.logDatalayerErrors("request: E: Could not get antvoice_variable", !0), d && d()
                })
            })
        },
        notifyWidgetDisplayed: function (a) {
            J(a) && N(function () {
                S() && _sr.isEnabled(function () {
                    avsr.activities.notifyWidgetDisplayed(a)
                }, function () {
                    a && a.callback && d(a.callback, 900)
                })
            })
        },
        notifyProductDisplayed: function (a) {
            J(a) && N(function () {
                S() && _sr.isEnabled(function () {
                    avsr.activities.notifyProductDisplayed(a)
                }, function () {
                    a && a.callback && d(a.callback, 900)
                })
            })
        },
        updateDatalayer: function () {
            J() && N(function () {
                C({
                    onDatalayerValid: function () {
                        avsr.utils.callInternal(avsr.specifics.postFillDatalayer,
                            !1, "postFillDatalayer")
                    }, onDatalayerInvalid: function () {
                        avsr.log("AntVoice library datalayer update cancelled by datalayer checking", "info", "startApi")
                    }
                })
            })
        },
        logout: function (a) {
            J({callback: a}) && N(function () {
                avsr.auth.logOut({callback: a})
            })
        },
        contentUrl: t,
        contentUrlAvads: document.location.protocol + "//img.avads.net/",
        isUserInTestGroup: function (a) {
            J({callback: a}) && N(function () {
                "undefined" !== typeof a && _$.isFunction(a) && a(avsr.auth.isAbTestGroup())
            })
        },
        getStorageAccess: Y,
        stringify: function (a) {
            if ("undefined" !==
                typeof Prototype && 1.7 > parseFloat(Prototype.Version.substr(0, 3)) && "undefined" !== typeof Array.prototype.toJSON) {
                var c = Array.prototype.toJSON;
                delete Array.prototype.toJSON;
                a = JSON.stringify(a);
                Array.prototype.toJSON = c;
                return a
            }
            return JSON.stringify(a)
        },
        loadCss: function (a) {
            if (!avsr.specifics.noCss && !E) {
                var c = a ? avsr.main.contentUrlAvads : avsr.main.contentUrl;
                !a && avsr.utils.getSpecificsConf().isUseAvadsUrl && (c = avsr.main.contentUrlAvads);
                c += "social.reco.recommendation." + avsr.utils.getSpecificsConf().project.cssKey +
                    ".css".replace("http: ", document.location.protocol + ":");
                a = window.loadCSS(c);
                window.onloadCSS(a, function () {
                    window.avsr.consoleLog("info", "Css Loaded");
                    E = !0
                })
            }
        },
        ensureCssLoaded: w,
        onCallSuccess: function () {
            try {
                avsr.auth.cleanTmpCookie()
            } catch (r) {
                avsr.logException("An error occured while cleaning tmp cookies", "onCallSuccess", r)
            }
        },
        enforceDnt: !1
    }
}();
window._sr = window._sr || {
    consts: {
        DL_OK: 0,
        DL_ERR: 1,
        DL_NOTUSED: 2,
        NODE_OK: 10,
        NODE_ERR: 11,
        NODE_EMPTY: 12,
        NODE_INCOMPLETE: 13,
        RECO: 100,
        NOTIFY_ACTION: 101,
        NOTIFY_TAG_ACTION: 102
    }
};
window._sr._start = avsr.main.startApi;

window.avsr = window.avsr || {};
window.avsr.loggingConfiguration = {enabled: false, sampleRate: 100, windowOnErrorEnabled: false, logLevel: 'info'};
window.avsr.specifics = window.avsr.specifics || (function () {

    var clientSpecConfiguration =
        {
            availability: {
                isRecoEnabled: true,
                isUserActionsEnabled: true,
                isTimeLoggingEnabled: true,
                logParametersInQuery: false,
                isCallLoggingEnabled: true,
                isRecommendationCached: false,
                disabledActionsList: [],
                auditIdentity: true,
                isThirdPartySyncEnabled: false
            }, // + param figstre par redirections => cf ci dessous
            templateKey: "misterauto",
            isCrossDomain: true,
            project: {"Id": 19, "groupKey": "MISTERAUTO", "cssKey": "MISTERAUTO"},
            configurations: {
                serverSideStrategies: true,
                noCss: true
            },
            tracking: {}
        };

    //AB TAsty Conf
    if (window.location && window.location.hash) {
        var encHash = window.location.hash.substring(1);
        if (encHash.indexOf("embedEditor=") != -1) {
            clientSpecConfiguration.isCrossDomain = false;
            clientSpecConfiguration.tracking.useRedirect = true;
        }
    }
    if (window.location && window.location.search) {
        var encQuery = window.location.search.substring(1);
        if (encQuery.indexOf("embedEditor=") != -1) {
            clientSpecConfiguration.isCrossDomain = false;
            clientSpecConfiguration.tracking.useRedirect = true;
        }
    }
    if (window.ABTastyEditor) {
        clientSpecConfiguration.isCrossDomain = false;
        clientSpecConfiguration.tracking.useRedirect = true;
    }
    // Hook particuliers

    /* Reco est un objet qui contient les propriétés suivantes :
		{
			r:
				[{
					items: response.data.items,
					owners: response.data.owners,
					recoGuid: response.data.recoGuid,
					log: response.data.log,
					isAbTesting: response.data.isAbTesting,
					isActive: response.data.isActive
				}],
			totalItems: response.data.items.length,
			gId: response.data.recoGuid // id de groupe de reco
		}
	*/

    var startTemplating = function (params, reco) { //Avant templating (HTML ou JSON)
        return true; // Pour annuler le templating
    }

    // pre et postTemplating seront appelé à priori pour chaque groupe. Donc il n'y aura qu'un recoContainer par appel
    var endTemplating = function (params, reco, recoContainers) {
        //Après templating (HTML ou JSON (si faisable)) -> le tableau recoContainers contient les objets Jquery répondant au sélecteur '[data-sr-recoid = "XXXX"]'
        return true; // Pour annuler l'appel
    }


    // GetRecommendation

    var startGetReco = function (params) {
        if (!window.recoTriggered)
            window.recoTriggered = {};

        for (k = 0; k < params.length; k++) {
            //STOP CALL FROM LEGACY
            if (params[k].legacy) {
                return false;
            }
            if (window.recoTriggered[params[k].areaId]) {
                return false;
            }
            else {
                window.recoTriggered[params[k].areaId] = true;
            }
        }

        return true; // Pour annuler l'appel
    }

    var preGetReco = function (params) { //Avant appel Serveur récupération Reco
        return true; // Pour annuler l'appel
    }

    var postGetReco = function (params, response) { // Après retour Serveur récupération Reco

        return true; // Pour annuler l'appel
    }

    var endGetReco = function (params) {
    }


    // NotifyAction

    var startNotifyAction = function (params) {
        if (!window.recoTriggered)
            window.recoTriggered = {};
        window.avsr.log("StartNotifyAction" + "Params : " + JSON.stringify(params) + "-Location :" + JSON.stringify(window.location) + "-AVVariable :" + JSON.stringify(window.antvoice_variable), "info", 'misterauto.specifics');
        if (window.recoTriggered.Notify || !params.newVersion) {
            return false;
        } /// STOP CALL FROM LEGACY
        window.recoTriggered.Notify = true;
        if (!params.newVersion) {
            if (params.clientProductId && params.clientProductId.indexOf(']') != -1 && params.clientProductId.indexOf('[') != -1) {
                params.clientProductId = JSON.parse(params.clientProductId.replace(/'/g, '"'));
            }
            if (params.actionName && params.actionName.indexOf("_Buy") != -1) {
                window.antvoice_variable.page.type = "PaymentConfirmationPage";
                if (!window.antvoice_variable.basket) {
                    window.antvoice_variable.basket = {};
                }
                window.antvoice_variable.basket.transaction_id = params.transactionId;
                window.antvoice_variable.basket.currency = params.currency ? params.currency : "EUR";
                window.antvoice_variable.basket.line_items = [];
                if (params.clientProductId && params.clientProductId.constructor === Array) {
                    for (var i = 0; i < params.clientProductId.length; i++) {
                        obj = {};
                        obj.product = {};
                        obj.quantity = 1;
                        obj.product.id = params.clientProductId[i];
                        obj.product.unit_sale_price = parseFloat(params.price[i]);
                        window.antvoice_variable.basket.line_items.push(obj);
                    }
                } else {
                    obj = {};
                    obj.product = {};
                    obj.quantity = 1;
                    obj.product.id = params.clientProductId;
                    obj.product.unit_sale_price = parseFloat(params.price);
                    window.antvoice_variable.basket.line_items.push(obj);
                }
                params = {
                    actionName: params.actionName
                };
            } else if (params.clientProductId) {
                if (!window.antvoice_variable.product) {
                    window.antvoice_variable.product = {};
                }
                window.antvoice_variable.product.id = params.clientProductId;
                params = {
                    actionName: params.actionName
                };
            }
        }

        return true; // Pour annuler l'appel
    }

    var preNotifyAction = function (params) { //Avant notification d'une action
        return true; // Pour annuler le notify
    }

    var postNotifyAction = function (params, response) { //Après notification d'une action
        return true; // Pour annuler l'appel
    }

    var endNotifyAction = function (params) {
    }


    // NotifyTagAction

    var startNotifyTagAction = function (params) {
        if (params.tagLabel && params.tagType && params.actionName) {
            var obj = {};
            obj.name = params.tagLabel;
            obj.type = params.tagType;
            obj.action = params.actionName;


            if (!window.antvoice_variable.tags) {
                window.antvoice_variable.tags = [];
            }
            window.antvoice_variable.tags.push(obj);
        }
        return true; // Pour annuler l'appel
    }

    var preNotifyTagAction = function (params) { //Avant notification d'une action
        return true; // Pour annuler le notify
    }

    var postNotifyTagAction = function (params, response) { //Après notification d'une action
        return true; // Pour annuler l'appel
    }

    var endNotifyTagAction = function (params) {
    }


    // Init calls

    var preStart = function () {
        //Si il y avait du code à la suite du specifics c'est dans ces fonctions qu'il doit aller (y compris le _sr.init/_sr.start)

        return true;  //Permet d'empêcher le chargement de la librairie
    }

    var fillDatalayer = function () {
        if (!window.antvoice_variable) {
            window.antvoice_variable = {};
        }
        if (window.antvoice_variable.version && window.antvoice_variable.version == '2.0') {
        } else {
            window.antvoice_variable.project = 'misterauto';
            window.antvoice_variable.page = {};
            window.antvoice_variable.page.environment = "P";
            window.antvoice_variable.page.hierarchy = [];
            window.antvoice_variable.page.context = {};

            window.antvoice_variable.page.type = "Unspecified";
        }
        if (window.antvoice_variable.page && !window.antvoice_variable.page.market) {
            window.antvoice_variable.page.market = ["fr-FR", "FR"];
        }
        if (window.antvoice_variable.page && window.antvoice_variable.page.market && window.antvoice_variable.page.market.length == 2) {
            if (window.location.hostname.indexOf(".br") > -1) {
                window.antvoice_variable.page.market = ["pt-BR", "BR"];
            } else if (window.location.hostname.indexOf(".com") > -1) {
                window.antvoice_variable.page.market = ["fr-FR", "FR"];
            } else if (window.location.hostname.indexOf(".fr") > -1) {
                window.antvoice_variable.page.market = ["fr-FR", "FR"];
            } else if (window.location.hostname.indexOf(".de") > -1) {
                window.antvoice_variable.page.market = ["de-DE", "DE"];
            } else if (window.location.href.indexOf(".ch/fr") > -1) {
                window.antvoice_variable.page.market = ["fr-CH", "CH"];
            } else if (window.location.hostname.indexOf(".es") > -1) {
                window.antvoice_variable.page.market = ["es-ES", "ES"];
            } else if (window.location.hostname.indexOf(".pt") > -1) {
                window.antvoice_variable.page.market = ["pt-PT", "PT"];
            } else if (window.location.hostname.indexOf(".re") > -1) {
                window.antvoice_variable.page.market = ["fr-FR", "FR"];
            } else if (window.location.hostname.indexOf(".gp") > -1) {
                window.antvoice_variable.page.market = ["fr-FR", "FR"];
            } else if (window.location.hostname.indexOf(".gr") > -1) {
                window.antvoice_variable.page.market = ["el-GR", "GR"];
            } else if (window.location.hostname.indexOf(".nl") > -1) {
                window.antvoice_variable.page.market = ["fl-NL", "NL"];
            } else if (window.location.hostname.indexOf(".at") > -1) {
                window.antvoice_variable.page.market = ["de-AT", "AT"];
            } else if (window.location.hostname.indexOf(".it") > -1) {
                window.antvoice_variable.page.market = ["it-IT", "IT"];
            } else if (window.location.hostname.indexOf(".fi") > -1) {
                window.antvoice_variable.page.market = ["fi-FI", "FI"];
            } else if (window.location.hostname.indexOf(".ma") > -1) {
                window.antvoice_variable.page.market = ["ar-MA", "MA"];
            } else if (window.location.href.indexOf(".be/fr") > -1) {
                window.antvoice_variable.page.market = ["fr-BE", "BE"];
            } else if (window.location.href.indexOf(".lu/fr") > -1) {
                window.antvoice_variable.page.market = ["fr-LU", "LU"];
            } else if (window.location.hostname.indexOf(".uk") > -1) {
                window.antvoice_variable.page.market = ["en-GB", "GB"];
            } else if (window.location.hostname.indexOf(".se") > -1) {
                window.antvoice_variable.page.market = ["sv-SE", "SE"];
            } else if (window.location.href.indexOf(".ch/de") > -1) {
                window.antvoice_variable.page.market = ["de-CH", "CH"];
            } else if (window.location.hostname.indexOf(".mq") > -1) {
                window.antvoice_variable.page.market = ["fr-FR", "FR"];
            } else if (window.location.href.indexOf(".be/fl") > -1) {
                window.antvoice_variable.page.market = ["fl-BE", "BE"];
            } else if (window.location.href.indexOf(".lu/de") > -1) {
                window.antvoice_variable.page.market = ["de-LU", "LU"];
            } else if (window.location.hostname.indexOf(".ie") > -1) {
                window.antvoice_variable.page.market = ["en-IE", "IE"];
            } else if (window.location.hostname.indexOf(".dk") > -1) {
                window.antvoice_variable.page.market = ["da-DK", "DK"];
            } else if (window.location.hostname.indexOf(".no") > -1) {
                window.antvoice_variable.page.market = ["no-NO", "NO"];
            } else if (window.location.hostname.indexOf(".gf") > -1) {
                window.antvoice_variable.page.market = ["fr-FR", "FR"];
            }
            else {
                window.antvoice_variable.page.market = ["en-GB", "GB"];
            }
        }
        if (!window.antvoice_strategies)
            window.antvoice_strategies =
                [
                    {
                        sId: "s65",
                        name: "Filtrage Vehicule",
                        locations: ["ProductPage", "HomePage", "CategoryPage", "SubCategoryPage", "BasketPage", "AddToBasketPopup"]
                    }
                ];
        return true; //Permet d'empêcher l'utilisation de la librairie
    }

    var postStart = function () {
        //Client Historique, on définit les fonctions de substitution
        // var dumbfunction = function(params){
        //     console.log("Call with old setup : " +JSON.stringify(params));
        // }
        //TODO STOP CALL FROM LEGACY
        // window._sr.getRecommendation = dumbfunction;
        // window._sr.getJsonRecommendation = dumbfunction;
        window._sr.getRecommendation = legacyGetRecommendation;
        window._sr.getJsonRecommendation = legacyGetRecommendation;


        //Si il y avait du code à la suite du specifics c'est dans ces fonctions qu'il doit aller (y compris le _sr.init/_sr.start)
        if (avsr.context && avsr.context.lang && avsr.context.market && window.antvoice_variable.version != '2.0') {
            window.antvoice_variable.page.market = [];
            window.antvoice_variable.page.market.push(avsr.context.lang);
            window.antvoice_variable.page.market.push(avsr.context.market);
        }
        //NOTIFY
        var loc = window.antvoice_variable.page.type;
        if (window.antvoice_variable.version == '2.0') {
            if (loc == "ProductPage") {
                if (window.antvoice_variable.product && window.antvoice_variable.product.id) {
                    _sr.notifyAction({
                        actionName: window.antvoice_variable.project.toUpperCase() + "_View"
                        , newVersion: true
                    });
                    //_$(function () {
                    //    if (_$('#formulaire form div.produit_btn input[onclick]').length == 1)
                    //    {
                    //        _$('#formulaire form div.produit_btn input[onclick]').live('click', function () {
                    //            _sr.notifyAction({
                    //                actionName: window.antvoice_variable.project.toUpperCase() + "_AddToBasket"
                    //            });
                    //        });
                    //    }
                    //});

                }
            }
            if (loc == "PaymentConfirmationPage" && window.antvoice_variable.basket) {
                _sr.notifyAction({
                    actionName: window.antvoice_variable.project.toUpperCase() + "_Buy"
                    , newVersion: true
                });
            }
        }
        //RECO
        if (window.antvoice_variable.version == '2.0') {
            if (loc == "ProductPage"
                && window.antvoice_variable.page.context && window.antvoice_variable.page.context.Vehicle) {
                _sr.getReco(
                    [{
                        areaId: "MISTERAUTO_BLOC_BASKETPOPUP",
                        location: "AddToBasketPopup",
                        rendering:
                            {
                                onSuccess: function (data) {
                                    window.Traiter_Antvoice_Recos(data.group.r[data.requestIndex].items, "popup_panier_");
                                }
                            }
                    }]);
                _sr.getReco(
                    [{
                        areaId: "MISTERAUTO_BLOC_PRODUCTPAGE",
                        rendering:
                            {
                                onSuccess: function (data) {
                                    window.Traiter_Antvoice_Recos(data.group.r[data.requestIndex].items, "");
                                    if (data.group.r[data.requestIndex].items.length > 0) {
                                        if ($('.antvoice_recommendations').length > 0) {
                                            $('.antvoice_recommendations').css('display', 'block');
                                        }
                                        for (var c = 0; c < data.group.r[data.requestIndex].items.length; c++) {
                                            if ($('#antvoice-reco_' + c).length > 0 && $('#antvoice-reco_' + c).attr('data-sr-recoguid')) {
                                                $('#antvoice-reco_' + c).css('display', 'block');
                                            }
                                        }
                                    }
                                }
                            }
                    }]);
            }
            else if (loc == "ProductPage_1"
                && window.antvoice_variable.page.context && window.antvoice_variable.page.context.Vehicle) {
                _sr.getReco(
                    [{
                        areaId: "MISTERAUTO_BLOC_BASKETPOPUP",
                        location: "AddToBasketPopup",
                        rendering:
                            {
                                onSuccess: function (data) {
                                    window.Traiter_Antvoice_Recos(data.group.r[data.requestIndex].items, "popup_panier_");
                                }
                            }
                    }]);
                _sr.getReco(
                    [{
                        areaId: "MISTERAUTO_BLOC_PRODUCTPAGE",
                        location: "ProductPage",
                        rendering:
                            {
                                onSuccess: function (data) {
                                    window.Traiter_Antvoice_Recos(data.group.r[data.requestIndex].items, "");
                                    if (data.group.r[data.requestIndex].items.length > 0) {
                                        if ($('.antvoice_recommendations').length > 0) {
                                            $('.antvoice_recommendations').css('display', 'block');
                                        }
                                        for (var c = 0; c < data.group.r[data.requestIndex].items.length; c++) {
                                            if ($('#antvoice-reco_' + c).length > 0 && $('#antvoice-reco_' + c).attr('data-sr-recoguid')) {
                                                $('#antvoice-reco_' + c).css('display', 'block');
                                            }
                                        }
                                    }
                                }
                            }
                    }]);
            }
            else if (loc == "SubCategoryPage"
                && window.antvoice_variable.page.context && window.antvoice_variable.page.context.Vehicle) {
                _sr.getReco([{
                    areaId: "MISTERAUTO_BLOC_SubCateg",
                    excluded: {"MISTERAUTO": window.antvoice_variable.excludedProdIds},
                    rendering:
                        {
                            onSuccess: function (data) {
                                window.Traiter_Antvoice_Recos(data.group.r[data.requestIndex].items, "");
                            }
                        }
                }]);
            }
            else if (loc == "CategoryPage"
                && window.antvoice_variable.page.context && window.antvoice_variable.page.context.Vehicle) {
                _sr.getReco([{
                    areaId: "MISTERAUTO_BLOC_VEHICLECATEG",
                    rendering:
                        {
                            onSuccess: function (data) {
                                window.Traiter_Antvoice_Recos(data.group.r[data.requestIndex].items, "");
                            }
                        }
                }]);
            }
            else if (loc == "BasketPage"
                && window.antvoice_variable.page.context && window.antvoice_variable.page.context.Vehicle) {
                _sr.getReco([{
                    areaId: "MISTERAUTO_BLOC_BASKETPAGE",
                    excluded: {"MISTERAUTO": window.antvoice_variable.excludedProdIds},
                    rendering:
                        {
                            onSuccess: function (data) {
                                window.Traiter_Antvoice_Recos(data.group.r[data.requestIndex].items, "");
                            }
                        }
                }]);
            }
        }
        window.avsr.cookies.deleteKey('av-multiInitLocker');
    }

    // Other methods

    var getRecoTriggeringDistance = function (params) {
        return -1;
    }


    var legacyGetRecommendation = function (params) {
        console.log("Call with old setup : " + JSON.stringify(params));

        if (!window.antvoice_variable.page.context) window.antvoice_variable.page.context = {};
        if (params.productFilters
            && params.productFilters.vehicle
            && params.productFilters.vehicle.values
            && params.productFilters.vehicle.values.length
            && params.productFilters.vehicle.values.length == 1
            && !window.antvoice_variable.page.context.Vehicle) {
            console.log("Vehicle Id set by old params, must be from GTM");
            window.antvoice_variable.page.context.Vehicle = params.productFilters.vehicle.values[0];
        }

        if (params.location && params.location == 'ProductPage' && params.clientProductId) {
            if (!window.antvoice_variable.product)
                window.antvoice_variable.product = {};
            if (params.clientProductId.indexOf(']') != -1 && params.clientProductId.indexOf('[') != -1) {
                params.clientProductId = JSON.parse(params.clientProductId.replace(/'/g, '"'));
            }
            if (params.clientProductId.constructor === Array && params.clientProductId.length == 1) {
                params.clientProductId = params.clientProductId[0];
            }
            if (!window.antvoice_variable.product.id) {
                window.antvoice_variable.product.id = params.clientProductId;
            }
        }

        // var recoDatalayer = {};
        // //Correction des locations mobile WEB qui ne persistent pas.
        // if (params.location == "ProductPage" && params.subTrackerLabel == "BasketPopup"
        //     && window.antvoice_variable.page.context.Vehicle) {
        //     recoDatalayer =
        //       {
        //           areaId: "MISTERAUTO_BLOC_BASKETPOPUP",
        //           location: "AddToBasketPopup",
        //           rendering:
        //           {
        //               onSuccess: function (data) {
        //                   params.callback(data.group.r[data.requestIndex].items)
        //               }
        //           }
        //           ,legacy : true
        //       };
        //     // On précise le page type avant appel
        //     window.antvoice_variable.page.type = params.location;
        //     _sr.getReco([recoDatalayer]);
        // }
        // else if (params.location == "SubCategoryPage"
        //     && window.antvoice_variable.page.context && window.antvoice_variable.page.context.Vehicle) {
        //     recoDatalayer =
        //         {
        //             areaId: "MISTERAUTO_BLOC_SubCateg",
        //             excluded: {},
        //             rendering:
        //             {
        //                 onSuccess: function (data) {
        //                     params.callback(data.group.r[data.requestIndex].items)
        //                 }
        //             }
        //             ,legacy : true
        //         };
        //     if (params.excludedClientProductIds) {
        //         recoDatalayer.excluded = { "MISTERAUTO": [] };
        //         for (var i = 0; i < params.excludedClientProductIds.length; i++) {
        //             recoDatalayer.excluded["MISTERAUTO"].push( "" + params.excludedClientProductIds[i] + "");
        //         }
        //     }
        //     // On précise le page type avant appel
        //     window.antvoice_variable.page.type = params.location;
        //     _sr.getReco([recoDatalayer]);

        // }
        // else if (params.location == "ProductPage"
        //     && window.antvoice_variable.page.context.Vehicle) {
        //     recoDatalayer =
        //       {
        //           areaId: "MISTERAUTO_BLOC_PRODUCTPAGE",
        //           rendering:
        //           {
        //               onSuccess: function (data) {
        //                   params.callback(data.group.r[data.requestIndex].items)
        //               }
        //           }
        //           ,legacy : true
        //       };
        //     // On précise le page type avant appel
        //     window.antvoice_variable.page.type = params.location;
        //     _sr.getReco([recoDatalayer]);

        // }
        // else if (params.location == "CategoryPage"
        //     && window.antvoice_variable.page.context.Vehicle) {
        //     recoDatalayer =
        //         {
        //             areaId: "MISTERAUTO_BLOC_VEHICLECATEG",
        //             rendering:
        //             {
        //                 onSuccess: function (data) {
        //                     params.callback(data.group.r[data.requestIndex].items)
        //                 }
        //             }
        //             ,legacy : true
        //         };
        //     // On précise le page type avant appel
        //     window.antvoice_variable.page.type = params.location;
        //     _sr.getReco([recoDatalayer]);
        // }
        // else if (params.location == "BasketPage"
        //     && window.antvoice_variable.page.context.Vehicle) {
        //     recoDatalayer =
        //         {
        //             areaId: "MISTERAUTO_BLOC_BASKETPAGE",
        //             excluded: {},
        //             rendering:
        //             {
        //                 onSuccess: function (data) {
        //                     params.callback(data.group.r[data.requestIndex].items)
        //                 }
        //             }
        //             ,legacy : true
        //         };
        //     // On précise le page type avant appel
        //     window.antvoice_variable.page.type = params.location;
        //     _sr.getReco([recoDatalayer]);
        //     if (params.excludedClientProductIds) {
        //         recoDatalayer.excluded = { "MISTERAUTO": [] };
        //         for (var i = 0; i < params.excludedClientProductIds.length; i++) {
        //             recoDatalayer.excluded["MISTERAUTO"].push("" + params.excludedClientProductIds[i] + "");
        //         }
        //     }
        // }

    };

    return {
        clientSpecConfiguration: clientSpecConfiguration,

        startTemplating: startTemplating,
        endTemplating: endTemplating,

        startGetReco: startGetReco,
        preGetReco: preGetReco,
        postGetReco: postGetReco,
        endGetReco: endGetReco,

        startNotifyAction: startNotifyAction,
        preNotifyAction: preNotifyAction,
        postNotifyAction: postNotifyAction,
        endNotifyAction: endNotifyAction,

        startNotifyTagAction: startNotifyTagAction,
        preNotifyTagAction: preNotifyTagAction,
        postNotifyTagAction: postNotifyTagAction,
        endNotifyTagAction: endNotifyTagAction,

        preStart: preStart,
        fillDatalayer: fillDatalayer,
        postStart: postStart,

        getRecoTriggeringDistance: getRecoTriggeringDistance,

        noCss: true
    };

})();

var checkForMultiInit = function () {
    window.avsr.cookies.getKey('av-multiInitLocker', function (value) {
        if (!value) {
            var now = new Date();
            now.setTime(now.getTime() + 15000);
            window.avsr.cookies.setKey('av-multiInitLocker', now, '1');
            if (!window._srAsyncInit) {
                _sr._start();
            } else {
                window._srAsyncInit();
            }
        } else {
            window.setTimeout(checkForMultiInit, 300);
        }
    });
}
checkForMultiInit();

