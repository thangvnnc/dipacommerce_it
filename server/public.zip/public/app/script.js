var general_width_oldui = 966;

function setModalMaxHeight(element) {
    this.$element = $(element), this.$content = this.$element.find(".modal-content");
    var borderWidth = this.$content.outerHeight() - this.$content.innerHeight(),
        dialogMargin = $(window).width() < 768 ? 20 : 60,
        maxHeight = $(window).height() - (dialogMargin + borderWidth) - ((this.$element.find(".modal-header").outerHeight() || 0) + (this.$element.find(".modal-footer").outerHeight() || 0));
    this.$content.css({overflow: "hidden"}), this.$element.find(".modal-body").css({
        "max-height": maxHeight,
        "overflow-y": "auto"
    })
}

function setCookie(name, value, days, encode) {
    void 0 === days && (days = 100);
    var date = new Date;
    date.setDate(date.getDate() + days), void 0 !== encode && !0 === encode && (value = encodeURIComponent(JSON.stringify(value)));
}

$("ul.nav li.desktop-menu-dropdown").hover(function () {
    $(this).find(".dropdown-menu").stop(!0, !0).delay(200).fadeIn(200)
}, function () {
    $(this).find(".dropdown-menu").stop(!0, !0).delay(200).fadeOut(200)
}), $("ul.nav li.ui-desktop-menu-dropdown").hover(function () {
    $(this).addClass("open"), $("a.dropdown-toggle", this).attr("aria-expanded", "true"), $(this).find(".dropdown-menu").stop(!0, !0).delay(200).fadeIn(200)
}, function () {
    $(this).removeClass("open"), $("a.dropdown-toggle", this).attr("aria-expanded", "false"), $(this).find(".dropdown-menu").stop(!0, !0).delay(200).fadeOut(200)
}), $(".modal").on("show.bs.modal", function () {
    $(this).show(), setModalMaxHeight(this)
}), $(window).resize(function () {
    0 != $(".modal.in").length && setModalMaxHeight($(".modal.in"))
})
var openFancyBox = function (element, options) {
    var data = {src: element, type: "inline"};
    options && $.each(options, function (key, item) {
        data[key] = item
    }), $.fancybox.open(data)
}, loader = function () {
    $(".container-loader").fadeToggle(500)
};

function initToolTip() {
    $('[data-toggle="tooltip"]').tooltip()
}

function removeEmptyDiv() {
    $(".tpl-region").find(".empty-content").each(function () {
        $(this).closest(".tpl-row").remove()
    })
}

function Sticky(selector) {
    var beginPosition = parseInt($(selector).offset().top);
    $(window).scroll(function () {
        var scrollTop = $(window).scrollTop();
        beginPosition < scrollTop ? ($(selector).addClass("sticky"), $("body").addClass("sticky")) : ($(selector).removeClass("sticky"), $("body").removeClass("sticky"))
    })
}

$(document).ready(function () {
    initToolTip(), removeEmptyDiv()
});
