function trackProductToCart(productData, typePage) {
    if ("object" == typeof productData) {
        var name = trim(productData.name), brand = trim(productData.brand);
        if (push_data_to_gtm({
            event: "eventGA",
            category: "ecommerce",
            action: "Add to Cart",
            label: name,
            ecommerce: {
                add: {
                    products: [{
                        name: name,
                        id: productData.id,
                        price: productData.price,
                        brand: brand,
                        category: productData.category,
                        variant: productData.variant,
                        quantity: productData.quantity
                    }]
                }
            }
        }), -1 !== $.inArray(typePage, ["listing", "item"]) && void 0 !== productData.availability && productData.availability <= 1) {
            if (0 == productData.availability) var action = "addToCartSDS"; else if (1 == productData.availability) action = "addToCartNDD";
            push_data_to_gtm({event: "eventGA", category: "marketPlaceInside", action: action, label: action})
        }
        "offer" === typePage && productData.offer && push_data_to_gtm({
            event: "eventGA",
            category: "marketPlaceInside",
            action: "addToBasket_" + productData.offer,
            label: productData.vehicle + "*" + productData.id + "*" + productData.quantity + "**" + productData.offer
        }), trackChoiceAssistanceProduct(productData, "AjoutPanier")
    }
}

function trackProductToCartIndispo(productData) {
    if ("object" == typeof productData) {
        var name = trim(productData.name), brand = trim(productData.brand);
        push_data_to_gtm({
            event: "eventGA",
            category: "out of stock",
            action: productData.category + "|" + brand,
            label: productData.id + "|" + name
        }), trackChoiceAssistanceProduct(productData, "AjoutPanier")
    }
}

function trackChoiceAssistanceProduct(productData, action) {
    0 < $(".choice-assistance-filter").length && push_data_to_gtm({
        event: "eventGA",
        category: "AideAuChoix",
        action: action + "|" + productData.id + "|" + trim(productData.name),
        label: getChoiceAssistanceSelectedLevels()
    })
}

function getChoiceAssistanceSelectedLevels() {
    var nbSelectedByLevels = angular.element(document.body).injector().get("choiceAssistanceService").getNbSelectedByLevels();
    return nbSelectedByLevels[1] + "|" + nbSelectedByLevels[2] + "|" + nbSelectedByLevels[3]
}

function trackChoiceAssistanceSelect(filterId, filterLabel, filterValue, filterLevel, isSelected) {
    push_data_to_gtm({
        event: "eventGA",
        category: "AideAuChoix",
        action: "Filtre de niveau " + filterLevel + " " + (isSelected ? "activé" : "désactivé"),
        label: filterId + "|" + filterLabel + "|" + filterValue
    })
}

function trackSelectorSubmit(selectorType, selectorValues) {
    push_data_to_gtm({
        event: "eventGA",
        category: "Selector",
        action: "Submit " + selectorType,
        label: Object.values(selectorValues).filter(function (elt) {
            return !!elt
        }).join(" | ")
    })
}

function trackProductGBB(productListingInfo, productData, tracking) {
    var data = {
        event: "eventGA",
        category: "listingCuration",
        label: productListingInfo.familyId + "|" + productListingInfo.genericId + "|" + productData.id
    };
    ("Listing_MonoMounting" === tracking.fromPage || "Listing_MonoManufacturer" === tracking.fromPage || "Listing_MonoManufacturerMonoMounting" === tracking.fromPage) && ("gbb" === tracking.fromLevel ? data.action = "addToCartGBB" : data.action = "addToCartCave", push_data_to_gtm(data))
}

function push_data_to_gtm(data) {
    dataLayer.push(data)
}
